pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // NewPipeExtractor (NewPipe's extraction library) is published through JitPack.
        // It is the on-device replacement for the desktop app's bundled yt-dlp binary.
        maven {
            url = uri("https://jitpack.io")
            content { includeGroupByRegex("com\\.github\\.TeamNewPipe.*") }
        }
    }
}

rootProject.name = "Riff"

// Layered modules, mirroring the structure requested for the port.
include(":app")       // application shell: Application, Activity, playback service host, resources
include(":core")      // design system, DSP/audio effects, playback engine, utilities
include(":data")      // Room, repositories, providers (search/stream/lyrics/download), WorkManager
include(":domain")    // pure Kotlin models, ports of the desktop algorithms, repository contracts
include(":feature")   // Compose screens + view models (home, search, player, library, playlists, lyrics, settings)
