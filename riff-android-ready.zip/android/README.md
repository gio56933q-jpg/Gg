# Riff for Android

A native Android client for the [Riff](../) desktop player — Kotlin, Jetpack Compose
(Material 3), AndroidX Media3 (`MediaSessionService`), Room, Coroutines/Flow, WorkManager.
No Electron, no WebView, no bundled yt-dlp/ffmpeg binaries.

See **[PORTING.md](PORTING.md)** for the full desktop → Android mapping, the fidelity notes
(reverb, transcoding, export, visualiser), the backend modes and the known limitations.

## Build

```bash
cd android
./gradlew assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
./gradlew test                 # JVM unit tests (domain, core, data, feature)
./gradlew connectedAndroidTest # instrumentation tests (device/emulator)
./gradlew installDebug         # install on a connected device
```

Needs JDK 17 and Android SDK 35 (`local.properties` → `sdk.dir=...`).

## Modules

| Module | Role |
| --- | --- |
| `:app` | Application (composition root), `MainActivity`, manifest |
| `:feature` | Compose screens + ViewModels: home (My Wave), search, player, library, playlists, lyrics, settings |
| `:core` | theme/palette, UI primitives, ExoPlayer + MediaSession service, audio-effects DSP, utils |
| `:data` | Room, DataStore, providers (NewPipe, lrclib, Deezer, Riff server), repositories, WorkManager downloads, imports, export |
| `:domain` | models, text normalisation, queue planner, lyrics parsing/sync, recommendation engine, repository interfaces |

## First run

1. Install and open the app — Discover is empty until you search or play something.
2. Search (YouTube/SoundCloud), then use a track's ⤓ button or its menu → **Download** to keep it offline.
3. Library → **Add files** imports your own audio through the storage picker (no permission needed);
   **Scan device** optionally indexes MediaStore audio (`READ_MEDIA_AUDIO` on Android 13+).
4. Settings → **Backend** can point the app at a running desktop backend:
   `node server.js` on the computer, then `adb reverse tcp:38472 tcp:38472`, and set the URL to
   `http://127.0.0.1:38472`. That mode uses the desktop's yt-dlp/ffmpeg for search, streams and
   downloads; the default *On device* mode needs no computer.
