package com.riff.android.core.player

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.riff.android.core.audio.dsp.RiffEffectState
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.repo.StreamResolver

/**
 * Builds the single ExoPlayer instance used by the playback service.
 *
 * Desktop equivalent: the `<audio>` element plus the AudioContext graph — here the
 * graph is the audio processor chain and the `<audio>` element is ExoPlayer.
 *
 * Deliberate choices:
 *  - `handleAudioFocus = true`: ExoPlayer pauses for calls/other apps (the desktop
 *    relied on the OS media session; the requirement is explicit on Android),
 *  - `setHandleAudioBecomingNoisy(true)`: pause when headphones are unplugged —
 *    Media3's built-in equivalent of the desktop's `navigator.mediaSession` dance,
 *  - `WifiLock`/`WakeMode.NETWORK`: keeps streaming alive in the background like
 *    Electron's power-save blocker did.
 */
@UnstableApi
object RiffPlayerFactory {

    fun create(
        context: Context,
        effectState: RiffEffectState,
        library: LibraryRepository,
        streamResolver: StreamResolver,
    ): ExoPlayer {
        val dataSourceFactory = ResolvingDataSource.Factory(
            DefaultDataSource.Factory(context),
            RiffUriResolver(library, streamResolver),
        )

        val mediaSourceFactory = DefaultMediaSourceFactory(context)
            .setDataSourceFactory(dataSourceFactory)

        val renderersFactory = RiffRenderersFactory(context, effectState)

        return ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
    }
}
