package com.riff.android.core.player

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.riff.android.core.audio.dsp.RiffAudioProcessorChain
import com.riff.android.core.audio.dsp.RiffEffectState

/**
 * Injects Riff's DSP chain into ExoPlayer's audio sink.
 *
 * This is the Android counterpart of building the Web Audio graph in
 * `audio-engine.js`: `DefaultAudioSink.Builder.setAudioProcessorChain(...)` is the
 * only supported insertion point for custom sample processing, and it runs on the
 * playback thread (never on the UI thread).
 */
@UnstableApi
class RiffRenderersFactory(
    context: Context,
    private val effectState: RiffEffectState,
) : DefaultRenderersFactory(context) {

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean,
    ): AudioSink = DefaultAudioSink.Builder(context)
        .setAudioProcessorChain(RiffAudioProcessorChain(effectState))
        // Keep float output for accuracy; fall back automatically on devices that
        // cannot do it (Media3 handles the negotiation).
        .setEnableFloatOutput(enableFloatOutput)
        // PlaybackParameters (speed/pitch) are applied by SonicAudioProcessor inside
        // the chain, so AudioTrack-level params stay off: the desktop also changed
        // `playbackRate` in the graph rather than delegating to the OS.
        .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
        .build()
}
