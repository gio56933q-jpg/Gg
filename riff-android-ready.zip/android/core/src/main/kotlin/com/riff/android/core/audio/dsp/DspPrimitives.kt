package com.riff.android.core.audio.dsp

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.tan

/**
 * Small DSP building blocks used by the Riff audio processors.
 *
 * These replace the Web Audio nodes the desktop engine builds in
 * `audio-engine.js` (`BiquadFilterNode`, `WaveShaperNode`, `ConvolverNode`,
 * `DynamicsCompressorNode`, `DelayNode`).
 */

/** RBJ cookbook biquad with per-channel state (port of `createBiquadFilter` usage). */
class BiquadFilter(private val channels: Int) {
    private val x1 = FloatArray(channels)
    private val x2 = FloatArray(channels)
    private val y1 = FloatArray(channels)
    private val y2 = FloatArray(channels)

    private var b0 = 1f
    private var b1 = 0f
    private var b2 = 0f
    private var a1 = 0f
    private var a2 = 0f

    var gainDb: Float = 0f
        private set

    fun setLowShelf(sampleRate: Int, freqHz: Float, gainDb: Float) {
        this.gainDb = gainDb
        val a = 10f.pow(gainDb / 40f)
        val w0 = 2.0 * PI * (freqHz / sampleRate).toDouble()
        val cosW0 = kotlin.math.cos(w0)
        val alpha = kotlin.math.sin(w0) / 2.0 * kotlin.math.sqrt(2.0)
        val beta = 2.0 * kotlin.math.sqrt(a.toDouble()) * alpha
        val a0 = (a + 1) + (a - 1) * cosW0 + beta
        b0 = (a * ((a + 1) - (a - 1) * cosW0 + beta) / a0).toFloat()
        b1 = (2 * a * ((a - 1) - (a + 1) * cosW0) / a0).toFloat()
        b2 = (a * ((a + 1) - (a - 1) * cosW0 - beta) / a0).toFloat()
        a1 = (-2 * ((a - 1) + (a + 1) * cosW0) / a0).toFloat()
        a2 = (((a + 1) + (a - 1) * cosW0 - beta) / a0).toFloat()
    }

    fun setHighShelf(sampleRate: Int, freqHz: Float, gainDb: Float) {
        this.gainDb = gainDb
        val a = 10f.pow(gainDb / 40f)
        val w0 = 2.0 * PI * (freqHz / sampleRate).toDouble()
        val cosW0 = kotlin.math.cos(w0)
        val alpha = kotlin.math.sin(w0) / 2.0 * kotlin.math.sqrt(2.0)
        val beta = 2.0 * kotlin.math.sqrt(a.toDouble()) * alpha
        val a0 = (a + 1) - (a - 1) * cosW0 + beta
        b0 = (a * ((a + 1) + (a - 1) * cosW0 + beta) / a0).toFloat()
        b1 = (-2 * a * ((a - 1) + (a + 1) * cosW0) / a0).toFloat()
        b2 = (a * ((a + 1) + (a - 1) * cosW0 - beta) / a0).toFloat()
        a1 = (2 * ((a - 1) - (a + 1) * cosW0) / a0).toFloat()
        a2 = (((a + 1) - (a - 1) * cosW0 - beta) / a0).toFloat()
    }

    fun setPeaking(sampleRate: Int, freqHz: Float, q: Float, gainDb: Float) {
        this.gainDb = gainDb
        val a = 10f.pow(gainDb / 40f)
        val w0 = 2.0 * PI * (freqHz / sampleRate).toDouble()
        val cosW0 = kotlin.math.cos(w0)
        val alpha = kotlin.math.sin(w0) / (2.0 * q)
        val a0 = 1 + alpha / a
        b0 = ((1 + alpha * a) / a0).toFloat()
        b1 = ((-2 * cosW0) / a0).toFloat()
        b2 = ((1 - alpha * a) / a0).toFloat()
        a1 = ((-2 * cosW0) / a0).toFloat()
        a2 = ((1 - alpha / a) / a0).toFloat()
    }

    fun processSample(channel: Int, input: Float): Float {
        val out = b0 * input + b1 * x1[channel] + b2 * x2[channel] - a1 * y1[channel] - a2 * y2[channel]
        x2[channel] = x1[channel]
        x1[channel] = input
        y2[channel] = y1[channel]
        y1[channel] = out
        return out
    }

    fun reset() {
        x1.fill(0f); x2.fill(0f); y1.fill(0f); y2.fill(0f)
    }
}

/**
 * Exact port of `_makeDistortionCurve(amount)` (audio-engine.js).
 *
 * The desktop code builds a 256 point curve:
 * `k = amount * 2.5; curve[i] = ((3 + k) * x * 20 * PI/180) / (PI + k * |x|)`
 * and Web Audio interpolates linearly between the points — reproduced here.
 */
class WaveshaperCurve private constructor(private val curve: FloatArray) {

    fun shape(x: Float): Float {
        val clamped = x.coerceIn(-1f, 1f)
        // Map [-1, 1] onto [0, N-1] exactly like Web Audio's WaveShaper.
        val position = (clamped + 1f) * 0.5f * (curve.size - 1)
        val index = position.toInt()
        if (index >= curve.size - 1) return curve[curve.size - 1]
        val frac = position - index
        return curve[index] * (1f - frac) + curve[index + 1] * frac
    }

    companion object {
        private const val SIZE = 256

        /** `_makeDistortionCurve(amount)` — amount 0..100 from the UI. */
        fun distortion(amount: Float): WaveshaperCurve {
            val curve = FloatArray(SIZE)
            val k = amount * 2.5f
            for (i in 0 until SIZE) {
                val x = (i * 2f) / SIZE - 1f
                curve[i] = if (k <= 0f) {
                    x
                } else {
                    ((3f + k) * x * 20f * (PI.toFloat() / 180f)) /
                        (PI.toFloat() + k * abs(x))
                }
            }
            return WaveshaperCurve(curve)
        }

        /** `_makeHarmonicCurve(amount)` — `curve[i] = x - k * x^3` with `k = amount * 0.02`. */
        fun harmonic(amount: Float): WaveshaperCurve {
            val curve = FloatArray(SIZE)
            val k = amount * 0.02f
            for (i in 0 until SIZE) {
                val x = (i * 2f) / SIZE - 1f
                curve[i] = x - k * x * x * x
            }
            return WaveshaperCurve(curve)
        }

        /**
         * True passthrough. The desktop's distortion/harmonic curves use Web Audio's
         * `i*2/n - 1` table convention (so full scale is never a table entry); the
         * identity curve is defined on `i*2/(n-1) - 1` instead so that ±1.0 map exactly
         * and a bypassed waveshaper cannot alter the signal.
         */
        fun identity(): WaveshaperCurve = WaveshaperCurve(FloatArray(SIZE) { (it * 2f) / (SIZE - 1) - 1f })
    }
}

/**
 * Fractional-free circular delay line (port of the `DelayNode` + feedback gain pair
 * in the standard effects chain: `delay 0.3s`, `feedback 0.35`).
 */
class DelayLine(private val channels: Int, maxDelaySeconds: Float, sampleRate: Int) {
    private val length = maxOf(1, (maxDelaySeconds * sampleRate).toInt())
    private val buffers = Array(channels) { FloatArray(length) }
    private var writeIndex = 0

    fun process(channel: Int, input: Float, delaySamples: Int, feedback: Float): Float {
        val readIndex = (writeIndex - delaySamples + length) % length
        val delayed = buffers[channel][readIndex]
        buffers[channel][writeIndex] = input + delayed * feedback
        return delayed
    }

    fun advance() {
        writeIndex = (writeIndex + 1) % length
    }

    fun reset() {
        buffers.forEach { it.fill(0f) }
        writeIndex = 0
    }
}

/**
 * Schroeder-style reverb (8 combs + 4 allpasses, Freeverb tunings).
 *
 * Desktop uses a `ConvolverNode` with a synthetic 0.6 s exponentially decaying
 * noise impulse (`_createReverbImpulse`). True convolution is far too expensive
 * per-sample on a phone, so an algorithmic reverb with Freeverb's classic
 * tunings is used instead; the wet amount keeps the same `amount / 100` mapping.
 * Documented in android/PORTING.md.
 */
class Freeverb(private val channels: Int, sampleRate: Int) {
    private val scale = sampleRate / 44100f

    private val combTuning = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val allpassTuning = intArrayOf(556, 441, 341, 225)
    private val stereoSpread = 23

    private val combBuffers: Array<Array<FloatArray>> = Array(channels) { ch ->
        Array(combTuning.size) { i ->
            val size = ((combTuning[i] + ch * stereoSpread) * scale).toInt().coerceAtLeast(1)
            FloatArray(size)
        }
    }
    private val combIndices = Array(channels) { IntArray(combTuning.size) }
    private val combFilters = Array(channels) { FloatArray(combTuning.size) }

    private val allpassBuffers: Array<Array<FloatArray>> = Array(channels) { ch ->
        Array(allpassTuning.size) { i ->
            val size = ((allpassTuning[i] + ch * stereoSpread) * scale).toInt().coerceAtLeast(1)
            FloatArray(size)
        }
    }
    private val allpassIndices = Array(channels) { IntArray(allpassTuning.size) }

    private val feedback = 0.84f
    private val damping = 0.28f
    private val allpassFeedback = 0.5f

    fun process(channel: Int, input: Float): Float {
        var out = 0f
        for (i in combTuning.indices) {
            val buffer = combBuffers[channel][i]
            val index = combIndices[channel][i]
            val output = buffer[index]
            out += output
            combFilters[channel][i] = output * (1f - damping) + combFilters[channel][i] * damping
            buffer[index] = input + combFilters[channel][i] * feedback
            combIndices[channel][i] = (index + 1) % buffer.size
        }
        out /= combTuning.size

        for (i in allpassTuning.indices) {
            val buffer = allpassBuffers[channel][i]
            val index = allpassIndices[channel][i]
            val buffered = buffer[index]
            val output = -out + buffered
            buffer[index] = out + buffered * allpassFeedback
            allpassIndices[channel][i] = (index + 1) % buffer.size
            out = output
        }
        return out
    }

    fun reset() {
        combBuffers.forEach { ch -> ch.forEach { it.fill(0f) } }
        allpassBuffers.forEach { ch -> ch.forEach { it.fill(0f) } }
        combFilters.forEach { it.fill(0f) }
        combIndices.forEach { it.fill(0) }
        allpassIndices.forEach { it.fill(0) }
    }
}

/**
 * Feed-forward compressor with soft knee + one-pole gain smoothing.
 *
 * Port of the `DynamicsCompressorNode` settings used by the HQ chain and the
 * limiter (`threshold -1 dB`, `ratio 20`), see `_applyHqParams()`.
 */
class DynamicsProcessor(private val channels: Int) {
    var thresholdDb: Float = -12f
    var kneeDb: Float = 10f
    var ratio: Float = 1.5f
    var attackMs: Float = 10f
    var releaseMs: Float = 100f
    var makeupDb: Float = 0f

    private var attackCoef = 0.99f
    private var releaseCoef = 0.999f
    private var envelope = 1f

    fun configure(sampleRate: Int) {
        attackCoef = exp(-1f / (0.001f * attackMs * sampleRate)).coerceIn(0f, 1f)
        releaseCoef = exp(-1f / (0.001f * releaseMs * sampleRate)).coerceIn(0f, 1f)
    }

    fun processFrame(input: FloatArray): Float {
        var peak = 0f
        for (ch in 0 until channels) {
            val magnitude = abs(input[ch])
            if (magnitude > peak) peak = magnitude
        }

        val target = if (peak > 1e-6f) {
            val levelDb = 20f * kotlin.math.log10(peak)
            val overDb = levelDb - thresholdDb
            if (overDb <= -kneeDb / 2f) {
                1f
            } else {
                val compressedDb = if (overDb < kneeDb / 2f) {
                    // Quadratic soft knee (same shape as the Web Audio compressor).
                    val x = overDb + kneeDb / 2f
                    overDb - ((1f - 1f / ratio) * x * x) / (2f * kneeDb)
                } else {
                    overDb / ratio
                }
                10f.pow((compressedDb - overDb) / 20f)
            }
        } else {
            1f
        }

        val coef = if (target < envelope) attackCoef else releaseCoef
        envelope = target + (envelope - target) * coef

        val gain = envelope * 10f.pow(makeupDb / 20f)
        for (ch in 0 until channels) input[ch] *= gain
        return gain
    }

    fun reset() {
        envelope = 1f
    }
}
