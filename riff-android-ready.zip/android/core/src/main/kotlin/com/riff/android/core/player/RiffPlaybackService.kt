package com.riff.android.core.player

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.riff.android.core.R
import com.riff.android.core.audio.dsp.RiffEffectState
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.PlaybackSnapshot
import com.riff.android.domain.model.RepeatMode
import com.riff.android.domain.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Implemented by the app's `Application` (see `RiffApplication` in `:app`). */
interface RiffServiceHost {
    val container: RiffContainer
    /** Shared DSP state; must be the same instance the AudioEffectsController writes to. */
    val effectsState: RiffEffectState
    /** Small icon for the media notification. */
    val notificationIconRes: Int
    /** Scope that lives as long as the process (not tied to any Activity). */
    val applicationScope: CoroutineScope
}

/**
 * Background playback host — the Android replacement for the desktop app's
 * always-running renderer process with `<audio>` + `navigator.mediaSession`.
 *
 * Responsibilities (nothing long-running lives in an Activity):
 *  - owns the single [ExoPlayer] + [MediaSession] (notification, lockscreen, Bluetooth,
 *    media buttons and audio focus all come from Media3),
 *  - restores the queue/position after process death from Room (the desktop only
 *    resumed history; the task explicitly requires resume, so the state is persisted),
 *  - persists the session periodically and on every queue change,
 *  - records plays into history,
 *  - auto-extends My Wave near the end of the queue, exactly like `playNext()` in app.js.
 */
@UnstableApi
class RiffPlaybackService : MediaSessionService() {

    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var persistJob: Job? = null
    private var restoreJob: Job? = null
    private var restoring = false

    private val host: RiffServiceHost?
        get() = application as? RiffServiceHost

    private val container: RiffContainer?
        get() = host?.container

    override fun onCreate() {
        super.onCreate()
        val app = applicationContext
        val hostRef = host ?: run {
            // Without the app container the service cannot resolve streams; bail out loudly.
            stopSelf()
            return
        }

        val exoPlayer = RiffPlayerFactory.create(
            context = app,
            effectState = hostRef.effectsState,
            library = hostRef.container.library,
            streamResolver = hostRef.container.streamResolver,
        )
        player = exoPlayer

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(app)
                .setChannelId(NOTIFICATION_CHANNEL_ID)
                .setChannelName(R.string.riff_playback_channel)
                .setNotificationId(NOTIFICATION_ID)
                .build()
                .also { it.setSmallIcon(hostRef.notificationIconRes) },
        )

        val sessionActivity = app.packageManager.getLaunchIntentForPackage(app.packageName)?.let { intent ->
            intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            PendingIntent.getActivity(
                app,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        }

        mediaSession = MediaSession.Builder(app, exoPlayer).apply {
            sessionActivity?.let { setSessionActivity(it) }
        }.build()

        exoPlayer.addListener(playerListener)
        exoPlayer.repeatMode = Player.REPEAT_MODE_OFF

        restoreQueue()

        persistJob = scope.launch {
            while (true) {
                delay(PERSIST_INTERVAL_MS)
                persistQueue()
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Desktop parity: closing the window stopped playback. Keeping the process
        // alive with an empty queue serves no purpose, so the service stops itself.
        val player = this.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        restoreJob?.cancel()
        persistJob?.cancel()
        persistQueue(synchronous = true)
        mediaSession?.run {
            player.release()
            release()
        }
        scope.cancel()
        mediaSession = null
        player = null
        super.onDestroy()
    }

    // --- restore / persist --------------------------------------------------

    private fun restoreQueue() {
        restoreJob = scope.launch {
            val container = container ?: return@launch
            val snapshot = runCatching { container.playbackState.observe().first() }.getOrNull() ?: return@launch
            if (snapshot.queueIds.isEmpty() || snapshot.currentTrackId == null) return@launch

            val tracks = runCatching { container.library.getMany(snapshot.queueIds) }.getOrNull().orEmpty()
            if (tracks.isEmpty()) return@launch

            val index = snapshot.queueIndex.coerceIn(0, tracks.lastIndex)
            restoring = true
            val context = inferContext(tracks)
            val items = tracks.map { RiffMediaItems.toMediaItem(it, context, waveActive = context is PlaybackContext.MyWave) }

            player?.apply {
                setMediaItems(items, index, snapshot.positionMs)
                repeatMode = when (snapshot.repeatMode) {
                    RepeatMode.ONE -> Player.REPEAT_MODE_ONE
                    RepeatMode.ALL -> Player.REPEAT_MODE_ALL
                    RepeatMode.OFF -> Player.REPEAT_MODE_OFF
                }
                shuffleModeEnabled = snapshot.shuffle
                prepare()
                // Never auto-play after a restore: the user presses play (the desktop
                // app also needed a gesture before the audio element could start).
                playWhenReady = false
            }
            restoring = false
        }
    }

    /**
     * The queue context is not part of the snapshot, so it is inferred the same way
     * the UI labels queues: a My Wave queue is one whose items carry the wave flag.
     */
    private fun inferContext(tracks: List<Track>): PlaybackContext = PlaybackContext.Queue

    private fun persistQueue(synchronous: Boolean = false) {
        val container = container ?: return
        val player = player ?: return
        if (restoring) return
        if (player.mediaItemCount == 0) return

        val queueIds = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).mediaId }
        val snapshot = PlaybackSnapshot(
            currentTrackId = player.currentMediaItem?.mediaId,
            positionMs = player.currentPosition.coerceAtLeast(0L),
            queueIndex = player.currentMediaItemIndex,
            queueIds = queueIds,
            isPlaying = player.isPlaying,
            repeatMode = when (player.repeatMode) {
                Player.REPEAT_MODE_ONE -> RepeatMode.ONE
                Player.REPEAT_MODE_ALL -> RepeatMode.ALL
                else -> RepeatMode.OFF
            },
            shuffle = player.shuffleModeEnabled,
            updatedAt = System.currentTimeMillis(),
        )

        val scope = host?.applicationScope ?: scope
        scope.launch { runCatching { container.playbackState.save(snapshot) } }
    }

    // --- player events ------------------------------------------------------

    private val playerListener = object : Player.Listener {

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            super.onMediaItemTransition(mediaItem, reason)
            if (mediaItem == null) return
            rememberPlayed(mediaItem)
            maybeExtendWave()
            persistQueue()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            super.onIsPlayingChanged(isPlaying)
            persistQueue()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            super.onPlaybackStateChanged(playbackState)
            if (playbackState == Player.STATE_ENDED) {
                // Desktop `ended` handler: `repeat` restarts the track, otherwise advance.
                val player = this@RiffPlaybackService.player ?: return
                if (player.repeatMode == Player.REPEAT_MODE_OFF) {
                    persistQueue()
                }
            }
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            super.onPlayerError(error)
            // Desktop: a failed stream showed an error in the UI and skipped to the
            // next item; keep the queue moving instead of stopping on a dead url.
            val player = this@RiffPlaybackService.player ?: return
            if (player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
            }
        }
    }

    /** Desktop `pushHistory()` + `/api/state`: counted once per track start. */
    private fun rememberPlayed(mediaItem: MediaItem) {
        val container = container ?: return
        val track = RiffMediaItems.toTrack(mediaItem)
        val scope = host?.applicationScope ?: scope
        scope.launch {
            runCatching {
                val stored = container.library.get(track.id)
                container.library.recordPlayed(stored ?: track, System.currentTimeMillis())
            }
        }
    }

    /**
     * Port of `playNext()`'s My Wave branch: when the queue is one of the wave
     * queues and the listener is within the last items, ask the recommendation
     * engine for more tracks and append them (`autoExtendWave` mirrors the
     * `riff_adv_auto_extend` setting).
     */
    private fun maybeExtendWave(force: Boolean = false) {
        val player = player ?: return
        val container = container ?: return
        val currentItem = player.currentMediaItem ?: return
        if (!RiffMediaItems.isWaveActive(currentItem)) return

        val index = player.currentMediaItemIndex
        val size = player.mediaItemCount
        val nearEnd = force || com.riff.android.domain.queue.QueuePlanner.shouldExtendWave(index, size, true)
        if (!nearEnd) return

        val scope = host?.applicationScope ?: scope
        scope.launch {
            val settings = runCatching { container.settings.current() }.getOrNull()
            if (settings?.advanced?.autoExtendWave == false) return@launch

            val result = runCatching {
                container.recommendations.recommend(limit = WAVE_EXTEND_SIZE, extend = true)
            }.getOrNull() ?: return@launch
            if (result.tracks.isEmpty()) return@launch

            container.library.upsertAll(result.tracks)
            player.apply {
                addMediaItems(
                    result.tracks.map { RiffMediaItems.toMediaItem(it, PlaybackContext.MyWave, waveActive = true) },
                )
            }
        }
    }

    companion object {
        const val NOTIFICATION_ID = 10_001
        const val NOTIFICATION_CHANNEL_ID = "riff_playback"
        const val PERSIST_INTERVAL_MS = 5_000L

        /** Desktop `extendMyWaveQueue()` asks `/api/vibe` for `limit: 8`. */
        const val WAVE_EXTEND_SIZE = 8
    }
}
