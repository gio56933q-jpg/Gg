package com.riff.android.core.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.riff.android.domain.model.Track
import com.riff.android.domain.text.TrackText

/**
 * Riff's `.section-header` / `.section-hint` pattern: a title with an optional
 * hint on the right and an optional trailing action.
 */
@Composable
fun RiffSectionHeader(
    title: String,
    hint: String? = null,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
        hint?.let {
            Spacer(Modifier.width(10.dp))
            Text(
                it,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
            )
        }
        Spacer(Modifier.weight(1f))
        trailing?.invoke()
    }
}

/** `.chip-btn` — suggestion chips on the discover page and the small filter chips. */
@Composable
fun RiffChip(
    label: String,
    selected: Boolean = false,
    onClick: () -> Unit,
) {
    val container = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh
    val content = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = container,
        modifier = Modifier.clip(RoundedCornerShape(999.dp)).clickable(onClick = onClick),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = content,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        )
    }
}

/** `.empty-hint` */
@Composable
fun RiffEmptyHint(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 32.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * Riff's M3-ish loading indicator (styles.css `.m3-circular-progress`): a rotating
 * arc in the primary colour.
 */
@Composable
fun RiffSpinner(size: Dp = 40.dp, color: Color = MaterialTheme.colorScheme.primary) {
    androidx.compose.material3.CircularProgressIndicator(
        modifier = Modifier.size(size),
        color = color,
        strokeWidth = 3.dp,
        trackColor = color.copy(alpha = 0.18f),
    )
}

/**
 * The playbar waveform-ish visualiser. The desktop draws a Web Audio analyser
 * (`startVisualizers`); here the bars animate with the play state, since Android
 * does not expose the sink's analyser to the UI process.
 */
@Composable
fun RiffEqualizerBars(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = MaterialTheme.colorScheme.primary,
    bars: Int = 4,
    height: Dp = 18.dp,
) {
    val transition = rememberInfiniteTransition(label = "riff-eq")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        for (index in 0 until bars) {
            val wave = kotlin.math.abs(kotlin.math.sin((phase + index * 0.22f) * 2f * Math.PI.toFloat()))
            val factor = if (isPlaying) 0.35f + wave * 0.65f else 0.25f
            Box(
                Modifier
                    .width(3.dp)
                    .height(height * factor)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isPlaying) barColor else barColor.copy(alpha = 0.4f)),
            )
        }
    }
}

/** Heart button used in track rows and the playbar (`#btn-toggle-fav`). */
@Composable
fun RiffFavoriteButton(favorite: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    androidx.compose.material3.IconButton(onClick = onClick, modifier = modifier) {
        Icon(
            imageVector = if (favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
            contentDescription = if (favorite) "Remove from favorites" else "Add to favorites",
            tint = if (favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * Track row — port of `createTrackRow()`: artwork, title/artist, optional badges
 * (downloaded, current), duration and the favourite/more actions.
 */
@Composable
fun RiffTrackRow(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onFavoriteToggle: (() -> Unit)? = null,
    onMoreClick: (() -> Unit)? = null,
    showIndex: Int? = null,
    isDownloaded: Boolean = track.isDownloaded,
) {
    val background = if (isCurrent) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    val titleColor = if (isCurrent) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        showIndex?.let {
            Text(
                it.toString(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(24.dp),
            )
        }
        RiffArtwork(
            uri = track.artworkUri,
            modifier = Modifier.size(48.dp),
            cornerRadius = 10.dp,
            contentDescription = track.title,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    track.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = titleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (isDownloaded) {
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Filled.DownloadDone,
                            contentDescription = "Downloaded",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(11.dp),
                        )
                    }
                }
            }
            Text(
                buildString {
                    append(track.artist)
                    if (track.album != null && track.album != Track.UNKNOWN_ALBUM) {
                        append(" • ")
                        append(track.album)
                    }
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (isCurrent) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (track.durationMs > 0) {
            Text(
                TrackText.formatDuration(track.durationMs / 1000),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        onFavoriteToggle?.let { RiffFavoriteButton(track.favorite, it) }
        onMoreClick?.let {
            androidx.compose.material3.IconButton(onClick = it) {
                Icon(Icons.Outlined.MoreVert, contentDescription = "More options", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Small pill used for section labels / platform badges (`results-platform-badge`). */
@Composable
fun RiffBadge(text: String, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Surface(
        color = color.copy(alpha = 0.16f),
        shape = RoundedCornerShape(999.dp),
        modifier = modifier,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

/**
 * Subtle "mesh" background — the desktop app paints `#bg-mesh-a/#bg-mesh-b` radial
 * gradients derived from the accent colour. Rendered here with Compose gradients.
 */
@Composable
fun RiffMeshBackground(
    accent: Color,
    accent2: Color,
    brightness: Float,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val base = MaterialTheme.colorScheme.background
    Box(
        modifier.background(
            Brush.radialGradient(
                colors = listOf(
                    accent.copy(alpha = 0.16f * brightness),
                    accent2.copy(alpha = 0.10f * brightness),
                    base.copy(alpha = 0f),
                ),
                radius = 1400f,
            ),
        ),
    ) {
        Box(
            Modifier.background(
                Brush.verticalGradient(
                    listOf(base.copy(alpha = 0.0f), base.copy(alpha = 0.55f)),
                ),
            ),
        )
        content()
    }
}

/** Thin progress line used by the mini player (desktop scrubber bar). */
@Composable
fun RiffProgressLine(progress: Float, modifier: Modifier = Modifier, height: Dp = 3.dp) {
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
    ) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(height)
                .background(MaterialTheme.colorScheme.primary),
        )
    }
}

/** Outlined pill button (`.btn-outline-pill`). */
@Composable
fun RiffOutlinedPill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = Color.Transparent,
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick),
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
    }
}
