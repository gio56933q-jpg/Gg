package com.riff.android.core.audio.dsp

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.tanh

/**
 * Riff's audio effects as Media3 [AudioProcessor]s.
 *
 * Desktop equivalent: the Web Audio graph built in `audio-engine.js`
 * (`initAudioGraph()`), split into a standard chain
 *
 *     source -> dry -> distortion(WaveShaper) -> delay(0.3 s, fb .35) -> convolver -> gain
 *
 * and the HQ chain
 *
 *     source -> compressor -> lowshelf(80) -> peaking(2500, Q1.2) -> highshelf(9000)
 *            -> saturation -> limiter -> gain
 *
 * Everything is processed on ExoPlayer's playback thread inside the audio sink, so
 * the UI process never touches sample data.
 *
 * Fidelity notes (also documented in android/PORTING.md):
 *  - the desktop convolution reverb uses an impulse response generated in JS
 *    (`.6 s` decaying noise). Android cannot run `ConvolverNode`; the port uses the
 *    classic Freeverb comb/allpass network with equivalent wet/dry balance and decay.
 *  - the HQ saturation uses the same `tanh` curve as the desktop `WaveShaperNode`.
 *  - the HQ compressor/limiter are feed-forward designs with the desktop's
 *    threshold/ratio/attack/release numbers; Media3 does not expose a compressor.
 */
@UnstableApi
object RiffSampleMath {
    /** Desktop `WaveShaperNode` curve: `tanh(x * k) / tanh(k)`. */
    fun saturate(sample: Float, k: Float): Float {
        if (k <= 0f) return sample
        val norm = tanh(k)
        if (norm == 0f) return sample
        return (tanh(sample * k) / norm).coerceIn(-1.5f, 1.5f)
    }
}

/**
 * Distortion (`state.audioSettings.distortion`, 0..100).
 * Desktop: waveshaper with `k = 3 + distortion/100 * 12` and a -0.75 drive compensation.
 */
@UnstableApi
class RiffOverdriveProcessor(
    private val state: RiffEffectState,
) : BaseAudioProcessor() {

    private var channels = 1

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        channels = inputAudioFormat.channelCount
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val sampleCount = inputBuffer.remaining() / 2 // 16-bit PCM
        if (sampleCount == 0) return

        val amount = state.distortionWet
        val output = replaceOutputBuffer(inputBuffer.remaining())
        if (amount <= 0f) {
            output.put(inputBuffer)
            output.flip()
            return
        }

        val drive = 3f + amount * 12f
        val compensation = 1f - 0.35f * amount
        val shorts = ShortArray(sampleCount)
        inputBuffer.asShortBuffer().get(shorts)

        val processed = ShortArray(sampleCount)
        for (index in 0 until sampleCount) {
            val sample = shorts[index] / 32768f * compensation
            val saturated = RiffSampleMath.saturate(sample, drive)
            processed[index] = (saturated.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        output.asShortBuffer().put(processed)
        output.position(output.position() + sampleCount * 2)
        output.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun onReset() {
        channels = 1
    }
}

/**
 * Echo / delay (`audioSettings.echo`). Desktop: `DelayNode` with `maxDelayTime = 1.0`,
 * `delayTime = 0.3`, feedback `0.35`, wet = `echo/100`.
 */
@UnstableApi
class RiffDelayProcessor(
    private val state: RiffEffectState,
) : BaseAudioProcessor() {

    private var sampleRate = 44_100
    private var channels = 2
    private var buffers: Array<FloatArray> = emptyArray()
    private var writeIndex = 0
    private var delaySamples = 13_230

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        delaySamples = (DELAY_SECONDS * sampleRate).toInt().coerceAtLeast(1)
        buffers = Array(channels) { FloatArray(delaySamples) }
        writeIndex = 0
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val sampleCount = inputBuffer.remaining() / 2
        if (sampleCount == 0) return
        val output = replaceOutputBuffer(inputBuffer.remaining())

        val amount = state.echoWet
        if (amount <= 0f) {
            output.put(inputBuffer)
            output.flip()
            return
        }

        val shorts = ShortArray(sampleCount)
        inputBuffer.asShortBuffer().get(shorts)
        val processed = ShortArray(sampleCount)
        for (index in 0 until sampleCount) {
            val channel = index % channels
            val input = shorts[index] / 32768f
            val delayed = buffers[channel][writeIndex]
            buffers[channel][writeIndex] = input + delayed * FEEDBACK
            val mixed = input * (1f - amount) + delayed * amount
            processed[index] = (mixed.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            if (channel == channels - 1) {
                writeIndex = (writeIndex + 1) % delaySamples
            }
        }
        output.asShortBuffer().put(processed)
        output.position(output.position() + sampleCount * 2)
        output.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun onFlush() {
        buffers.forEach { it.fill(0f) }
        writeIndex = 0
    }

    override fun onReset() {
        buffers = emptyArray()
        writeIndex = 0
    }

    private companion object {
        const val DELAY_SECONDS = 0.3f
        const val FEEDBACK = 0.35f
    }
}

/**
 * Reverb (`audioSettings.reverb`).
 *
 * Desktop: `ConvolverNode` with a `.6 s` exponentially decaying noise impulse.
 * Android has no convolution node, so this is a Freeverb-style network: 8 parallel
 * combs + 4 series allpasses per channel with the classic tunings, and the wet/dry
 * mix driven by `reverb/100`.
 */
@UnstableApi
class RiffReverbProcessor(
    private val state: RiffEffectState,
) : BaseAudioProcessor() {

    private var sampleRate = 44_100
    private var channels = 2
    private var combs: Array<Array<Comb>> = emptyArray()
    private var allpasses: Array<Array<Allpass>> = emptyArray()
    private var damping = 0.28f
    private var feedback = 0.84f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        buildNetwork()
        return inputAudioFormat
    }

    private fun buildNetwork() {
        val scale = sampleRate / 44_100f
        combs = Array(channels) { channel ->
            COMB_TUNINGS.map { tuning ->
                Comb((tuning * scale).toInt().coerceAtLeast(1), channel)
            }.toTypedArray()
        }
        allpasses = Array(channels) { channel ->
            ALLPASS_TUNINGS.map { tuning ->
                Allpass((tuning * scale).toInt().coerceAtLeast(1), channel)
            }.toTypedArray()
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val sampleCount = inputBuffer.remaining() / 2
        if (sampleCount == 0) return
        val output = replaceOutputBuffer(inputBuffer.remaining())

        val amount = state.reverbWet
        if (amount <= 0f) {
            output.put(inputBuffer)
            output.flip()
            return
        }

        val shorts = ShortArray(sampleCount)
        inputBuffer.asShortBuffer().get(shorts)
        val processed = ShortArray(sampleCount)
        val wetScale = amount * 1.05f
        val dryScale = 1f - 0.3f * amount

        for (index in 0 until sampleCount) {
            val channel = (index % channels).coerceAtMost(combs.lastIndex)
            val input = shorts[index] / 32768f

            var wet = 0f
            val channelCombs = combs[channel]
            for (comb in channelCombs) {
                wet += comb.process(input, feedback, damping)
            }
            wet /= channelCombs.size

            var tail = wet
            for (allpass in allpasses[channel]) {
                tail = allpass.process(tail)
            }

            val mixed = input * dryScale + tail * wetScale
            processed[index] = (mixed.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }

        output.asShortBuffer().put(processed)
        output.position(output.position() + sampleCount * 2)
        output.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun onFlush() {
        combs.forEach { channel -> channel.forEach { it.clear() } }
        allpasses.forEach { channel -> channel.forEach { it.clear() } }
    }

    override fun onReset() {
        combs = emptyArray()
        allpasses = emptyArray()
    }

    private class Comb(size: Int, seed: Int) {
        private val buffer = FloatArray(size)
        private var index = 0
        private var filterState = 0f

        init {
            // Desktop impulse is noise; desynchronise the combs like Freeverb's `spread`.
            var state = (seed + 1) * 2_000_011
            for (i in buffer.indices) {
                state = state * 1_103_515_245 + 12_345
                buffer[i] = ((state ushr 16) and 0x7FFF) / 32768f * 0.4f
            }
        }

        fun process(input: Float, feedback: Float, damping: Float): Float {
            val output = buffer[index]
            filterState = output * (1f - damping) + filterState * damping
            buffer[index] = input + filterState * feedback
            index = (index + 1) % buffer.size
            return output
        }

        fun clear() {
            buffer.fill(0f)
            filterState = 0f
        }
    }

    private class Allpass(size: Int, seed: Int) {
        private val buffer = FloatArray(size)
        private var index = 0
        private var feedback = 0.5f + (seed % 3) * 0.02f

        fun process(input: Float): Float {
            val buffered = buffer[index]
            val output = -input + buffered
            buffer[index] = input + buffered * feedback
            index = (index + 1) % buffer.size
            return output
        }

        fun clear() {
            buffer.fill(0f)
        }
    }

    private companion object {
        /** Freeverb tunings at 44.1 kHz, scaled to the actual sample rate. */
        val COMB_TUNINGS = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
        val ALLPASS_TUNINGS = intArrayOf(556, 441, 341, 225)
    }
}

/**
 * HQ chain: compressor -> lowshelf 80 Hz -> peaking 2.5 kHz -> highshelf 9 kHz ->
 * saturation -> limiter, driven by `hqSettings` (vocal/air/bass knobs, engine preset).
 * Desktop: `_buildHqChain()` in `audio-engine.js`.
 */
@UnstableApi
class RiffHqProcessor(
    private val state: RiffEffectState,
) : BaseAudioProcessor() {

    private var channels = 2
    private var sampleRate = 44_100
    private val bassFilters = mutableListOf<RiffBiquad>()
    private val vocalFilters = mutableListOf<RiffBiquad>()
    private val airFilters = mutableListOf<RiffBiquad>()
    private var envelope = 0f
    private var limiterEnvelope = 0f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        channels = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate
        bassFilters.clear()
        vocalFilters.clear()
        airFilters.clear()
        repeat(channels) {
            bassFilters += RiffBiquad()
            vocalFilters += RiffBiquad()
            airFilters += RiffBiquad()
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val sampleCount = inputBuffer.remaining() / 2
        if (sampleCount == 0) return
        val output = replaceOutputBuffer(inputBuffer.remaining())

        if (!state.hqEnabled) {
            output.put(inputBuffer)
            output.flip()
            return
        }

        val hq = state.hq
        val preset = HQ_PRESETS[hq.preset] ?: HQ_PRESETS.getValue("studio")
        val bassDb = applyEngine(HQ_BASS_BASE_DB + hq.bass * KNOB_DB_PER_UNIT, HQ_MIN_DB, HQ_MAX_DB, preset.bassScale)
        val vocalDb = applyEngine(HQ_VOCAL_BASE_DB + hq.vocal * KNOB_DB_PER_UNIT, HQ_MIN_DB, HQ_MAX_DB, preset.vocalScale)
        val airDb = applyEngine(HQ_AIR_BASE_DB + hq.air * KNOB_DB_PER_UNIT, HQ_MIN_DB, HQ_MAX_DB, preset.airScale)

        for (channel in 0 until channels) {
            bassFilters[channel].configure(RiffBiquad.Type.LOW_SHELF, sampleRate, 80f, gainDb = bassDb)
            vocalFilters[channel].configure(RiffBiquad.Type.PEAKING, sampleRate, 2500f, q = 1.2f, gainDb = vocalDb)
            airFilters[channel].configure(RiffBiquad.Type.HIGH_SHELF, sampleRate, 9000f, gainDb = airDb)
        }

        val shorts = ShortArray(sampleCount)
        inputBuffer.asShortBuffer().get(shorts)
        val processed = ShortArray(sampleCount)

        val attack = exp(-1f / (COMPRESSOR_ATTACK_S * sampleRate)).coerceIn(0f, 0.9999f)
        val release = exp(-1f / (COMPRESSOR_RELEASE_S * sampleRate)).coerceIn(0f, 0.9999f)

        for (index in 0 until sampleCount) {
            val channel = index % channels
            var sample = shorts[index] / 32768f

            // Compressor (feed-forward, peak detector, hard knee)
            val level = abs(sample)
            envelope = if (level > envelope) attack * envelope + (1 - attack) * level
            else release * envelope + (1 - release) * level
            val envelopeDb = 20f * kotlin.math.log10(max(envelope, 1e-6f))
            if (envelopeDb > COMPRESSOR_THRESHOLD_DB) {
                val compressedDb = COMPRESSOR_THRESHOLD_DB +
                    (envelopeDb - COMPRESSOR_THRESHOLD_DB) / COMPRESSOR_RATIO
                sample *= 10f.pow((compressedDb - envelopeDb) / 20f)
            }

            sample = bassFilters[channel].processSafe(sample)
            sample = vocalFilters[channel].processSafe(sample)
            sample = airFilters[channel].processSafe(sample)
            sample = RiffSampleMath.saturate(sample, HQ_SATURATION_K)
            sample = max(-1.2f, min(1.2f, sample))
            sample *= preset.outputGain

            // Limiter (-1 dBFS, 20:1, fast attack, 50 ms release)
            val limitedLevel = abs(sample)
            limiterEnvelope = if (limitedLevel > limiterEnvelope) 0.6f * limiterEnvelope + 0.4f * limitedLevel
            else 0.999f * limiterEnvelope + 0.001f * limitedLevel
            val limiterDb = 20f * kotlin.math.log10(max(limiterEnvelope, 1e-6f))
            if (limiterDb > LIMITER_THRESHOLD_DB) {
                val limitedDb = LIMITER_THRESHOLD_DB + (limiterDb - LIMITER_THRESHOLD_DB) / LIMITER_RATIO
                sample *= 10f.pow((limitedDb - limiterDb) / 20f)
            }

            processed[index] = (sample.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }

        output.asShortBuffer().put(processed)
        output.position(output.position() + sampleCount * 2)
        output.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun onFlush() {
        envelope = 0f
        limiterEnvelope = 0f
        bassFilters.forEach { it.reset() }
        vocalFilters.forEach { it.reset() }
        airFilters.forEach { it.reset() }
    }

    override fun onReset() {
        bassFilters.clear()
        vocalFilters.clear()
        airFilters.clear()
    }

    private fun applyEngine(base: Float, minDb: Float, maxDb: Float, scale: Float): Float =
        (base * scale).coerceIn(minDb, maxDb)

    /** Engine differences from `audio-engine.js` (`hqmusic-3`, `glyphs-7B`, `fyro1.1`). */
    private data class HqPreset(val bassScale: Float, val vocalScale: Float, val airScale: Float, val outputGain: Float)

    private val HQ_PRESETS = mapOf(
        "studio" to HqPreset(1f, 1f, 1f, 1f),
        "vinyl" to HqPreset(1.15f, 0.85f, 0.7f, 1.02f),
        "concert" to HqPreset(1.05f, 1.25f, 1.15f, 0.98f),
    )

    private companion object {
        const val COMPRESSOR_THRESHOLD_DB = -12f
        const val COMPRESSOR_RATIO = 1.5f
        const val COMPRESSOR_ATTACK_S = 0.01f
        const val COMPRESSOR_RELEASE_S = 0.1f
        const val LIMITER_THRESHOLD_DB = -1f
        const val LIMITER_RATIO = 20f
        const val HQ_SATURATION_K = 4f
        const val HQ_MIN_DB = -12f
        const val HQ_MAX_DB = 12f
        const val HQ_BASS_BASE_DB = 3f
        const val HQ_VOCAL_BASE_DB = 0f
        const val HQ_AIR_BASE_DB = 2.5f

        /** Desktop: one knob step = 0.08 * 100 units -> ±4 dB at the extremes. */
        const val KNOB_DB_PER_UNIT = 0.08f
    }
}

/**
 * Preset gain (`audioSettings.volume`, the desktop "gain" node). Applied last so the
 * preset boost is not squashed by the limiter, matching the desktop graph order.
 */
@UnstableApi
class RiffGainProcessor(
    private val state: RiffEffectState,
) : BaseAudioProcessor() {

    private var currentGain = 1f

    override fun queueInput(inputBuffer: ByteBuffer) {
        val sampleCount = inputBuffer.remaining() / 2
        if (sampleCount == 0) return
        val output = replaceOutputBuffer(inputBuffer.remaining())

        val target = state.presetGain
        if (abs(target - currentGain) < 0.001f && abs(target - 1f) < 0.001f) {
            output.put(inputBuffer)
            output.flip()
            return
        }

        val shorts = ShortArray(sampleCount)
        inputBuffer.asShortBuffer().get(shorts)
        val processed = ShortArray(sampleCount)
        // Smooth over ~50 ms (desktop ramps gain exponentially as well).
        val step = (target - currentGain) / max(1f, sampleCount / 4f)
        for (index in 0 until sampleCount) {
            currentGain = if (abs(target - currentGain) < abs(step)) target else currentGain + step
            val value = shorts[index] / 32768f * currentGain
            processed[index] = (value.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        output.asShortBuffer().put(processed)
        output.position(output.position() + sampleCount * 2)
        output.flip()
        inputBuffer.position(inputBuffer.limit())
    }

    override fun onFlush() {
        currentGain = 1f
    }
}

/** Constants shared with the unit tests. */
object RiffDspDefaults {
    const val SAMPLE_RATE = 44_100
    const val CHANNEL_COUNT = 2
    const val C_ENCODING = C.ENCODING_PCM_16BIT
}
