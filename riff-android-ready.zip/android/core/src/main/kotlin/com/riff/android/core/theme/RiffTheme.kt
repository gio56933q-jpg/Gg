package com.riff.android.core.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.riff.android.domain.model.PaletteStyle
import com.riff.android.domain.model.RiffSettings
import com.riff.android.domain.model.ThemeMode

/**
 * The generated palette, exposed to any composable that needs the raw desktop
 * tokens (e.g. `primaryContainer` before it is composited onto a surface).
 */
val LocalRiffColors = staticCompositionLocalOf {
    RiffPalette.generate(RiffPalette.SEED, ThemeMode.DARK, 0, 50, PaletteStyle.CLASSIC)
}

/**
 * Riff's Material 3 theme.
 *
 * Desktop equivalent: `generateM3Palette()` writing `--md-sys-color-*` into
 * `:root` (styles.css). Here the same generated values are handed to
 * [MaterialTheme] so every Material 3 component (buttons, chips, navigation bar,
 * sheets) picks them up, and [LocalRiffColors] keeps the untransformed tokens for
 * custom surfaces.
 *
 * Typography note: the desktop bundles Google Sans via `fonts.googleapis.com`.
 * Google Sans is not redistributable, so the Android build uses the platform
 * default family with the same size/weight ramp — documented in android/PORTING.md.
 */
@Composable
fun RiffTheme(settings: RiffSettings, content: @Composable () -> Unit) {
    val theme = settings.theme
    val dark = when (theme.mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colors = remember(theme.accent, theme.intensity, theme.brightness, theme.paletteStyle, dark) {
        RiffPalette.generate(
            accentHex = theme.accent,
            mode = if (dark) ThemeMode.DARK else ThemeMode.LIGHT,
            intensity = theme.intensity,
            brightness = theme.brightness,
            paletteStyle = theme.paletteStyle,
        )
    }

    val colorScheme = remember(colors, dark) { colors.toColorScheme(dark) }

    CompositionLocalProvider(LocalRiffColors provides colors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = RiffType,
            shapes = RiffShapes,
            content = content,
        )
    }
}

/** Maps the palette onto Material 3's colour roles. */
private fun RiffColors.toColorScheme(dark: Boolean): androidx.compose.material3.ColorScheme {
    val base = if (dark) darkColorScheme() else lightColorScheme()
    return base.copy(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = primaryContainerResolved,
        onPrimaryContainer = onPrimaryContainer,
        secondary = secondary,
        onSecondary = onSecondary,
        secondaryContainer = secondaryContainer,
        onSecondaryContainer = onSecondaryContainer,
        tertiary = tertiary,
        onTertiary = onTertiary,
        tertiaryContainer = tertiaryContainer,
        onTertiaryContainer = onTertiaryContainer,
        background = background,
        onBackground = onBackground,
        surface = surface,
        onSurface = onSurface,
        surfaceVariant = surfaceContainerHighest,
        onSurfaceVariant = onSurfaceVariant,
        surfaceDim = surfaceDim,
        surfaceBright = surfaceBright,
        surfaceContainerLowest = surfaceContainerLowest,
        surfaceContainerLow = surfaceContainerLow,
        surfaceContainer = surfaceContainer,
        surfaceContainerHigh = surfaceContainerHigh,
        surfaceContainerHighest = surfaceContainerHighest,
        outline = outline,
        outlineVariant = outlineVariant,
        inverseSurface = onSurface,
        inverseOnSurface = surface,
        scrim = Color(0xFF000000),
        surfaceTint = primary,
    )
}

/** Bottom-sheet/card corners follow the desktop's shape scale. */
val RiffShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

/**
 * Type ramp. Sizes follow the desktop stylesheet closely (the app is a dense
 * information UI: small labels, compact rows), with the platform font family.
 */
val RiffType = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 32.sp, lineHeight = 38.sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 19.sp, lineHeight = 24.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 20.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 13.5.sp, lineHeight = 18.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 13.5.sp, lineHeight = 19.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 17.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 11.5.sp, lineHeight = 15.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 10.5.sp, lineHeight = 14.sp),
)
