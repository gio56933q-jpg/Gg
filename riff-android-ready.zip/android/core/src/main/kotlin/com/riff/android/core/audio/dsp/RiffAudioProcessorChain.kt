package com.riff.android.core.audio.dsp

import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessorChain
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi

/**
 * The Android equivalent of `initAudioGraph()` in `audio-engine.js`.
 *
 * Desktop signal flow (standard mode):
 *
 *     source -> dry(1 - .4*d) -> distortion(WaveShaper) -> delay(.3s fb .35)
 *            -> convolver(.6s noise IR) -> gain -> master -> destination
 *
 * Desktop signal flow (HQ mode):
 *
 *     source -> compressor(-12 dB, 1.5:1) -> lowshelf(80) -> peaking(2500 Q1.2)
 *            -> highshelf(9000) -> saturation(4x) -> limiter(-1 dB, 20:1) -> gain
 *
 * Media3 gives us the same insertion point through
 * `DefaultAudioSink.Builder.setAudioProcessorChain`; [SonicAudioProcessor] replaces
 * the desktop's `preservesPitch` behaviour for speed/pitch (see
 * `AudioEffectsController.playbackParameters`), and the custom processors cover the
 * effects. The chain reports the *same* order and the *same* parameter scaling as the
 * desktop graph, so presets ("slow + reverb", "distortion hard", …) sound the same
 * modulo the documented reverb substitution.
 */
@UnstableApi
class RiffAudioProcessorChain(
    private val state: RiffEffectState,
) : AudioProcessorChain {

    private val sonic = SonicAudioProcessor().apply {
        setOutputSampleRateHz(SonicAudioProcessor.SAMPLE_RATE_NO_CHANGE)
    }

    private val overdrive = RiffOverdriveProcessor(state)
    private val delay = RiffDelayProcessor(state)
    private val reverb = RiffReverbProcessor(state)
    private val hq = RiffHqProcessor(state)
    private val gain = RiffGainProcessor(state)

    private val processors: List<AudioProcessor> = listOf(sonic, overdrive, delay, reverb, hq, gain)

    override fun getAudioProcessors(): Array<AudioProcessor> = processors.toTypedArray()

    /**
     * Speed/pitch are handled by [SonicAudioProcessor]; the desktop changed
     * `audioElement.playbackRate` (`preservesPitch = false` for tape-style speed-up),
     * which is exactly what [PlaybackParameters] expresses:
     *
     *  - normal speed      -> `PlaybackParameters(speed, 1f)` (pitch preserved),
     *  - tape speed/pitch  -> `PlaybackParameters(rate, rate)` (both scale, i.e.
     *    resampling — desktop sets `preservesPitch = false`).
     */
    override fun applyPlaybackParameters(playbackParameters: PlaybackParameters): PlaybackParameters =
        playbackParameters

    /**
     * Skip-silence is an optional setting on Android (the desktop had no equivalent).
     * The chain has no silence-skipping processor, so the flag is reported as
     * unsupported instead of silently doing nothing.
     */
    override fun applySkipSilenceEnabled(skipSilenceEnabled: Boolean): Boolean = false

    /** Duration is unchanged by the effects (Sonic reports its own scaling separately). */
    override fun getMediaDuration(mediaDurationUs: Long): Long = mediaDurationUs

    override fun getSkippedOutputFrameCount(): Long = 0L
}
