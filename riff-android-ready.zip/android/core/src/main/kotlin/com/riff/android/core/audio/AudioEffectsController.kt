package com.riff.android.core.audio

import androidx.media3.common.PlaybackParameters
import com.riff.android.core.audio.dsp.RiffEffectState
import com.riff.android.domain.model.AudioSettings
import com.riff.android.domain.model.HqSettings
import com.riff.android.domain.model.RiffPreset
import com.riff.android.domain.model.RiffSettings
import com.riff.android.domain.repo.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Single source of truth for "what the effects are doing right now".
 *
 * The task requires effects to be *isolated* from playback and UI: the UI talks
 * only to this controller, and the playback side only ever reads [effectState].
 * Nothing else in the app knows whether reverb is implemented with a convolver,
 * a Freeverb network or a future FFmpeg filter — that knowledge stops here.
 *
 * Desktop equivalent: `RiffAudioEngine.applySettings()` / `applyPreset()`
 * (`audio-engine.js`) plus the preset chips in Settings.
 */
class AudioEffectsController(
    private val settingsRepository: SettingsRepository,
    private val scope: CoroutineScope,
) {

    /** Live parameters polled by the audio processors. */
    val effectState = RiffEffectState()

    private val _audioSettings = MutableStateFlow(AudioSettings.DEFAULT)
    val audioSettings: StateFlow<AudioSettings> = _audioSettings.asStateFlow()

    private val _hqSettings = MutableStateFlow(HqSettings())
    val hqSettings: StateFlow<HqSettings> = _hqSettings.asStateFlow()

    private val _hqEnabled = MutableStateFlow(false)
    val hqEnabled: StateFlow<Boolean> = _hqEnabled.asStateFlow()

    private val _playbackParameters = MutableStateFlow(PlaybackParameters.DEFAULT)

    /** Speed/pitch as Media3 parameters — the player subscribes to this. */
    val playbackParameters: StateFlow<PlaybackParameters> = _playbackParameters.asStateFlow()

    private val _activePresetId = MutableStateFlow(RiffPreset.DEFAULT_PREFIX + "default")
    val activePresetId: StateFlow<String> = _activePresetId.asStateFlow()

    /** Mirrors persisted settings into the live DSP state (and after process death). */
    fun bind() {
        scope.launch {
            settingsRepository.observeSettings().collect { settings ->
                applyLocally(settings)
            }
        }
    }

    private fun applyLocally(settings: RiffSettings) {
        val audio = settings.audio
        _audioSettings.value = audio
        _hqSettings.value = settings.hq
        _hqEnabled.value = settings.playback.hqEnabled
        _activePresetId.value = settings.activePresetId

        effectState.audio = audio
        effectState.hq = settings.hq
        effectState.hqEnabled = settings.playback.hqEnabled

        _playbackParameters.value = playbackParametersFor(audio)
    }

    /**
     * Port of `applySettings()` for the rate/pitch part:
     *
     * ```js
     * const p = Math.pow(2, pitch / 12);
     * if (speedPitch !== 1) { audio.playbackRate = speedPitch * p; audio.preservesPitch = false; }
     * else { audio.playbackRate = speed; audio.preservesPitch = true; audio.pitchShift = p; }
     * ```
     *
     * `preservesPitch = false` resamples, i.e. tempo and pitch scale by the same
     * factor — represented here as `PlaybackParameters(rate, rate)`.
     */
    fun playbackParametersFor(audio: AudioSettings): PlaybackParameters = RiffPlaybackParameters.of(audio)

    /** Slider/knob updates: persist, then let the settings flow update the DSP state. */
    suspend fun updateAudio(audio: AudioSettings) {
        val settings = settingsRepository.current()
        settingsRepository.setAudio(audio)
        val presetId = if (audio == AudioSettings.DEFAULT) {
            RiffPreset.DEFAULT_PREFIX + "default"
        } else {
            // Any manual change turns the preset chips into "custom" (desktop keeps the
            // last id active but marks the settings dirty; we mirror the id and let the
            // settings screen show "custom" when no preset matches).
            settings.activePresetId
        }
        settingsRepository.setActivePreset(presetId)
    }

    /** Desktop `applyPreset(preset)`: copy every effect value into the settings. */
    suspend fun applyPreset(preset: RiffPreset) {
        settingsRepository.setAudio(preset.settings)
        settingsRepository.setActivePreset(preset.id)
    }

    suspend fun updateHq(hq: HqSettings, enabled: Boolean) {
        settingsRepository.setHq(hq, enabled)
    }

    suspend fun setHqEnabled(enabled: Boolean) {
        val current = settingsRepository.current()
        settingsRepository.setHq(current.hq, enabled)
    }

    /** Saves the current audio settings as a user preset (desktop `saveCustomPreset`). */
    suspend fun saveCustomPreset(name: String): RiffPreset {
        val current = settingsRepository.current()
        val preset = RiffPreset(
            id = "custom_${System.currentTimeMillis()}",
            name = name.ifBlank { "preset ${current.customPresets.size + 1}" },
            settings = current.audio,
        )
        settingsRepository.saveCustomPreset(preset)
        settingsRepository.setActivePreset(preset.id)
        return preset
    }

    suspend fun deleteCustomPreset(presetId: String) {
        settingsRepository.deleteCustomPreset(presetId)
        if (settingsRepository.current().activePresetId == presetId) {
            settingsRepository.setActivePreset(RiffPreset.DEFAULT_PREFIX + "default")
        }
    }
}
