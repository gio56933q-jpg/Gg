package com.riff.android.core.audio

import androidx.media3.common.PlaybackParameters
import com.riff.android.domain.model.AudioSettings
import kotlin.math.pow

/**
 * Speed/pitch mapping — the `applySettings()` part of `audio-engine.js`:
 *
 * ```js
 * const p = Math.pow(2, pitch / 12);
 * if (speedPitch !== 1) { audio.playbackRate = speedPitch * p; audio.preservesPitch = false; }
 * else { audio.playbackRate = speed; audio.preservesPitch = true; audio.pitchShift = p; }
 * ```
 *
 * `preservesPitch = false` means the browser resamples: tempo *and* pitch scale by the
 * same factor. Media3 has no "resample" switch, but `PlaybackParameters(speed, pitch)`
 * with both values equal produces the same result (Sonic's speed changes tempo, its
 * pitch changes pitch; scaling both is a resample).
 *
 * The mapping lives in a standalone object (instead of inside the controller) so the
 * behaviour is unit-testable without an Android context.
 */
object RiffPlaybackParameters {

    /** `Pitch.SPEED_TO_SEEK_...`-free, clamps to the desktop's 0.25x–4x window. */
    fun of(audio: AudioSettings): PlaybackParameters {
        val pitchFactor = 2f.pow(audio.pitch / 12f)
        return if (audio.speedPitch != 1f || audio.pitch != 0) {
            val rate = (audio.speedPitch * pitchFactor).coerceIn(MIN_RATE, MAX_RATE)
            PlaybackParameters(rate, rate)
        } else {
            PlaybackParameters(audio.speed.coerceIn(MIN_RATE, MAX_RATE), 1f)
        }
    }

    const val MIN_RATE = 0.25f
    const val MAX_RATE = 4f
}
