package com.riff.android.core.theme

import androidx.compose.ui.graphics.Color
import com.riff.android.domain.model.PaletteStyle
import com.riff.android.domain.model.ThemeMode
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Port of the desktop palette engine (`generateM3Palette()` + `PALETTE_STYLES` in
 * app.js, lines ~482-660).
 *
 * The desktop writes the generated tokens into CSS custom properties
 * (`--md-sys-color-*`); here the same values become a [RiffColors] value object
 * that the Compose theme maps onto Material 3's [androidx.compose.material3.ColorScheme].
 * Every rule is kept: the intensity threshold for the monochrome fallback, the
 * brightness formula (light `v + (br - 0.5) * 24`, dark `v * br * 2`), the four
 * saturation scales, and the `rgba(primary, 0.18)` container in dark mode.
 */
object RiffPalette {

    const val SEED = "#6750A4"

    /** `PALETTE_STYLES` — hue shifts and saturation scales per style. */
    data class Style(
        val key: PaletteStyle,
        val label: String,
        val secHueShift: Int,
        val tertHueShift: Int,
        val priSatScale: Double,
        val surfSatScale: Double,
        val contSatScale: Double,
    )

    val STYLES: Map<PaletteStyle, Style> = mapOf(
        PaletteStyle.CLASSIC to Style(PaletteStyle.CLASSIC, "Classic", 0, 0, 1.0, 1.0, 1.0),
        PaletteStyle.TONAL_SPOT to Style(PaletteStyle.TONAL_SPOT, "Tonal spot", 0, 60, 1.0, 0.8, 0.9),
        PaletteStyle.EXPRESSIVE to Style(PaletteStyle.EXPRESSIVE, "Expressive", 60, 120, 1.25, 1.5, 1.3),
        PaletteStyle.VIBRANT to Style(PaletteStyle.VIBRANT, "Vibrant", 0, 60, 1.4, 1.2, 1.4),
        PaletteStyle.NEUTRAL to Style(PaletteStyle.NEUTRAL, "Neutral", 0, 0, 0.35, 0.2, 0.25),
    )

    fun style(style: PaletteStyle): Style = STYLES[style] ?: STYLES.getValue(PaletteStyle.CLASSIC)

    fun generate(
        accentHex: String?,
        mode: ThemeMode,
        intensity: Int,
        brightness: Int,
        paletteStyle: PaletteStyle,
    ): RiffColors {
        val hex = accentHex?.takeIf { it.isNotBlank() } ?: SEED
        val (r, g, b) = hexToRgb(hex)
        val hsl = rgbToHsl(r, g, b)
        val h = hsl[0]
        val intensityFactor = intensity.coerceIn(0, 100) / 100.0
        val style = style(paletteStyle)
        val hSec = (h + style.secHueShift) % 360
        val hTert = (h + style.tertHueShift) % 360
        val monochrome = intensityFactor < 0.08 || (paletteStyle == PaletteStyle.NEUTRAL && intensityFactor < 0.05)
        val br = brightness.coerceIn(0, 100) / 100.0

        return if (mode == ThemeMode.LIGHT) {
            val lb = { v: Int -> (v + (br - 0.5) * 24).roundToInt().coerceIn(0, 100) }
            if (monochrome) {
                RiffColors(
                    primary = Color(0xFF1C1B1F),
                    onPrimary = Color.White,
                    primaryContainer = hsl(0.0, 0, lb(90)),
                    onPrimaryContainer = Color(0xFF1C1B1F),
                    secondary = Color(0xFF49454F),
                    onSecondary = Color.White,
                    secondaryContainer = hsl(0.0, 0, lb(90)),
                    onSecondaryContainer = Color(0xFF1C1B1F),
                    tertiary = Color(0xFF49454F),
                    onTertiary = Color.White,
                    tertiaryContainer = hsl(0.0, 0, lb(90)),
                    onTertiaryContainer = Color(0xFF1C1B1F),
                    background = hsl(0.0, 0, lb(99)),
                    onBackground = Color(0xFF1C1B1F),
                    surface = hsl(0.0, 0, lb(98)),
                    onSurface = Color(0xFF1C1B1F),
                    surfaceDim = hsl(0.0, 0, lb(87)),
                    surfaceBright = hsl(0.0, 0, lb(98)),
                    surfaceContainerLowest = hsl(0.0, 0, lb(100)),
                    surfaceContainerLow = hsl(0.0, 0, lb(96)),
                    surfaceContainer = hsl(0.0, 0, lb(94)),
                    surfaceContainerHigh = hsl(0.0, 0, lb(92)),
                    surfaceContainerHighest = hsl(0.0, 0, lb(90)),
                    onSurfaceVariant = Color(0xFF49454F),
                    outline = Color(0xFF79747E),
                    outlineVariant = Color(0xFFCAC4D0),
                    isMonochrome = true,
                )
            } else {
                val sat = min(100.0, 48 * intensityFactor * style.priSatScale).roundToInt()
                val satHi = min(100.0, 80 * intensityFactor * style.contSatScale).roundToInt()
                val satMed = min(100.0, 55 * intensityFactor * style.priSatScale).roundToInt()
                val satLow = min(100.0, 30 * intensityFactor * style.contSatScale).roundToInt()
                val satLow2 = min(100.0, 20 * intensityFactor * style.contSatScale).roundToInt()
                val surf = intensityFactor * style.surfSatScale
                RiffColors(
                    primary = hsl(h, sat, 40),
                    onPrimary = Color(0xFFFEFBFF),
                    primaryContainer = hsl(h, satHi, lb(90)),
                    onPrimaryContainer = hsl(h, satMed, 18),
                    secondary = hsl(hSec, satLow, 45),
                    onSecondary = Color.White,
                    secondaryContainer = hsl(hSec, satLow, lb(90)),
                    onSecondaryContainer = hsl(hSec, satLow2, 15),
                    tertiary = hsl(hTert, satLow, 45),
                    onTertiary = Color.White,
                    tertiaryContainer = hsl(hTert, satLow, lb(90)),
                    onTertiaryContainer = hsl(hTert, satLow2, 15),
                    background = hsl(h, (5 * surf).roundToInt(), lb(99)),
                    onBackground = Color(0xFF1C1B1F),
                    surface = hsl(h, (6 * surf).roundToInt(), lb(98)),
                    onSurface = Color(0xFF1C1B1F),
                    surfaceDim = hsl(h, (5 * surf).roundToInt(), lb(87)),
                    surfaceBright = hsl(h, (6 * surf).roundToInt(), lb(98)),
                    surfaceContainerLowest = hsl(h, (4 * surf).roundToInt(), lb(100)),
                    surfaceContainerLow = hsl(h, (5 * surf).roundToInt(), lb(96)),
                    surfaceContainer = hsl(h, (6 * surf).roundToInt(), lb(94)),
                    surfaceContainerHigh = hsl(h, (5 * surf).roundToInt(), lb(92)),
                    surfaceContainerHighest = hsl(h, (5 * surf).roundToInt(), lb(90)),
                    onSurfaceVariant = Color(0xFF49454F),
                    outline = Color(0xFF79747E),
                    outlineVariant = Color(0xFFCAC4D0),
                    isMonochrome = false,
                )
            }
        } else {
            val b = { v: Int -> (v * (br * 2)).roundToInt().coerceIn(0, 100) }
            if (monochrome) {
                RiffColors(
                    primary = Color(0xFFE2E2E9),
                    onPrimary = Color(0xFF1C1B1F),
                    primaryContainer = Color(0xFF49454F),
                    onPrimaryContainer = Color(0xFFE2E2E9),
                    secondary = Color(0xFFC4C6D0),
                    onSecondary = Color(0xFF1C1B1F),
                    secondaryContainer = Color(0xFF2B2930),
                    onSecondaryContainer = Color(0xFFE2E2E9),
                    tertiary = Color(0xFFC4C6D0),
                    onTertiary = Color(0xFF1C1B1F),
                    tertiaryContainer = Color(0xFF2B2930),
                    onTertiaryContainer = Color(0xFFE2E2E9),
                    background = hsl(0.0, 0, b(7)),
                    onBackground = Color(0xFFE2E2E9),
                    surface = hsl(0.0, 0, b(7)),
                    onSurface = Color(0xFFE2E2E9),
                    surfaceDim = hsl(0.0, 0, b(7)),
                    surfaceBright = hsl(0.0, 0, b(19)),
                    surfaceContainerLowest = hsl(0.0, 0, b(5)),
                    surfaceContainerLow = hsl(0.0, 0, b(10)),
                    surfaceContainer = hsl(0.0, 0, b(13)),
                    surfaceContainerHigh = hsl(0.0, 0, b(16)),
                    surfaceContainerHighest = hsl(0.0, 0, b(20)),
                    onSurfaceVariant = Color(0xFFC4C6D0),
                    outline = Color(0xFF8E9099),
                    outlineVariant = Color(0xFF44474E),
                    isMonochrome = true,
                )
            } else {
                val sat = min(100.0, 60 * intensityFactor * style.priSatScale).roundToInt()
                val satHi = min(100.0, 60 * intensityFactor * style.contSatScale).roundToInt()
                val satMed = min(100.0, 50 * intensityFactor * style.priSatScale).roundToInt()
                val satLow = min(100.0, 15 * intensityFactor * style.contSatScale).roundToInt()
                val satLow2 = min(100.0, 30 * intensityFactor * style.contSatScale).roundToInt()
                val surf = intensityFactor * style.surfSatScale
                val primary = hsl(h, sat, 75)
                RiffColors(
                    primary = primary,
                    onPrimary = hsl(h, satMed, 20),
                    // Desktop: `rgba(primary, 0.18)` — reproduced with alpha here and
                    // resolved onto the surface when mapped to a ColorScheme.
                    primaryContainer = primary.copy(alpha = 0.18f),
                    onPrimaryContainer = primary,
                    secondary = hsl(hSec, satLow2, 75),
                    onSecondary = hsl(hSec, satMed, 20),
                    secondaryContainer = hsl(hSec, satLow, 22),
                    onSecondaryContainer = hsl(hSec, satLow2, 85),
                    tertiary = hsl(hTert, satLow2, 75),
                    onTertiary = hsl(hTert, satMed, 20),
                    tertiaryContainer = hsl(hTert, satLow, 22),
                    onTertiaryContainer = hsl(hTert, satLow2, 85),
                    background = hsl(h, (5 * surf).roundToInt(), b(7)),
                    onBackground = Color(0xFFE2E2E9),
                    surface = hsl(h, (6 * surf).roundToInt(), b(8)),
                    onSurface = Color(0xFFE2E2E9),
                    surfaceDim = hsl(h, (5 * surf).roundToInt(), b(7)),
                    surfaceBright = hsl(h, (4 * surf).roundToInt(), b(24)),
                    surfaceContainerLowest = hsl(h, (5 * surf).roundToInt(), b(5)),
                    surfaceContainerLow = hsl(h, (5 * surf).roundToInt(), b(10)),
                    surfaceContainer = hsl(h, (6 * surf).roundToInt(), b(13)),
                    surfaceContainerHigh = hsl(h, (5 * surf).roundToInt(), b(16)),
                    surfaceContainerHighest = hsl(h, (5 * surf).roundToInt(), b(20)),
                    onSurfaceVariant = Color(0xFFC4C6D0),
                    outline = Color(0xFF8E9099),
                    outlineVariant = Color(0xFF282A33),
                    isMonochrome = false,
                )
            }
        }
    }

    // --- colour maths (same as app.js) --------------------------------------

    fun hexToRgb(hex: String): Triple<Int, Int, Int> {
        val clean = hex.removePrefix("#").let { if (it.length == 3) it.map { c -> "$c$c" }.joinToString("") else it }
        val value = clean.toLongOrNull(16) ?: 0x6750A4
        return Triple(((value shr 16) and 0xFF).toInt(), ((value shr 8) and 0xFF).toInt(), (value and 0xFF).toInt())
    }

    fun rgbToHsl(r: Int, g: Int, b: Int): DoubleArray {
        val rf = r / 255.0
        val gf = g / 255.0
        val bf = b / 255.0
        val maxV = max(rf, max(gf, bf))
        val minV = min(rf, min(gf, bf))
        var h = 0.0
        val l = (maxV + minV) / 2.0
        val d = maxV - minV
        val s = if (d == 0.0) 0.0 else d / (1 - abs(2 * l - 1))
        if (d != 0.0) {
            h = when (maxV) {
                rf -> 60 * (((gf - bf) / d) % 6)
                gf -> 60 * (((bf - rf) / d) + 2)
                else -> 60 * (((rf - gf) / d) + 4)
            }
        }
        if (h < 0) h += 360
        return doubleArrayOf(h, s * 100, l * 100)
    }

    /** Returns a Compose colour for `hsl(h, s%, l%)`. */
    private fun hsl(h: Double, s: Int, l: Int): Color {
        val sf = s.coerceIn(0, 100) / 100.0
        val lf = l.coerceIn(0, 100) / 100.0
        val c = (1 - abs(2 * lf - 1)) * sf
        val x = c * (1 - abs(((h / 60.0) % 2) - 1))
        val m = lf - c / 2
        val (r1, g1, b1) = when {
            h < 60 -> Triple(c, x, 0.0)
            h < 120 -> Triple(x, c, 0.0)
            h < 180 -> Triple(0.0, c, x)
            h < 240 -> Triple(0.0, x, c)
            h < 300 -> Triple(x, 0.0, c)
            else -> Triple(c, 0.0, x)
        }
        return Color(
            red = (r1 + m).toFloat(),
            green = (g1 + m).toFloat(),
            blue = (b1 + m).toFloat(),
            alpha = 1f,
        )
    }

    /**
     * A hue-shifted companion of [hex] (desktop `analyzeCover()` returns
     * `accent2` = accent rotated by 40°). Used by the mesh/ambient glow layers.
     */
    fun shifted(hex: String, degrees: Int, sat: Int, light: Int): Color {
        val (r, g, b) = hexToRgb(hex)
        val h = (rgbToHsl(r, g, b)[0] + degrees + 360) % 360
        return hsl(h, sat, light)
    }

    /** `#RRGGBB` for the generated primary — used by the settings swatch preview. */
    fun toHex(color: Color): String {
        val r = (color.red * 255).roundToInt().coerceIn(0, 255)
        val g = (color.green * 255).roundToInt().coerceIn(0, 255)
        val b = (color.blue * 255).roundToInt().coerceIn(0, 255)
        return "#%02X%02X%02X".format(r, g, b)
    }

    /**
     * Port of `analyzeCover()`'s colour maths: the average cover colour is pushed
     * into a usable accent (desktop maps it through HSL too — saturated, mid-light
     * colours read best against the dark surfaces).
     */
    fun accentFromAverageColor(r: Int, g: Int, b: Int): String {
        val (h, s) = rgbToHsl(r, g, b)
        // Boost low chroma so grey-ish covers still produce a tinted UI, and keep
        // the lightness in the same band as the desktop swatches.
        val sat = (s.coerceAtLeast(18.0) * 1.2).coerceAtMost(85.0).roundToInt()
        return toHex(hsl(h, sat, 62))
    }

    /** Desktop `analyzeCover()` returns `accent2 = accent` rotated by +40°. */
    fun accent2(accentHex: String): String {
        val (r, g, b) = hexToRgb(accentHex)
        val hsl = rgbToHsl(r, g, b)
        return toHex(shifted(accentHex, 40, hsl[1].roundToInt().coerceIn(0, 100), hsl[2].roundToInt().coerceIn(0, 100)))
    }

    /** The desktop's swatch list (`renderThemeSection`). */
    val ACCENT_SWATCHES: List<String> = listOf(
        "#6750A4", "#a8c7fa", "#d0bcff", "#a8e6cf", "#f8bbd0", "#ffe082", "#ffcc80", "#e2e2e9",
    )
}

/** Resolved palette tokens (mirrors the `--md-sys-color-*` custom properties). */
data class RiffColors(
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val secondary: Color,
    val onSecondary: Color,
    val secondaryContainer: Color,
    val onSecondaryContainer: Color,
    val tertiary: Color,
    val onTertiary: Color,
    val tertiaryContainer: Color,
    val onTertiaryContainer: Color,
    val background: Color,
    val onBackground: Color,
    val surface: Color,
    val onSurface: Color,
    val surfaceDim: Color,
    val surfaceBright: Color,
    val surfaceContainerLowest: Color,
    val surfaceContainerLow: Color,
    val surfaceContainer: Color,
    val surfaceContainerHigh: Color,
    val surfaceContainerHighest: Color,
    val onSurfaceVariant: Color,
    val outline: Color,
    val outlineVariant: Color,
    val isMonochrome: Boolean,
) {
    /** Dark mode stores `rgba(primary, 0.18)`: resolve it against the surface for M3. */
    val primaryContainerResolved: Color
        get() = if (primaryContainer.alpha < 1f) {
            androidx.compose.ui.graphics.lerp(surfaceContainerHigh, primaryContainer, primaryContainer.alpha)
        } else {
            primaryContainer
        }
}
