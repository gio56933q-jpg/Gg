package com.riff.android.core.audio.dsp

import com.riff.android.domain.model.AudioSettings
import com.riff.android.domain.model.HqSettings
import java.util.concurrent.atomic.AtomicLong

/**
 * Live DSP parameters, shared between the UI (settings screen, preset chips) and the
 * ExoPlayer audio processors.
 *
 * Desktop equivalent: `audioSettings`, `hqSettings`, `hqEnabled` and the individual
 * `ConvolverNode`/`WaveShaperNode`/`DelayNode` gains attached to the Web Audio graph
 * in `audio-engine.js`. The Android processors poll this state on every buffer, so a
 * knob change is audible immediately without rebuilding the player.
 *
 * [version] is bumped on every change so the processors can cheaply skip work when
 * everything is at its default (bit-exact passthrough — the desktop also bypasses
 * the graph when `isModified()` is false).
 */
class RiffEffectState {

    @Volatile
    var audio: AudioSettings = AudioSettings.DEFAULT
        set(value) {
            field = value
            version.incrementAndGet()
        }

    @Volatile
    var hq: HqSettings = HqSettings()
        set(value) {
            field = value
            version.incrementAndGet()
        }

    @Volatile
    var hqEnabled: Boolean = false
        set(value) {
            field = value
            version.incrementAndGet()
        }

    internal val version = AtomicLong(0)

    /** Desktop `isModified()`. */
    val isModified: Boolean get() = audio.isModified || hqEnabled

    /** `audioSettings.reverb / 100`. */
    val reverbWet: Float get() = (audio.reverb / 100f).coerceIn(0f, 1f)

    /** `audioSettings.echo / 100`. */
    val echoWet: Float get() = (audio.echo / 100f).coerceIn(0f, 1f)

    /** `audioSettings.distortion / 100`. */
    val distortionWet: Float get() = (audio.distortion / 100f).coerceIn(0f, 1f)

    /** Preset gain (`audioSettings.volume`), 1.0 = unity. */
    val presetGain: Float get() = audio.volume.coerceIn(0f, 4f)
}
