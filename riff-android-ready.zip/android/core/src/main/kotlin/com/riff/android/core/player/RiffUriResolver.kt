package com.riff.android.core.player

import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.ResolvingDataSource
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.repo.StreamResolver
import kotlinx.coroutines.runBlocking
import java.util.concurrent.ConcurrentHashMap

/**
 * Turns `riff://track/<id>` into something the media stack can open.
 *
 * Desktop equivalent: the `<audio>` `src` switching in `app.js` (`playTrack()` asks
 * `/api/stream-info`, which answers with `isLocal: true` and `/api/local-track?id=…`
 * for cached files, or with a fresh yt-dlp url otherwise, cached for 2 hours).
 *
 * Same order here:
 *  1. the track's `localUri` (download/import) — offline-first, no network at all,
 *  2. a cached stream url (2 h TTL, like the desktop `streamUrlCache`),
 *  3. [StreamResolver] (NewPipe extractor or the configured Riff backend).
 *
 * `resolveDataSpec()` runs on ExoPlayer's loading thread, so the blocking bridge is
 * intentional and does not touch the UI thread.
 */
@UnstableApi
class RiffUriResolver(
    private val library: LibraryRepository,
    private val streamResolver: StreamResolver,
    private val streamUrlTtlMs: Long = 2 * 60 * 60 * 1000L,
) : ResolvingDataSource.Resolver {

    private class CachedUrl(val url: String, val resolvedAt: Long) {
        fun isFresh(ttl: Long) = System.currentTimeMillis() - resolvedAt < ttl
    }

    private val urlCache = ConcurrentHashMap<String, CachedUrl>()

    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val uri = dataSpec.uri
        if (uri.scheme != SCHEME) return dataSpec

        val trackId = Uri.decode(uri.lastPathSegment ?: uri.path?.trimStart('/').orEmpty())
        val track = runBlocking { runCatching { library.get(trackId) }.getOrNull() }

        // 1. offline-first: downloaded or imported file.
        track?.localUri?.takeIf { it.isNotBlank() }?.let { local ->
            return dataSpec.withUri(Uri.parse(local))
        }

        // 2/3. remote stream, cached like the desktop's 2 hour stream url cache.
        val cached = urlCache[trackId]
        val streamUrl = if (cached?.isFresh(streamUrlTtlMs) == true) {
            cached.url
        } else {
            val resolved = runBlocking {
                runCatching { streamResolver.resolve(track ?: error("track $trackId is not in the library")) }
                    .getOrElse { error -> throw java.io.IOException("stream resolution failed: ${error.message}", error) }
            }
            urlCache[trackId] = CachedUrl(resolved, System.currentTimeMillis())
            resolved
        }

        return dataSpec.withUri(Uri.parse(streamUrl))
    }

    fun clearCache() = urlCache.clear()

    companion object {
        const val SCHEME = "riff"
    }
}
