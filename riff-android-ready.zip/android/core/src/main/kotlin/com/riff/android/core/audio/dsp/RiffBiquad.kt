package com.riff.android.core.audio.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Direct-form-II transposed biquad (RBJ cookbook), the Android equivalent of the
 * desktop's `BiquadFilterNode`s in `audio-engine.js` (lowshelf 80 Hz, peaking
 * 2500 Hz Q 1.2, highshelf 9000 Hz).
 */
class RiffBiquad {

    enum class Type { LOW_SHELF, PEAKING, HIGH_SHELF }

    private var b0 = 1f
    private var b1 = 0f
    private var b2 = 0f
    private var a1 = 0f
    private var a2 = 0f

    private var z1 = 0f
    private var z2 = 0f

    fun configure(type: Type, sampleRate: Int, frequencyHz: Float, q: Float = 0.707f, gainDb: Float) {
        val a = Math.pow(10.0, (gainDb / 40.0)).toFloat()
        val w0 = (2.0 * PI * frequencyHz.coerceIn(10f, sampleRate / 2f - 100f) / sampleRate).toFloat()
        val cosW0 = cos(w0)
        val sinW0 = sin(w0)
        val alpha = sinW0 / (2f * q.coerceAtLeast(0.05f))

        when (type) {
            Type.LOW_SHELF -> {
                val sqrtA = sqrt(a)
                val twoSqrtAAlpha = 2f * sqrtA * alpha
                val a0 = (a + 1f) + (a - 1f) * cosW0 + twoSqrtAAlpha
                b0 = (a * ((a + 1f) - (a - 1f) * cosW0 + twoSqrtAAlpha)) / a0
                b1 = (2f * a * ((a - 1f) - (a + 1f) * cosW0)) / a0
                b2 = (a * ((a + 1f) - (a - 1f) * cosW0 - twoSqrtAAlpha)) / a0
                a1 = (-2f * ((a - 1f) + (a + 1f) * cosW0)) / a0
                a2 = ((a + 1f) + (a - 1f) * cosW0 - twoSqrtAAlpha) / a0
            }

            Type.PEAKING -> {
                val a0 = 1f + alpha / a
                b0 = (1f + alpha * a) / a0
                b1 = (-2f * cosW0) / a0
                b2 = (1f - alpha * a) / a0
                a1 = (-2f * cosW0) / a0
                a2 = (1f - alpha / a) / a0
            }

            Type.HIGH_SHELF -> {
                val sqrtA = sqrt(a)
                val twoSqrtAAlpha = 2f * sqrtA * alpha
                val a0 = (a + 1f) - (a - 1f) * cosW0 + twoSqrtAAlpha
                b0 = (a * ((a + 1f) + (a - 1f) * cosW0 + twoSqrtAAlpha)) / a0
                b1 = (-2f * a * ((a - 1f) + (a + 1f) * cosW0)) / a0
                b2 = (a * ((a + 1f) + (a - 1f) * cosW0 - twoSqrtAAlpha)) / a0
                a1 = (2f * ((a - 1f) - (a + 1f) * cosW0)) / a0
                a2 = ((a + 1f) - (a - 1f) * cosW0 - twoSqrtAAlpha) / a0
            }
        }
    }

    fun reset() {
        z1 = 0f
        z2 = 0f
    }

    fun process(sample: Float): Float {
        val out = b0 * sample + z1
        z1 = b1 * sample - a1 * out + z2
        z2 = b2 * sample - a2 * out
        return out
    }

    /** Safety: any numerical blow-up resets the filter instead of producing NaN. */
    fun processSafe(sample: Float): Float {
        val out = process(sample)
        if (!out.isFinite()) {
            reset()
            return 0f
        }
        return out
    }
}
