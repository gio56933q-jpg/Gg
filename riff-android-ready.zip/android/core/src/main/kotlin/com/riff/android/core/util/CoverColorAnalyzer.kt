package com.riff.android.core.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.riff.android.core.theme.RiffPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Port of `analyzeCover()` / `extractDominantColor()` from app.js: the desktop
 * draws the artwork into a tiny canvas and averages the pixels to pick the accent
 * colour used for the ambient light, mesh gradient and (optionally) the theme.
 *
 * Android does the same thing with `BitmapFactory` + `inSampleSize` so decoding is
 * cheap, and caches the result per uri like the desktop `coverAnalysisCache`.
 */
class CoverColorAnalyzer(private val context: Context) {

    data class CoverAnalysis(
        val averageColor: Int,
        val accent: String,
        val accent2: String,
        val luminance: Float,
        val saturation: Float,
    )

    private val cache = ConcurrentHashMap<String, CoverAnalysis>()

    suspend fun analyze(uriString: String?): CoverAnalysis? {
        if (uriString.isNullOrBlank()) return null
        cache[uriString]?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = decode(uriString) ?: return@runCatching null
                val analysis = average(bitmap)
                bitmap.recycle()
                cache[uriString] = analysis
                analysis
            }.getOrNull()
        }
    }

    private fun decode(uriString: String): Bitmap? {
        val uri = Uri.parse(uriString)
        val options = android.graphics.BitmapFactory.Options().apply {
            inSampleSize = 8
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return when (uri.scheme) {
            "content", "android.resource" -> context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, options)
            }
            "file" -> android.graphics.BitmapFactory.decodeFile(uri.path, options)
            "http", "https" -> null // remote artwork is loaded and cached by Coil before analysis
            else -> android.graphics.BitmapFactory.decodeFile(uriString, options)
        }
    }

    private fun average(bitmap: Bitmap): CoverAnalysis {
        val width = minOf(bitmap.width, 10)
        val height = minOf(bitmap.height, 10)
        var r = 0L
        var g = 0L
        var b = 0L
        var count = 0
        for (x in 0 until width) {
            for (y in 0 until height) {
                val px = bitmap.getPixel(
                    x * bitmap.width / width.coerceAtLeast(1),
                    y * bitmap.height / height.coerceAtLeast(1),
                )
                r += (px shr 16) and 0xFF
                g += (px shr 8) and 0xFF
                b += px and 0xFF
                count++
            }
        }
        if (count == 0) return CoverAnalysis(0xFF6750A4.toInt(), "#6750A4", "#9A82DB", 0.2f, 0.5f)
        val avgR = (r / count).toInt()
        val avgG = (g / count).toInt()
        val avgB = (b / count).toInt()
        val accent = RiffPalette.accentFromAverageColor(avgR, avgG, avgB)
        val (_, sat, _) = RiffPalette.rgbToHsl(avgR, avgG, avgB)
        val luminance = (0.2126f * avgR + 0.7152f * avgG + 0.0722f * avgB) / 255f
        return CoverAnalysis(
            averageColor = android.graphics.Color.rgb(avgR, avgG, avgB),
            accent = accent,
            accent2 = RiffPalette.accent2(accent),
            luminance = luminance,
            saturation = (sat / 100.0).toFloat(),
        )
    }
}
