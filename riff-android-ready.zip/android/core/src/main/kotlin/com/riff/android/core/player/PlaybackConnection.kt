package com.riff.android.core.player

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.riff.android.core.audio.AudioEffectsController
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.RepeatMode
import com.riff.android.domain.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Everything the player UI (mini player, full player, queue view) renders. */
data class PlayerUiState(
    val track: Track? = null,
    val queue: List<Track> = emptyList(),
    val index: Int = -1,
    val context: PlaybackContext = PlaybackContext.None,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val volume: Float = 0.85f,
    val waveActive: Boolean = false,
    val error: String? = null,
    val connected: Boolean = false,
) {
    val hasTrack: Boolean get() = track != null
    val progress: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}

/**
 * UI-side handle on the [RiffPlaybackService] media session.
 *
 * Desktop equivalent: the `<audio>` element plus the `state.queue` /
 * `state.queueIndex` / `state.isPlaying` bookkeeping in `app.js`. Commands are the
 * same set: play/pause, next, previous (with the 3 second restart rule), seek,
 * shuffle, repeat, volume and queue edits.
 *
 * The connection is created by the Activity, survives configuration changes because
 * it is remembered per Activity, and never owns playback itself — killing the UI
 * leaves the service playing (that is the whole point of the MediaSessionService).
 */
@UnstableApi
class PlaybackConnection(
    private val context: Context,
    private val scope: CoroutineScope,
    private val effects: AudioEffectsController,
) {

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var positionJob: Job? = null
    private var effectsJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            publish(player)
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            _state.value = _state.value.copy(error = error.message ?: "playback error")
        }
    }

    fun connect() {
        if (controller != null || controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, RiffPlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                val mediaController = runCatching { future.get() }.getOrNull() ?: return@addListener
                controller = mediaController
                mediaController.addListener(listener)
                publish(mediaController)
                startTicking()
                applyEffectsToController()
            },
            androidx.core.content.ContextCompat.getMainExecutor(context),
        )
    }

    fun release() {
        positionJob?.cancel()
        effectsJob?.cancel()
        controller?.removeListener(listener)
        controllerFuture?.let { future ->
            runCatching { MediaController.releaseFuture(future) }
        }
        controller = null
        controllerFuture = null
        _state.value = _state.value.copy(connected = false)
    }

    // --- commands (desktop `playTrack()`, `playNext()`, `playPrev()`, …) -----

    /** Desktop `playTrack(track, list, index)`: replace the queue and start playing. */
    fun playTracks(
        tracks: List<Track>,
        startIndex: Int = 0,
        context: PlaybackContext = PlaybackContext.Queue,
        waveActive: Boolean = false,
    ) {
        val player = controller ?: return
        if (tracks.isEmpty()) return
        val index = startIndex.coerceIn(0, tracks.lastIndex)
        player.setMediaItems(
            tracks.map { RiffMediaItems.toMediaItem(it, context, waveActive) },
            index,
            0L,
        )
        player.prepare()
        player.play()
        _state.value = _state.value.copy(error = null)
    }

    /** Desktop "add to queue". */
    fun addToQueue(track: Track) {
        val player = controller ?: return
        val itemCount = player.mediaItemCount
        player.addMediaItem(RiffMediaItems.toMediaItem(track, PlaybackContext.Queue))
        if (itemCount == 0) player.prepare()
        publish(player)
    }

    /** Desktop "play next" in the queue context menu. */
    fun playNextInQueue(track: Track) {
        val player = controller ?: return
        val insertIndex = (player.currentMediaItemIndex + 1).coerceIn(0, player.mediaItemCount)
        player.addMediaItem(insertIndex, RiffMediaItems.toMediaItem(track, PlaybackContext.Queue))
        if (player.mediaItemCount == 1) player.prepare()
        publish(player)
    }

    fun removeFromQueue(mediaItemId: String) {
        val player = controller ?: return
        val index = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == mediaItemId }
            ?: return
        player.removeMediaItem(index)
        publish(player)
    }

    fun moveInQueue(fromIndex: Int, toIndex: Int) {
        val player = controller ?: return
        if (fromIndex in 0 until player.mediaItemCount && toIndex in 0 until player.mediaItemCount) {
            player.moveMediaItem(fromIndex, toIndex)
            publish(player)
        }
    }

    fun clearQueue() {
        val player = controller ?: return
        player.stop()
        player.clearMediaItems()
        publish(player)
    }

    /** Desktop `togglePlayPause()`: with no current item, do nothing (no source). */
    fun togglePlayPause() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
        }
    }

    /** Desktop `playNext()`: shuffle picks a random index, otherwise advance. */
    fun next() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) return
        player.seekToNextMediaItem()
        player.play()
    }

    /**
     * Desktop `playPrev()`: within the first 3 seconds it goes to the previous
     * track, afterwards it restarts the current one — Media3's
     * `seekToPreviousMediaItem()` implements exactly this rule via
     * `Player#getSeekBackIncrementMs`/`maxSeekToPreviousPositionMs`.
     */
    fun previous() {
        val player = controller ?: return
        if (player.mediaItemCount == 0) return
        player.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs.coerceAtLeast(0L))
    }

    fun seekToIndex(index: Int) {
        val player = controller ?: return
        if (index in 0 until player.mediaItemCount) {
            player.seekTo(index, 0L)
            player.play()
        }
    }

    fun setShuffle(enabled: Boolean) {
        controller?.shuffleModeEnabled = enabled
    }

    fun cycleRepeat() {
        val player = controller ?: return
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setVolume(volume: Float) {
        controller?.volume = volume.coerceIn(0f, 1f)
    }

    fun setPlaybackParameters(parameters: PlaybackParameters) {
        controller?.playbackParameters = parameters
    }


    /**
     * Replaces the currently playing item's metadata without interrupting playback.
     *
     * Used when a track is (un)favourited or its download finishes while playing: the
     * notification, the lock screen and the queue all read the MediaItem, so the item
     * has to be updated, not just the database row. The playback position is preserved
     * because `replaceMediaItem` is used instead of `setMediaItem`.
     */
    fun updateCurrentTrack(track: Track) {
        val player = controller ?: return
        val index = player.currentMediaItemIndex
        if (index < 0 || index >= player.mediaItemCount) return
        val waveActive = _state.value.waveActive
        runCatching {
            player.replaceMediaItem(index, RiffMediaItems.toMediaItem(track, _state.value.context, waveActive))
        }
        publish(player)
    }

    fun stop() {
        val player = controller ?: return
        player.stop()
        player.clearMediaItems()
        publish(player)
    }

    // --- internals ----------------------------------------------------------

    private fun startTicking() {
        positionJob?.cancel()
        positionJob = scope.launch {
            while (true) {
                controller?.let { publish(it) }
                delay(POSITION_TICK_MS)
            }
        }
        // Speed/pitch changes come from the effects controller (settings screen or a
        // preset chip) and are pushed to the session so the sinks stay in sync.
        effectsJob?.cancel()
        effectsJob = scope.launch {
            effects.playbackParameters.collect { parameters ->
                controller?.playbackParameters = parameters
            }
        }
    }

    private fun applyEffectsToController() {
        controller?.playbackParameters = effects.playbackParameters.value
    }

    private fun publish(player: Player) {
        val items = (0 until player.mediaItemCount).map { player.getMediaItemAt(it) }
        val currentItem = player.currentMediaItem
        val volume = player.volume
        _state.value = PlayerUiState(
            track = currentItem?.let { RiffMediaItems.toTrack(it) },
            queue = items.map { RiffMediaItems.toTrack(it) },
            index = player.currentMediaItemIndex,
            context = RiffMediaItems.contextFromKey(
                currentItem?.mediaMetadata?.extras?.getString(RiffMediaItems.EXTRA_CONTEXT_KEY),
            ),
            isPlaying = player.isPlaying,
            isBuffering = player.playbackState == Player.STATE_BUFFERING,
            positionMs = player.currentPosition.coerceAtLeast(0L),
            durationMs = player.duration.takeIf { it > 0 } ?: currentItem?.mediaMetadata?.durationMs ?: 0L,
            shuffle = player.shuffleModeEnabled,
            repeatMode = when (player.repeatMode) {
                Player.REPEAT_MODE_ONE -> RepeatMode.ONE
                Player.REPEAT_MODE_ALL -> RepeatMode.ALL
                else -> RepeatMode.OFF
            },
            speed = player.playbackParameters.speed,
            pitch = player.playbackParameters.pitch,
            volume = volume,
            waveActive = currentItem?.let { RiffMediaItems.isWaveActive(it) } ?: false,
            error = null,
            connected = true,
        )
    }

    companion object {
        /** 4 ticks/second: the desktop scrubber updated roughly this often. */
        const val POSITION_TICK_MS = 500L
    }
}
