package com.riff.android.core.player

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource

/**
 * Track -> MediaItem conversion.
 *
 * Every queue item uses the stable `riff://track/<id>` uri so the queue survives
 * process death and the actual media (local file, `content://` import, or a freshly
 * extracted http URL) is resolved lazily by [RiffUriResolver] — mirroring the
 * desktop flow where `/api/stream-info` is called when a track actually starts.
 *
 * The whole [Track] travels in the item extras, so reordering the queue or restoring
 * the session never requires a database round trip.
 */
@UnstableApi
object RiffMediaItems {

    const val EXTRA_TITLE = "riff.title"
    const val EXTRA_ARTIST = "riff.artist"
    const val EXTRA_ALBUM = "riff.album"
    const val EXTRA_DURATION = "riff.durationMs"
    const val EXTRA_SOURCE = "riff.source"
    const val EXTRA_SOURCE_ID = "riff.sourceId"
    const val EXTRA_SOURCE_URL = "riff.sourceUrl"
    const val EXTRA_SEARCH_QUERY = "riff.searchQuery"
    const val EXTRA_LOCAL_URI = "riff.localUri"
    const val EXTRA_ARTWORK = "riff.artwork"
    const val EXTRA_FAVORITE = "riff.favorite"
    const val EXTRA_CONTEXT_KEY = "riff.contextKey"
    const val EXTRA_WAVE_ACTIVE = "riff.wave"

    fun toMediaItem(
        track: Track,
        context: PlaybackContext,
        waveActive: Boolean = false,
    ): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .setAlbumTitle(track.album)
            .setArtworkUri(track.artworkUri?.let { android.net.Uri.parse(it) })
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setDurationMs(track.durationMs.takeIf { it > 0 })
            .setExtras(
                android.os.Bundle().apply {
                    putString(EXTRA_TITLE, track.title)
                    putString(EXTRA_ARTIST, track.artist)
                    putString(EXTRA_ALBUM, track.album)
                    putLong(EXTRA_DURATION, track.durationMs)
                    putString(EXTRA_SOURCE, track.source.id)
                    putString(EXTRA_SOURCE_ID, track.sourceId)
                    putString(EXTRA_SOURCE_URL, track.sourceUrl)
                    putString(EXTRA_SEARCH_QUERY, track.searchQuery)
                    putString(EXTRA_LOCAL_URI, track.localUri)
                    putString(EXTRA_ARTWORK, track.artworkUri)
                    putBoolean(EXTRA_FAVORITE, track.favorite)
                    putString(EXTRA_CONTEXT_KEY, contextKey(context))
                    putBoolean(EXTRA_WAVE_ACTIVE, waveActive)
                },
            )
            .build()

        return MediaItem.Builder()
            .setMediaId(track.id)
            .setUri(track.playableUri)
            .setMediaMetadata(metadata)
            .build()
    }

    /** Rebuilds the [Track] without touching the database (extras are authoritative). */
    fun toTrack(item: MediaItem): Track {
        val extras = item.mediaMetadata.extras
        val title = extras?.getString(EXTRA_TITLE) ?: item.mediaMetadata.title?.toString().orEmpty()
        val artist = extras?.getString(EXTRA_ARTIST) ?: item.mediaMetadata.artist?.toString().orEmpty()
        val album = extras?.getString(EXTRA_ALBUM) ?: item.mediaMetadata.albumTitle?.toString()
        val duration = extras?.getLong(EXTRA_DURATION, 0L) ?: (item.mediaMetadata.durationMs ?: 0L)
        val localUri = extras?.getString(EXTRA_LOCAL_URI)
        val artwork = extras?.getString(EXTRA_ARTWORK) ?: item.mediaMetadata.artworkUri?.toString()

        return Track(
            id = item.mediaId,
            title = title.ifBlank { "untitled" },
            artist = artist.ifBlank { UNKNOWN_ARTIST },
            album = album,
            durationMs = duration,
            artworkUri = artwork,
            source = TrackSource.fromId(extras?.getString(EXTRA_SOURCE)),
            sourceId = extras?.getString(EXTRA_SOURCE_ID),
            sourceUrl = extras?.getString(EXTRA_SOURCE_URL),
            searchQuery = extras?.getString(EXTRA_SEARCH_QUERY),
            localUri = localUri,
            favorite = extras?.getBoolean(EXTRA_FAVORITE) ?: false,
        )
    }

    fun contextKey(context: PlaybackContext): String = when (context) {
        PlaybackContext.None -> "none"
        PlaybackContext.Search -> "search"
        PlaybackContext.Favorites -> "favorites"
        PlaybackContext.History -> "history"
        PlaybackContext.Library -> "library"
        PlaybackContext.Downloads -> "downloads"
        PlaybackContext.Queue -> "queue"
        PlaybackContext.MyWave -> "wave"
        is PlaybackContext.PlaylistContext -> "playlist:${context.playlistId}"
        is PlaybackContext.ArtistContext -> "artist:${context.name}"
    }

    fun contextFromKey(key: String?): PlaybackContext = when {
        key == null -> PlaybackContext.None
        key == "none" -> PlaybackContext.None
        key == "search" -> PlaybackContext.Search
        key == "favorites" -> PlaybackContext.Favorites
        key == "history" -> PlaybackContext.History
        key == "library" -> PlaybackContext.Library
        key == "downloads" -> PlaybackContext.Downloads
        key == "queue" -> PlaybackContext.Queue
        key == "wave" -> PlaybackContext.MyWave
        key.startsWith("playlist:") -> PlaybackContext.PlaylistContext(key.removePrefix("playlist:"), "")
        key.startsWith("artist:") -> PlaybackContext.ArtistContext(key.removePrefix("artist:"))
        else -> PlaybackContext.None
    }

    fun isWaveActive(item: MediaItem): Boolean =
        item.mediaMetadata.extras?.getBoolean(EXTRA_WAVE_ACTIVE) == true

    private const val UNKNOWN_ARTIST = "unknown artist"
}
