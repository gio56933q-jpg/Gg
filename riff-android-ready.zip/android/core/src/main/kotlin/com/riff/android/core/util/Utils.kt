package com.riff.android.core.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Shared OkHttp client, replacing the desktop's `fetch()`/`node-fetch` calls.
 *
 * The desktop server sends a desktop User-Agent for yt-dlp/lrclib/Wikipedia
 * requests; the same header is used here because some endpoints (Wikipedia REST,
 * lrclib) behave differently for unknown clients.
 */
object HttpClientProvider {

    const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(45, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}

/** Connectivity helper — used by the download worker's "Wi-Fi only" option. */
object NetworkMonitor {

    fun isOnline(context: Context): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun isUnmetered(context: Context): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }
}

/** `formatBytes()` from app.js (cache modal) — decimal units like the desktop version. */
object Bytes {
    fun format(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = listOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var index = 0
        while (value >= 1024 && index < units.lastIndex) {
            value /= 1024.0
            index++
        }
        return if (index == 0) "${bytes} B" else "%.1f %s".format(value, units[index])
    }
}

/** Duration formatting — `formatTime()` in app.js (`m:ss`, `h:mm:ss`). */
object TimeFormat {
    fun clock(totalSeconds: Long): String {
        val seconds = totalSeconds.coerceAtLeast(0)
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, secs) else "%d:%02d".format(minutes, secs)
    }

    fun clockMs(millis: Long): String = clock(millis / 1000)
}

/** Audio mime helpers — port of the `/api/local-track` mime table in server.js. */
object AudioMime {

    fun contentTypeForPath(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "opus" -> "audio/ogg; codecs=opus"
        "webm" -> "audio/webm"
        "m4a" -> "audio/mp4"
        "mp3" -> "audio/mpeg"
        "flac" -> "audio/flac"
        "wav" -> "audio/wav"
        else -> "audio/mpeg"
    }

    fun extensionFor(contentType: String?, fallback: String = "opus"): String = when {
        contentType == null -> fallback
        contentType.contains("webm") -> "webm"
        contentType.contains("mp4") || contentType.contains("m4a") -> "m4a"
        contentType.contains("mpeg") -> "mp3"
        contentType.contains("flac") -> "flac"
        contentType.contains("wav") -> "wav"
        else -> fallback
    }
}
