package com.riff.android.core.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Album artwork with the desktop's fallback treatment (`right-panel-cover-fallback`,
 * `artwork-fallback`): a surface container with a music glyph when no image exists.
 * Remote artwork is cached by Coil (the desktop caches thumbnails in `thumbnails/`).
 */
@Composable
fun RiffArtwork(
    uri: String?,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 12.dp,
    contentDescription: String? = null,
    placeholderColor: Color = MaterialTheme.colorScheme.surfaceContainerHigh,
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier.clip(shape).background(placeholderColor),
        contentAlignment = Alignment.Center,
    ) {
        if (uri.isNullOrBlank()) {
            Icon(
                imageVector = Icons.Filled.MusicNote,
                contentDescription = contentDescription,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(6.dp).fillMaxSize(0.5f),
            )
        } else {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(uri)
                    .crossfade(true)
                    .build(),
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/**
 * 2x2 playlist mosaic — port of `renderPlaylistCover()` in app.js: up to four
 * covers in a grid, or a single cover enlarged when the playlist is small.
 */
@Composable
fun RiffPlaylistCover(
    covers: List<String>,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 12.dp,
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(modifier = modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
        when {
            covers.isEmpty() -> RiffArtwork(null, Modifier.fillMaxSize(), cornerRadius)
            covers.size == 1 -> RiffArtwork(covers[0], Modifier.fillMaxSize(), cornerRadius)
            else -> androidx.compose.foundation.layout.Column(Modifier.fillMaxSize()) {
                androidx.compose.foundation.layout.Row(Modifier.weight(1f)) {
                    RiffArtwork(covers.getOrNull(0), Modifier.weight(1f).fillMaxSize(), 0.dp)
                    RiffArtwork(covers.getOrNull(1), Modifier.weight(1f).fillMaxSize(), 0.dp)
                }
                androidx.compose.foundation.layout.Row(Modifier.weight(1f)) {
                    RiffArtwork(covers.getOrNull(2) ?: covers.getOrNull(0), Modifier.weight(1f).fillMaxSize(), 0.dp)
                    RiffArtwork(covers.getOrNull(3) ?: covers.getOrNull(1), Modifier.weight(1f).fillMaxSize(), 0.dp)
                }
            }
        }
    }
}
