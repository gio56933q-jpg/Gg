package com.riff.android.core

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.google.common.truth.Truth.assertThat
import com.riff.android.core.player.RiffMediaItems
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Track <-> MediaItem mapping on a real device.
 *
 * The whole media session (notification, lock screen, Bluetooth metadata, resuming the
 * queue after process death) depends on this mapping: if a field is lost, the lock
 * screen shows the wrong artist or a downloaded track loses its offline uri. Media3
 * types are Android classes, so this runs as an instrumentation test.
 */
@RunWith(AndroidJUnit4::class)
class RiffMediaItemsTest {

    private fun track() = Track(
        id = "youtube:abc",
        title = "Song",
        artist = "Artist",
        album = "Album",
        durationMs = 213_000,
        artworkUri = "https://img/cover.jpg",
        source = TrackSource.YOUTUBE,
        sourceId = "abc",
        sourceUrl = "https://youtube.com/watch?v=abc",
        localUri = "file:///music/Artist - Song.opus",
        downloadedAt = 1_700_000_000_000,
        fileSizeBytes = 4_000_000,
        favorite = true,
        lastPlayedAt = 1_700_000_100_000,
        playCount = 3,
    )

    @Test
    fun toMediaItemCarriesTheSessionMetadata() {
        val item = RiffMediaItems.toMediaItem(track(), PlaybackContext.MyWave, waveActive = true)

        assertThat(item.mediaId).isEqualTo("youtube:abc")
        assertThat(item.mediaMetadata.title.toString()).isEqualTo("Song")
        assertThat(item.mediaMetadata.artist.toString()).isEqualTo("Artist")
        assertThat(item.mediaMetadata.albumTitle.toString()).isEqualTo("Album")
        assertThat(item.mediaMetadata.artworkUri.toString()).isEqualTo("https://img/cover.jpg")
    }

    @Test
    fun toMediaItemUsesTheLocalFileWhenTheTrackIsDownloaded() {
        val downloaded = RiffMediaItems.toMediaItem(track(), PlaybackContext.Library)
        assertThat(downloaded.localConfiguration?.uri.toString())
            .isEqualTo("file:///music/Artist - Song.opus")

        val streamed = RiffMediaItems.toMediaItem(track().copy(localUri = null, downloadedAt = null), PlaybackContext.Library)
        // No local file: a lazy `riff://` uri that the media session resolves to a stream.
        assertThat(streamed.localConfiguration?.uri.toString()).startsWith("riff://track/")
    }

    @Test
    fun toTrackRebuildsTheDomainObjectWithoutTheDatabase() {
        val original = track()
        val restored = RiffMediaItems.toTrack(RiffMediaItems.toMediaItem(original, PlaybackContext.Favorites))

        assertThat(restored).isNotNull()
        assertThat(restored!!.id).isEqualTo(original.id)
        assertThat(restored.title).isEqualTo(original.title)
        assertThat(restored.artist).isEqualTo(original.artist)
        assertThat(restored.album).isEqualTo(original.album)
        assertThat(restored.durationMs).isEqualTo(original.durationMs)
        assertThat(restored.artworkUri).isEqualTo(original.artworkUri)
        assertThat(restored.localUri).isEqualTo(original.localUri)
        assertThat(restored.favorite).isTrue()
        assertThat(restored.source).isEqualTo(TrackSource.YOUTUBE)
    }

    @Test
    fun uriResolutionUsesTheLocalFileFirstWhenOffline() {
        // Offline-first requirement: a downloaded track must never need the network.
        val downloaded = RiffMediaItems.toMediaItem(track(), PlaybackContext.Downloads)
        val value = downloaded.localConfiguration?.uri.toString().orEmpty()
        assertThat(value.startsWith("file://") || value.startsWith("content://")).isTrue()
    }

    @Test
    fun playingAQueueOfMixedSourcesKeepsIdsStable() {
        val items = listOf(
            track(),
            track().copy(id = "soundcloud:xyz", source = TrackSource.SOUNDCLOUD, sourceId = "xyz", localUri = null),
            track().copy(id = "local:7", source = TrackSource.LOCAL, sourceId = null, localUri = "content://media/7"),
        ).map { RiffMediaItems.toMediaItem(it, PlaybackContext.Queue) }

        assertThat(items.map { it.mediaId })
            .containsExactly("youtube:abc", "soundcloud:xyz", "local:7").inOrder()
        assertThat(items.mapNotNull { it.localConfiguration?.uri.toString() }.distinct()).hasSize(3)
    }
}
