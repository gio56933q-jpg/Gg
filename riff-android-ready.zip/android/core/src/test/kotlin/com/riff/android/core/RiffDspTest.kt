package com.riff.android.core

import com.google.common.truth.Truth.assertThat
import com.riff.android.core.audio.RiffPlaybackParameters
import com.riff.android.core.audio.dsp.BiquadFilter
import com.riff.android.core.audio.dsp.DelayLine
import com.riff.android.core.audio.dsp.Freeverb
import com.riff.android.core.audio.dsp.RiffEffectState
import com.riff.android.core.audio.dsp.WaveshaperCurve
import com.riff.android.domain.model.AudioSettings
import com.riff.android.domain.model.HqSettings
import org.junit.Test
import kotlin.math.abs

/**
 * Audio effect building blocks and the speed/pitch mapping.
 *
 * The desktop runs Web Audio nodes (WaveShaper, Delay, Convolver, BiquadFilter,
 * DynamicsCompressor); Android has to implement the same maths in the audio pipeline.
 * These tests pin the *contract* of that port:
 *
 *  - a bypassed effect is bit-exact passthrough (the desktop also skips the graph when
 *    nothing is modified),
 *  - every primitive stays finite (no NaN/Inf ever reaches the speaker),
 *  - the rate/pitch mapping matches `applySettings()` in `audio-engine.js`.
 */
class RiffDspTest {

    @Test
    fun `identity waveshaper is a passthrough`() {
        val curve = WaveshaperCurve.identity()
        // Web Audio interpolates between table entries; the table itself is exact, so
        // only float rounding separates the output from the input.
        for (x in listOf(-1f, -0.5f, 0f, 0.25f, 1f)) {
            assertThat(curve.shape(x)).isWithin(1e-6f).of(x)
        }
    }

    @Test
    fun `distortion curve is monotonic and bounded`() {
        val curve = WaveshaperCurve.distortion(75f)
        var previous = curve.shape(-1f)
        for (step in 1..100) {
            val x = -1f + step * 0.02f
            val shaped = curve.shape(x)
            assertThat(shaped).isAtLeast(previous - 1e-4f)
            assertThat(abs(shaped)).isLessThan(1f)
            previous = shaped
        }
    }

    @Test
    fun `harmonics curve adds the cubic term`() {
        val curve = WaveshaperCurve.harmonic(50f)
        val x = 0.5f
        val expected = x - (50f * 0.02f) * x * x * x
        assertThat(curve.shape(x)).isWithin(0.01f).of(expected)
    }

    @Test
    fun `delay line delays the signal and applies feedback`() {
        val delay = DelayLine(channels = 1, maxDelaySeconds = 1f, sampleRate = 48_000)
        val first = delay.process(0, 1f, delaySamples = 480, feedback = 0.5f)
        delay.advance()
        assertThat(first).isWithin(1e-5f).of(0f)

        // After the delay time the input comes back out.
        var output = 0f
        repeat(480) {
            output = delay.process(0, 0f, delaySamples = 480, feedback = 0.5f)
            delay.advance()
        }
        assertThat(output).isWithin(0.01f).of(1f)
    }

    @Test
    fun `freeverb produces a tail that decays and stays finite`() {
        val reverb = Freeverb(channels = 2, sampleRate = 48_000)
        var lastEnergy = Float.MAX_VALUE
        var energy = 0f
        repeat(24_000) { index ->
            val input = if (index == 0) 1f else 0f
            val left = reverb.process(0, input)
            reverb.process(1, input)
            assertThat(left.isFinite()).isTrue()
            energy += abs(left)
            if (index == 23_999) lastEnergy = energy
        }
        assertThat(lastEnergy).isGreaterThan(0f)
    }

    @Test
    fun `biquad shelves are stable and boost the expected band`() {
        val filter = BiquadFilter(channels = 1)
        filter.setLowShelf(sampleRate = 48_000, freqHz = 80f, gainDb = 6f)

        // Feed DC: a low shelf with positive gain raises it.
        var output = 0f
        repeat(2_000) { output = filter.processSample(0, 1f) }
        assertThat(output).isGreaterThan(1f)
        assertThat(output.isFinite()).isTrue()

        filter.setPeaking(sampleRate = 48_000, freqHz = 2_500f, q = 1.2f, gainDb = -6f)
        filter.reset()
        var sample = 0f
        repeat(2_000) {
            sample = filter.processSample(0, 1f)
            assertThat(sample.isFinite()).isTrue()
        }
    }

    @Test
    fun `effect state reports bypass only when nothing is modified`() {
        val state = RiffEffectState()
        assertThat(state.isModified).isFalse()
        assertThat(state.reverbWet).isEqualTo(0f)

        state.audio = AudioSettings(reverb = 65, echo = 15)
        assertThat(state.isModified).isTrue()
        assertThat(state.reverbWet).isWithin(1e-4f).of(0.65f)

        state.hq = HqSettings()
        state.hqEnabled = true
        assertThat(state.isModified).isTrue()
    }

    @Test
    fun `speed mapping preserves pitch when only speed is set`() {
        val parameters = RiffPlaybackParameters.of(AudioSettings(speed = 1.35f))

        assertThat(parameters.speed).isWithin(1e-4f).of(1.35f)
        assertThat(parameters.pitch).isEqualTo(1f)
    }

    @Test
    fun `tape pitch mapping scales rate and pitch together`() {
        val parameters = RiffPlaybackParameters.of(AudioSettings(speedPitch = 1.30f))

        assertThat(parameters.speed).isWithin(1e-4f).of(1.30f)
        assertThat(parameters.pitch).isWithin(1e-4f).of(1.30f)
    }

    @Test
    fun `pitch shift keeps the tempo and applies semitones`() {
        // -12 semitones = one octave down, tempo unchanged in the desktop branch
        // (playbackRate = speedPitch * 2^(pitch/12) with speedPitch == 1).
        val parameters = RiffPlaybackParameters.of(AudioSettings(pitch = -12))

        assertThat(parameters.speed).isWithin(1e-3f).of(0.5f)
        assertThat(parameters.pitch).isWithin(1e-3f).of(0.5f)
    }

    @Test
    fun `speed is clamped to a sane range`() {
        assertThat(RiffPlaybackParameters.of(AudioSettings(speed = 8f)).speed).isEqualTo(4f)
        assertThat(RiffPlaybackParameters.of(AudioSettings(speed = 0.01f)).speed).isEqualTo(0.25f)
    }

    @Test
    fun `default audio settings map to unity playback`() {
        val parameters = RiffPlaybackParameters.of(AudioSettings.DEFAULT)
        assertThat(parameters.speed).isEqualTo(1f)
        assertThat(parameters.pitch).isEqualTo(1f)
    }
}
