package com.riff.android.data.provider

import com.riff.android.core.util.HttpClientProvider
import com.riff.android.domain.model.BackendSettings
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.repo.MusicSearchProvider
import com.riff.android.domain.repo.SettingsRepository
import com.riff.android.domain.repo.StreamResolutionException
import com.riff.android.domain.repo.StreamResolver
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Request
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo

/**
 * On-device stream resolution with NewPipeExtractor — the replacement for
 * `yt-dlp -g -f bestaudio/ba/b` in `handleStreamInfo()` (server.js).
 *
 * Selection order mirrors yt-dlp's `bestaudio/ba/b`:
 *  1. progressive audio-only streams (muxed audio, directly seekable),
 *  2. DASH audio-only streams (highest bitrate wins — `bestaudio`),
 *  3. the HLS manifest ([StreamInfo.getHlsUrl]), which ExoPlayer plays natively,
 *  4. the DASH manifest, as a last resort.
 *
 * If extraction fails completely the desktop falls back to a SoundCloud search for
 * `"<artist> <title>"`; [SoundCloudFallbackResolver] reproduces that behaviour.
 */
class NewPipeStreamResolver : StreamResolver {

    override val id: String = "newpipe"

    override suspend fun resolve(track: Track): String = withContext(Dispatchers.IO) {
        val sourceUrl = track.sourceUrl?.takeIf { it.isNotBlank() }
            ?: throw StreamResolutionException("track has no source url to extract from")

        NewPipeService.ensureInitialized()
        val service = when (track.source) {
            TrackSource.SOUNDCLOUD -> ServiceList.SoundCloud
            else -> ServiceList.YouTube
        }

        val info = runCatching { StreamInfo.getInfo(service, sourceUrl) }.getOrElse { error ->
            throw StreamResolutionException("extraction failed: ${error.message}", error)
        }

        chooseStream(info) ?: throw StreamResolutionException("no playable audio stream found")
    }

    /** Shared by the direct and the fallback path. */
    private fun chooseStream(info: StreamInfo): String? {
        val audioOnly = info.audioStreams.orEmpty()
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP || it.deliveryMethod == DeliveryMethod.DASH }
            .sortedWith(compareByDescending<org.schabi.newpipe.extractor.stream.AudioStream> { it.averageBitrate }
                .thenByDescending { it.bitrate })

        audioOnly.forEach { stream ->
            val url = runCatching { stream.content }.getOrNull()?.takeIf { it.isNotBlank() }
            if (url != null) return url
            val manifest = runCatching { stream.manifestUrl }.getOrNull()?.takeIf { it.isNotBlank() }
            if (manifest != null) return manifest
        }

        info.hlsUrl?.takeIf { it.isNotBlank() }?.let { return it }
        info.dashMpdUrl?.takeIf { it.isNotBlank() }?.let { return it }
        return null
    }
}

/**
 * Desktop parity fallback (`handleStreamInfo`): when the original url cannot be
 * extracted, search SoundCloud for `"<artist> <title>"` and play the best hit.
 * Only used when the primary resolver failed — never as the first choice.
 */
class SoundCloudFallbackResolver(
    private val searchProvider: MusicSearchProvider,
) : StreamResolver {

    override val id: String = "soundcloud-fallback"

    override suspend fun resolve(track: Track): String = withContext(Dispatchers.IO) {
        val query = "${track.artist} ${track.title}".trim()
        if (query.isBlank()) throw StreamResolutionException("nothing to search for")

        val hit = searchProvider.search(query, limit = 5)
            .firstOrNull { it.id != track.id } ?: throw StreamResolutionException("no SoundCloud match for '$query'")

        val service = ServiceList.SoundCloud
        val url = hit.sourceUrl ?: throw StreamResolutionException("SoundCloud hit has no url")
        val info = runCatching { StreamInfo.getInfo(service, url) }.getOrElse { error ->
            throw StreamResolutionException("fallback extraction failed: ${error.message}", error)
        }
        val stream = info.audioStreams.orEmpty()
            .sortedByDescending { it.averageBitrate }
            .firstNotNullOfOrNull { runCatching { it.content }.getOrNull()?.takeIf { s -> s.isNotBlank() } }
            ?: info.hlsUrl?.takeIf { it.isNotBlank() }
            ?: throw StreamResolutionException("fallback produced no stream")
        stream
    }
}

/**
 * Stream resolution through a running Riff backend.
 *
 * `POST /api/stream-info` (server.js) answers
 * `{success, isLocal, streamUrl, isHls, proxyUrl}` — when the backend has the file
 * cached it serves `/api/local-track?id=…` (HTTP range support), otherwise it runs
 * yt-dlp and returns the extracted url, cached for 2 hours.
 */
class RiffServerStreamResolver(
    private val baseUrlProvider: suspend () -> String = { "" },
) : StreamResolver {

    override val id: String = "riff-server"

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun resolve(track: Track): String = withContext(Dispatchers.IO) {
        val base = baseUrlProvider().trimEnd('/')
        if (base.isBlank()) throw StreamResolutionException("no Riff server configured")

        val url = buildString {
            append(base)
            append("/api/stream-info?url=").append(TrackText.urlEncode(track.sourceUrl.orEmpty()))
            append("&id=").append(TrackText.urlEncode(track.sourceId ?: track.id))
            append("&platform=").append(track.source.id)
            append("&title=").append(TrackText.urlEncode(track.title))
            append("&artist=").append(TrackText.urlEncode(track.artist))
            append("&duration=").append(track.durationSeconds)
            append("&thumbnail=").append(TrackText.urlEncode(track.artworkUri.orEmpty()))
        }

        runCatching {
            val request = Request.Builder().url(url).header("User-Agent", HttpClientProvider.USER_AGENT).build()
            HttpClientProvider.client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val payload = json.decodeFromString(StreamInfoResponse.serializer(), body)
                when {
                    !payload.success -> throw StreamResolutionException(payload.error ?: "backend could not resolve the track")
                    payload.isLocal && payload.localId != null -> "$base/api/local-track?id=${TrackText.urlEncode(payload.localId)}"
                    payload.streamUrl != null -> payload.streamUrl
                    else -> throw StreamResolutionException("backend returned no stream url")
                }
            }
        }.getOrElse { error ->
            throw if (error is StreamResolutionException) error
            else StreamResolutionException("backend request failed: ${error.message}", error)
        }
    }

    @Serializable
    private data class StreamInfoResponse(
        val success: Boolean = false,
        val isLocal: Boolean = false,
        val localId: String? = null,
        val streamUrl: String? = null,
        val isHls: Boolean = false,
        val proxyUrl: String? = null,
        val error: String? = null,
    )
}

/**
 * Chooses the resolver from the user's backend setting.
 *
 * `ON_DEVICE` (default) uses NewPipeExtractor, `RIFF_SERVER` requires a configured
 * backend, and `AUTO` prefers the backend and silently falls back to the extractor.
 * Either way the UI and the playback service only ever see one [StreamResolver].
 */
class BackendAwareStreamResolver(
    private val settings: SettingsRepository,
    private val onDevice: StreamResolver,
    private val remote: StreamResolver,
    private val fallback: StreamResolver? = null,
) : StreamResolver {

    override val id: String = "composite"

    override suspend fun resolve(track: Track): String {
        // A downloaded/imported track never touches the network.
        track.localUri?.takeIf { it.isNotBlank() }?.let { return it }

        val backend = runCatching { settings.observeSettings().first().backend }.getOrNull() ?: BackendSettings()

        return when (backend.mode) {
            com.riff.android.domain.model.BackendMode.ON_DEVICE -> tryOnDevice(track)
            com.riff.android.domain.model.BackendMode.RIFF_SERVER ->
                if (backend.baseUrl.isBlank()) {
                    throw StreamResolutionException("no Riff server configured — switch to on-device mode or set a server url")
                } else {
                    remote.resolve(track)
                }
            com.riff.android.domain.model.BackendMode.AUTO ->
                if (backend.baseUrl.isNotBlank()) {
                    runCatching { remote.resolve(track) }.getOrElse { tryOnDevice(track) }
                } else {
                    tryOnDevice(track)
                }
        }
    }

    private suspend fun tryOnDevice(track: Track): String = try {
        onDevice.resolve(track)
    } catch (error: Exception) {
        val soundcloudFallback = fallback ?: throw error
        runCatching { soundcloudFallback.resolve(track) }.getOrElse { throw error }
    }

    /** Desktop prefetch: the first results are resolved in the background. */
    override suspend fun prefetch(track: Track) {
        runCatching { resolve(track) }
    }
}

/** Helper so the fallback resolver can be built without a second search provider. */
fun soundCloudFallback(searchProvider: MusicSearchProvider): StreamResolver =
    SoundCloudFallbackResolver(searchProvider)

/** The platforms the desktop app supports, used by the fallback wiring. */
val SUPPORTED_FALLBACK_PLATFORM: SearchPlatform = SearchPlatform.SOUNDCLOUD
