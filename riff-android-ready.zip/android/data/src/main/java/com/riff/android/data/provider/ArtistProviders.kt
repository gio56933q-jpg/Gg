package com.riff.android.data.provider

import com.riff.android.core.util.HttpClientProvider
import com.riff.android.domain.model.ArtistProfile
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.repo.ArtistInfoProvider
import com.riff.android.domain.text.SpamFilter
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Request
import java.util.concurrent.ConcurrentHashMap

/**
 * Artist profiles: Deezer (image, top tracks, verification) + Wikipedia (biography).
 *
 * Port of `fetchArtistInfo()` (server.js). Both sources are public and keyless, which
 * is why the desktop used them:
 *  - `https://api.deezer.com/search/artist?q=<name>` → artist id/avatar,
 *  - `https://api.deezer.com/artist/<id>/top?limit=25` → top tracks,
 *  - `https://en.wikipedia.org/api/rest_v1/page/summary/<name>` → biography.
 *
 * Differences from the desktop, documented in PORTING.md:
 *  - the desktop also tried YouTube Music scraping for the header image; the Deezer
 *    cover plus the Wikipedia thumbnail cover the same need,
 *  - tracks are attributed to YouTube with a `searchQuery` (`"<artist> - <title>
 *    official audio"`), exactly like the desktop, so playing them resolves through
 *    the normal search path instead of a second extractor.
 */
class DeezerArtistProvider(
    private val ttlMs: Long = 30 * 60 * 1000L,
) : ArtistInfoProvider {

    override val id: String = "deezer"

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val cache = ConcurrentHashMap<String, CacheEntry>()

    private class CacheEntry(val profile: ArtistProfile, val fetchedAt: Long) {
        fun isFresh(ttl: Long) = System.currentTimeMillis() - fetchedAt < ttl
    }

    override suspend fun lookup(artistName: String): ArtistProfile? = withContext(Dispatchers.IO) {
        val clean = TrackText.cleanArtistForLookup(artistName)
        if (clean.isBlank()) return@withContext null

        cache[clean.lowercase()]?.let { if (it.isFresh(ttlMs)) return@withContext it.profile }

        val search = runCatching {
            val body = get("https://api.deezer.com/search/artist?q=${TrackText.urlEncode(clean)}")
            json.decodeFromString(DeezerArtistSearch.serializer(), body)
        }.getOrNull() ?: DeezerArtistSearch()

        val top = search.data.firstOrNull()
        val tracks = top?.let { artist -> topTracks(artist, clean) }.orEmpty()
        val wiki = wikipedia(clean)

        val profile = ArtistProfile(
            name = top?.name?.takeIf { it.isNotBlank() } ?: clean,
            bio = wiki?.extract?.takeIf { it.isNotBlank() } ?: "no biography available for this artist.",
            avatarUri = top?.pictureXl ?: top?.pictureBig ?: top?.pictureMedium ?: wiki?.thumbnail?.source,
            verified = (top?.nbFan ?: 0) > 30_000 || wiki != null,
            tracks = tracks,
            followers = top?.nbFan ?: 0,
        )

        cache[clean.lowercase()] = CacheEntry(profile, System.currentTimeMillis())
        profile
    }

    private fun topTracks(artist: DeezerArtist, fallbackName: String): List<Track> = runCatching {
        val body = get("https://api.deezer.com/artist/${artist.id}/top?limit=25")
        val payload = json.decodeFromString(DeezerTop.serializer(), body)
        payload.data
            .filter { !SpamFilter.isSpamOrUnofficial(it.title, it.duration, fallbackName) }
            .map { hit ->
                val title = hit.title.ifBlank { "untitled" }
                Track(
                    id = "dz_${hit.id}",
                    title = title,
                    artist = hit.artist?.name?.takeIf { it.isNotBlank() } ?: fallbackName,
                    album = hit.album?.title,
                    durationMs = (hit.duration.takeIf { it > 0 } ?: 0) * 1000L,
                    artworkUri = hit.album?.coverBig ?: hit.album?.coverMedium ?: artist.pictureBig,
                    source = TrackSource.YOUTUBE,
                    sourceId = null,
                    sourceUrl = null,
                    // Desktop: artist tracks are played by searching YouTube for the
                    // official audio — no extra extraction step needed.
                    searchQuery = "$fallbackName - $title official audio",
                    addedAt = System.currentTimeMillis(),
                )
            }
    }.getOrElse { emptyList() }

    private fun wikipedia(name: String): WikiSummary? = runCatching {
        val body = get("https://en.wikipedia.org/api/rest_v1/page/summary/${TrackText.urlEncode(name)}")
        json.decodeFromString(WikiSummary.serializer(), body)
    }.getOrNull()

    private fun get(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", HttpClientProvider.USER_AGENT).build()
        HttpClientProvider.client.newCall(request).execute().use { response ->
            return response.body?.string().orEmpty()
        }
    }

    @Serializable
    private data class DeezerArtistSearch(val data: List<DeezerArtist> = emptyList())

    @Serializable
    private data class DeezerArtist(
        val id: Long = 0,
        val name: String? = null,
        val pictureXl: String? = null,
        val pictureBig: String? = null,
        val pictureMedium: String? = null,
        val nbFan: Long = 0,
    )

    @Serializable
    private data class DeezerTop(val data: List<DeezerTrack> = emptyList())

    @Serializable
    private data class DeezerTrack(
        val id: Long = 0,
        val title: String = "",
        val duration: Int = 0,
        val artist: DeezerArtistRef? = null,
        val album: DeezerAlbumRef? = null,
    )

    @Serializable
    private data class DeezerArtistRef(val name: String? = null)

    @Serializable
    private data class DeezerAlbumRef(
        val title: String? = null,
        val coverMedium: String? = null,
        val coverBig: String? = null,
    )

    @Serializable
    private data class WikiSummary(
        val extract: String? = null,
        val thumbnail: WikiImage? = null,
        val originalimage: WikiImage? = null,
    )

    @Serializable
    private data class WikiImage(val source: String? = null)
}
