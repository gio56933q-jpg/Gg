package com.riff.android.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Room schema replacing the desktop's `localStorage` documents plus the
 * `metadata.json` / `lyrics/` folders under `%LOCALAPPDATA%/Riff` (`platform.js`).
 */
@Database(
    entities = [
        TrackEntity::class,
        PlaylistEntity::class,
        PlaylistTrackEntity::class,
        HistoryEntity::class,
        DownloadEntity::class,
        LyricsEntity::class,
        SeenRecommendationEntity::class,
        QueueItemEntity::class,
        PlaybackStateEntity::class,
        ImportedFolderEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class RiffDatabase : RoomDatabase() {

    abstract fun tracks(): TrackDao
    abstract fun playlists(): PlaylistDao
    abstract fun history(): HistoryDao
    abstract fun downloads(): DownloadDao
    abstract fun lyrics(): LyricsDao
    abstract fun recommendations(): SeenRecommendationDao
    abstract fun playback(): PlaybackStateDao
    abstract fun importedFolders(): ImportedFolderDao

    companion object {
        const val NAME = "riff.db"

        fun build(context: Context): RiffDatabase =
            Room.databaseBuilder(context.applicationContext, RiffDatabase::class.java, NAME)
                .fallbackToDestructiveMigration()
                .build()

        /** Used by unit/instrumentation tests. */
        fun buildInMemory(context: Context): RiffDatabase =
            Room.inMemoryDatabaseBuilder(context, RiffDatabase::class.java)
                .allowMainThreadQueries()
                .build()
    }
}
