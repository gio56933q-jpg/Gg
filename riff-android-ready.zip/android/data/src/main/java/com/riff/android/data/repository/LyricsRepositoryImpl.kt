package com.riff.android.data.repository

import com.riff.android.data.local.LyricsEntity
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.toDomain
import com.riff.android.domain.lyrics.LrcParser
import com.riff.android.domain.model.Lyrics
import com.riff.android.domain.model.LyricsSource
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.LyricsProvider
import com.riff.android.domain.repo.LyricsRepository
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Lyrics repository — offline-first, exactly like the desktop two-tier cache:
 *
 *  1. **custom lyrics** (`custom-lyrics/<artist>_<title>.lrc`, edited by the user),
 *  2. **fetched lyrics** (`lyrics/<artist>___<title>.lrc`, written after a successful
 *     lookup so the next play works offline),
 *  3. a provider lookup (lrclib.net) when online lookups are enabled,
 *  4. empty → the UI shows "no lyrics found" instead of an error.
 *
 * Custom entries are never overwritten by a provider result, and deleting custom
 * lyrics falls back to the fetched copy — the same precedence the desktop has.
 */
class LyricsRepositoryImpl(
    private val database: RiffDatabase,
    private val providers: List<LyricsProvider>,
) : LyricsRepository {

    private val dao = database.lyrics()

    override suspend fun get(track: Track, allowOnline: Boolean): Lyrics = withContext(Dispatchers.IO) {
        val key = TrackText.lyricsKey(track.artist, track.title)
        val cached = dao.get(key)

        if (cached != null) {
            val parsed = cached.toDomain()
            if (cached.custom || !allowOnline || parsed.lines.isNotEmpty() || cached.content.isNotBlank()) {
                return@withContext parsed.copy(lines = LrcParser.parse(cached.content, key, parsed.source).lines)
            }
        }

        if (!allowOnline) return@withContext emptyLyrics(key)

        for (provider in providers) {
            if (!provider.isEnabled()) continue
            val raw = runCatching { provider.fetch(track) }.getOrNull()?.takeIf { it.isNotBlank() } ?: continue
            return@withContext cacheFetched(track, raw)
        }

        emptyLyrics(key)
    }

    override suspend fun saveCustom(track: Track, rawLyrics: String): Lyrics = withContext(Dispatchers.IO) {
        val key = TrackText.lyricsKey(track.artist, track.title)
        val now = System.currentTimeMillis()
        val parsed = LrcParser.parse(rawLyrics, key, LyricsSource.CUSTOM)
        dao.upsert(
            LyricsEntity(
                trackKey = key,
                content = rawLyrics,
                synced = parsed.synced || parsed.lines.any { it.isTimed },
                custom = true,
                source = LyricsSource.CUSTOM.name,
                updatedAt = now,
            ),
        )
        parsed.copy(updatedAt = now)
    }

    override suspend fun deleteCustom(track: Track) = withContext(Dispatchers.IO) {
        dao.deleteCustom(TrackText.lyricsKey(track.artist, track.title))
        Unit
    }

    override suspend fun cacheFetched(track: Track, rawLyrics: String): Lyrics = withContext(Dispatchers.IO) {
        val key = TrackText.lyricsKey(track.artist, track.title)
        val existing = dao.get(key)
        if (existing?.custom == true) return@withContext existing.toDomain()

        val now = System.currentTimeMillis()
        val parsed = LrcParser.parse(rawLyrics, key, LyricsSource.LRCLIB)
        dao.upsert(
            LyricsEntity(
                trackKey = key,
                content = rawLyrics,
                synced = parsed.lines.any { it.isTimed },
                custom = false,
                source = LyricsSource.LRCLIB.name,
                updatedAt = now,
            ),
        )
        parsed.copy(updatedAt = now)
    }

    override suspend fun hasCached(track: Track): Boolean = withContext(Dispatchers.IO) {
        val entity = dao.get(TrackText.lyricsKey(track.artist, track.title))
        entity != null && (entity.custom || entity.content.isNotBlank())
    }

    private fun emptyLyrics(key: String) = Lyrics(
        trackKey = key,
        lines = emptyList(),
        source = LyricsSource.NONE,
        synced = false,
        raw = "",
        updatedAt = 0L,
    )
}
