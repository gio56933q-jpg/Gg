package com.riff.android.data.repository

import com.riff.android.domain.model.Artist
import com.riff.android.domain.model.ArtistProfile
import com.riff.android.domain.repo.ArtistInfoProvider
import com.riff.android.domain.repo.ArtistRepository
import com.riff.android.domain.repo.LibraryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Artist profiles.
 *
 * Desktop equivalent: `openArtistProfile()` → `/api/artist` (Deezer search, top
 * tracks, Wikipedia bio) with an in-memory 30 minute cache in the server. Here the
 * provider owns the cache and this class only merges in the local library, so an
 * artist page still works with no connection.
 */
class ArtistRepositoryImpl(
    private val library: LibraryRepository,
    private val provider: ArtistInfoProvider,
) : ArtistRepository {

    override fun observeLocalArtists(): Flow<List<Artist>> = library.observeArtists()

    override suspend fun loadProfile(artistName: String): ArtistProfile? = withContext(Dispatchers.IO) {
        val remote = runCatching { provider.lookup(artistName) }.getOrNull()
        if (remote != null && remote.tracks.isNotEmpty()) return@withContext remote

        val localTrack = runCatching { library.searchLocal(artistName).first() }.getOrDefault(emptyList())
        if (localTrack.isEmpty() && remote == null) return@withContext null

        ArtistProfile(
            name = remote?.name ?: artistName,
            bio = remote?.bio ?: "showing tracks from your library — no online profile available.",
            avatarUri = remote?.avatarUri ?: localTrack.firstOrNull()?.artworkUri.orEmpty(),
            verified = remote?.verified ?: false,
            tracks = remote?.tracks.orEmpty().ifEmpty { localTrack },
            followers = remote?.followers ?: 0L,
        )
    }
}
