package com.riff.android.data.repository

import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.SeenRecommendationEntity
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.Track
import com.riff.android.domain.recommend.RecommendationEngine
import com.riff.android.domain.recommend.RecommendationResult
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.repo.RecommendationRepository
import com.riff.android.domain.repo.SearchRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * "My Wave" recommendations.
 *
 * The algorithm itself lives in `domain.recommend.RecommendationEngine` (a direct
 * port of `computeTasteProfile()` in app.js plus `buildDiscoveryQueries()` /
 * `scoreDiscoveryCandidate()` / `recommendVibeTracks()` in server.js). This
 * repository only supplies the inputs the server used to gather itself:
 *
 *  - `history[0:30]` and `favorites[0:25]` (the desktop slice sizes),
 *  - the recently-recommended windows (100 ids / 100 keys) — the desktop kept them
 *    in server memory, Android persists them so a restart does not repeat itself,
 *  - discovery searches, over SoundCloud exactly like `/api/vibe` did, with a YouTube
 *    fallback when SoundCloud returns nothing.
 */
class RecommendationRepositoryImpl(
    private val database: RiffDatabase,
    private val library: LibraryRepository,
    private val search: SearchRepository,
    private val engine: RecommendationEngine,
) : RecommendationRepository {

    private val seen = database.recommendations()

    override suspend fun recommend(limit: Int, extend: Boolean): RecommendationResult = withContext(Dispatchers.IO) {
        val history = runCatching { library.observeHistory().first() }.getOrDefault(emptyList()).take(HISTORY_SLICE)
        val favorites = runCatching { library.observeFavorites().first() }.getOrDefault(emptyList()).take(FAVORITES_SLICE)

        val seenIds = seen.values(KIND_ID, RecommendationEngine.SEEN_WINDOW).toSet()
        val seenKeys = seen.values(KIND_KEY, RecommendationEngine.SEEN_WINDOW).toSet()

        val result = engine.recommend(
            history = history,
            favorites = favorites,
            limit = limit.coerceIn(MIN_LIMIT, MAX_LIMIT),
            recentlyRecommendedIds = seenIds,
            recentlyRecommendedKeys = seenKeys,
            search = { query, count -> discover(query, count) },
        )

        if (result.tracks.isNotEmpty()) {
            remember(result.tracks)
            library.upsertAll(result.tracks)
        }
        result
    }

    override fun observeRecentlyRecommendedCount(): Flow<Int> = seen.observeCount()

    override suspend fun resetSeen() = withContext(Dispatchers.IO) {
        seen.clear()
    }

    /** Desktop `/api/vibe` searches SoundCloud; YouTube is the safety net. */
    private suspend fun discover(query: String, count: Int): List<Track> {
        val soundCloud = search.search(query, SearchPlatform.SOUNDCLOUD, count).tracks
        if (soundCloud.isNotEmpty()) return soundCloud
        return search.search(query, SearchPlatform.YOUTUBE, count).tracks
    }

    private suspend fun remember(tracks: List<Track>) {
        val now = System.currentTimeMillis()
        tracks.forEach { track ->
            seen.upsert(SeenRecommendationEntity(value = track.id, kind = KIND_ID, seenAt = now))
            track.normalizedKey.takeIf { it.isNotBlank() }?.let { key ->
                seen.upsert(SeenRecommendationEntity(value = key, kind = KIND_KEY, seenAt = now))
            }
        }
        seen.trim(KIND_ID, RecommendationEngine.SEEN_WINDOW)
        seen.trim(KIND_KEY, RecommendationEngine.SEEN_WINDOW)
    }

    private companion object {
        const val HISTORY_SLICE = 30
        const val FAVORITES_SLICE = 25
        const val MIN_LIMIT = 4
        const val MAX_LIMIT = 16
        const val KIND_ID = "id"
        const val KIND_KEY = "key"
    }
}
