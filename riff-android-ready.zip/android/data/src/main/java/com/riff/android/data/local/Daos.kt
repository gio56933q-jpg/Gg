package com.riff.android.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {

    @Query("SELECT * FROM tracks WHERE inLibrary = 1 ORDER BY addedAt DESC")
    fun observeLibrary(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE favorite = 1 ORDER BY favoritedAt DESC")
    fun observeFavorites(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE downloadedAt IS NOT NULL ORDER BY downloadedAt DESC")
    fun observeDownloads(): Flow<List<TrackEntity>>

    @Query(
        """
        SELECT t.* FROM tracks t
        INNER JOIN history h ON h.trackId = t.id
        ORDER BY h.playedAt DESC
        LIMIT :limit
        """,
    )
    fun observeHistoryOrdered(limit: Int): Flow<List<TrackEntity>>

    @Query(
        """
        SELECT * FROM tracks
        WHERE (:onlyLibrary = 0 OR inLibrary = 1)
          AND (LOWER(title) LIKE '%' || :needle || '%'
               OR LOWER(artist) LIKE '%' || :needle || '%'
               OR LOWER(COALESCE(album, '')) LIKE '%' || :needle || '%')
        ORDER BY
          CASE WHEN LOWER(title) LIKE :needle || '%' THEN 0 ELSE 1 END,
          LOWER(title)
        LIMIT :limit
        """,
    )
    suspend fun search(needle: String, onlyLibrary: Boolean, limit: Int = 200): List<TrackEntity>

    @Query(
        """
        SELECT artist AS name, COUNT(*) AS trackCount, MAX(COALESCE(artworkUri, '')) AS artworkUri
        FROM tracks WHERE artist != '' GROUP BY artist COLLATE NOCASE
        ORDER BY trackCount DESC, artist COLLATE NOCASE
        """,
    )
    fun observeArtists(): Flow<List<ArtistRow>>

    @Query(
        """
        SELECT COALESCE(album, 'Unknown album') AS name, artist, COUNT(*) AS trackCount,
               MAX(COALESCE(artworkUri, '')) AS artworkUri
        FROM tracks WHERE album IS NOT NULL AND album != '' GROUP BY name, artist COLLATE NOCASE
        ORDER BY name COLLATE NOCASE
        """,
    )
    fun observeAlbums(): Flow<List<AlbumRow>>

    @Query("SELECT * FROM tracks WHERE id = :id LIMIT 1")
    suspend fun get(id: String): TrackEntity?

    @Query("SELECT * FROM tracks WHERE normalizedKey = :key LIMIT 1")
    suspend fun findByKey(key: String): TrackEntity?

    @Query("SELECT * FROM tracks WHERE localUri IS NOT NULL")
    suspend fun local(): List<TrackEntity>

    @Query("SELECT COALESCE(SUM(fileSizeBytes), 0) FROM tracks WHERE downloadedAt IS NOT NULL")
    suspend fun totalDownloadBytes(): Long

    @Query("SELECT * FROM tracks")
    suspend fun all(): List<TrackEntity>

    @Query("SELECT * FROM tracks WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<String>): List<TrackEntity>

    @Upsert
    suspend fun upsert(entity: TrackEntity)

    @Upsert
    suspend fun upsertAll(entities: List<TrackEntity>)

    @Query("DELETE FROM tracks WHERE id = :id")
    suspend fun delete(id: String)
}

data class ArtistRow(val name: String, val trackCount: Int, val artworkUri: String?)

data class AlbumRow(val name: String, val artist: String, val trackCount: Int, val artworkUri: String?)

@Dao
interface PlaylistDao {

    @Query("SELECT * FROM playlists ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :playlistId LIMIT 1")
    fun observe(playlistId: String): Flow<PlaylistEntity?>

    @Query("SELECT * FROM playlists WHERE id = :playlistId LIMIT 1")
    suspend fun get(playlistId: String): PlaylistEntity?

    @Query(
        """
        SELECT t.* FROM tracks t
        INNER JOIN playlist_tracks pt ON pt.trackId = t.id
        WHERE pt.playlistId = :playlistId
        ORDER BY pt.position ASC
        """,
    )
    fun observeTracks(playlistId: String): Flow<List<TrackEntity>>

    @Query(
        """
        SELECT t.* FROM tracks t
        INNER JOIN playlist_tracks pt ON pt.trackId = t.id
        WHERE pt.playlistId = :playlistId
        ORDER BY pt.position ASC
        """,
    )
    suspend fun tracks(playlistId: String): List<TrackEntity>

    @Query("SELECT trackId FROM playlist_tracks WHERE playlistId = :playlistId ORDER BY position ASC")
    suspend fun trackIds(playlistId: String): List<String>

    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun count(playlistId: String): Int

    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = :playlistId")
    fun observeCount(playlistId: String): Flow<Int>

    @Query(
        """
        SELECT COALESCE(t.artworkUri, '') FROM playlist_tracks pt
        INNER JOIN tracks t ON t.id = pt.trackId
        WHERE pt.playlistId = :playlistId AND t.artworkUri IS NOT NULL
        ORDER BY pt.position ASC LIMIT :limit
        """,
    )
    suspend fun coverUris(playlistId: String, limit: Int = 4): List<String>

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun nextPosition(playlistId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrack(entity: PlaylistTrackEntity)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId")
    suspend fun removeTrack(playlistId: String, trackId: String)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun clearTracks(playlistId: String)

    @Update
    suspend fun updatePositions(rows: List<PlaylistTrackEntity>)

    @Upsert
    suspend fun upsertPlaylist(entity: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: String)

    /** Appends tracks at the end of the playlist (desktop `playlist.tracks.push`). */
    @Transaction
    suspend fun addTracks(playlistId: String, trackIds: List<String>, addedAt: Long) {
        var position = nextPosition(playlistId)
        trackIds.forEach { trackId ->
            insertTrack(PlaylistTrackEntity(playlistId, trackId, position, addedAt))
            position++
        }
    }

    /**
     * Reorders like the desktop drag & drop (`initListReordering`): take the item out
     * and insert it at the new index, then renumber everything.
     */
    @Transaction
    suspend fun moveTrack(playlistId: String, fromIndex: Int, toIndex: Int) {
        val current = trackIds(playlistId)
        if (fromIndex !in current.indices || toIndex !in current.indices || fromIndex == toIndex) return
        val reordered = current.toMutableList()
        val item = reordered.removeAt(fromIndex)
        reordered.add(toIndex, item)
        clearTracks(playlistId)
        var position = 0
        reordered.forEach { trackId ->
            insertTrack(PlaylistTrackEntity(playlistId, trackId, position, System.currentTimeMillis()))
            position++
        }
    }
}

@Dao
interface HistoryDao {

    @Query("SELECT * FROM history ORDER BY playedAt DESC LIMIT :limit")
    fun observe(limit: Int): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE trackId = :trackId LIMIT 1")
    suspend fun get(trackId: String): HistoryEntity?

    @Query("SELECT COUNT(*) FROM history")
    suspend fun count(): Int

    @Upsert
    suspend fun upsert(entity: HistoryEntity)

    @Query("DELETE FROM history")
    suspend fun clear()

    @Query("DELETE FROM history WHERE trackId = :trackId")
    suspend fun delete(trackId: String)

    /** Keeps the newest [limit] entries, exactly like `state.history.slice(0, 100)`. */
    @Query(
        """
        DELETE FROM history WHERE trackId IN (
            SELECT trackId FROM history ORDER BY playedAt DESC LIMIT -1 OFFSET :limit
        )
        """,
    )
    suspend fun trim(limit: Int)
}

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloads ORDER BY requestedAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE trackId = :trackId LIMIT 1")
    fun observe(trackId: String): Flow<DownloadEntity?>

    @Query("SELECT * FROM downloads WHERE state IN ('QUEUED', 'RUNNING') ORDER BY requestedAt ASC")
    fun observeActive(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE trackId = :trackId LIMIT 1")
    suspend fun get(trackId: String): DownloadEntity?

    @Upsert
    suspend fun upsert(entity: DownloadEntity)

    @Query("DELETE FROM downloads WHERE trackId = :trackId")
    suspend fun delete(trackId: String)

    @Query("DELETE FROM downloads WHERE state IN ('COMPLETED', 'FAILED', 'CANCELED')")
    suspend fun clearFinished()
}

@Dao
interface LyricsDao {

    @Query("SELECT * FROM lyrics WHERE trackKey = :trackKey LIMIT 1")
    suspend fun get(trackKey: String): LyricsEntity?

    @Upsert
    suspend fun upsert(entity: LyricsEntity)

    @Query("DELETE FROM lyrics WHERE trackKey = :trackKey AND custom = 1")
    suspend fun deleteCustom(trackKey: String)

    @Query("SELECT COUNT(*) FROM lyrics")
    suspend fun count(): Int
}

@Dao
interface SeenRecommendationDao {

    @Query("SELECT value FROM seen_recommendations WHERE kind = :kind ORDER BY seenAt DESC LIMIT :limit")
    suspend fun values(kind: String, limit: Int): List<String>

    @Query("SELECT COUNT(*) FROM seen_recommendations")
    fun observeCount(): Flow<Int>

    @Upsert
    suspend fun upsert(entity: SeenRecommendationEntity)

    @Query(
        """
        DELETE FROM seen_recommendations WHERE value IN (
            SELECT value FROM seen_recommendations WHERE kind = :kind ORDER BY seenAt DESC LIMIT -1 OFFSET :keep
        )
        """,
    )
    suspend fun trim(kind: String, keep: Int)

    @Query("DELETE FROM seen_recommendations")
    suspend fun clear()
}

@Dao
interface PlaybackStateDao {

    @Query("SELECT * FROM playback_state WHERE id = 1 LIMIT 1")
    fun observe(): Flow<PlaybackStateEntity?>

    @Query("SELECT * FROM playback_state WHERE id = 1 LIMIT 1")
    suspend fun get(): PlaybackStateEntity?

    @Upsert
    suspend fun upsert(entity: PlaybackStateEntity)

    @Query("SELECT * FROM queue_items ORDER BY position ASC")
    suspend fun queue(): List<QueueItemEntity>

    @Query("DELETE FROM queue_items")
    suspend fun clearQueue()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQueueItems(items: List<QueueItemEntity>)

    @Transaction
    suspend fun saveQueue(items: List<QueueItemEntity>) {
        clearQueue()
        insertQueueItems(items)
    }

    @Query("DELETE FROM playback_state")
    suspend fun clearState()
}

@Dao
interface ImportedFolderDao {

    @Query("SELECT path FROM imported_folders")
    fun observeAll(): Flow<List<String>>

    @Upsert
    suspend fun upsert(entity: ImportedFolderEntity)

    @Query("DELETE FROM imported_folders WHERE path = :path")
    suspend fun delete(path: String)
}
