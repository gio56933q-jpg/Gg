package com.riff.android.data.media

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.riff.android.core.util.AudioMime
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Importing the user's own audio.
 *
 * The desktop app only ever played its own cache directory, so there is no direct
 * equivalent; the requirement is a local library that also covers imported files.
 *
 * Two paths, both with minimal permissions:
 *  1. **SAF** (`ACTION_OPEN_DOCUMENT` / `ACTION_OPEN_DOCUMENT_TREE`, wired in the
 *     Library screen) — no permission at all, works on every API level and keeps the
 *     user in control. Imported files stay where they are; only a `content://`
 *     reference plus metadata is stored.
 *  2. **MediaStore scan** — optional, needs `READ_MEDIA_AUDIO` on API 33+ and
 *     `READ_EXTERNAL_STORAGE` on API ≤ 32, requested only when the user taps the
 *     scan button. `MANAGE_EXTERNAL_STORAGE` is never requested.
 */
class MediaStoreImporter(private val context: Context) {

    data class ImportedFile(
        val uri: String,
        val displayName: String?,
        val mimeType: String?,
        val sizeBytes: Long,
    )

    /** `ACTION_OPEN_DOCUMENT` result: one file the user picked. */
    suspend fun readFile(uri: Uri): ImportedFile? = withContext(Dispatchers.IO) {
        runCatching {
            var displayName: String? = null
            var size = 0L
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0 && !cursor.isNull(nameIndex)) displayName = cursor.getString(nameIndex)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
            ImportedFile(
                uri = uri.toString(),
                displayName = displayName ?: uri.lastPathSegment,
                mimeType = context.contentResolver.getType(uri),
                sizeBytes = size,
            )
        }.getOrNull()
    }

    suspend fun scan(excludedFolders: Set<String> = emptySet()): List<Track> = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATE_ADDED,
        )

        val tracks = mutableListOf<Track>()
        context.contentResolver.query(collection, projection, null, null, null)?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val albumIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

            while (cursor.moveToNext()) {
                val path = cursor.getString(dataColumn) ?: continue
                if (excludedFolders.any { path.startsWith(it) }) continue

                val id = cursor.getLong(idColumn)
                val uri = ContentUris.withAppendedId(collection, id)
                val duration = cursor.getLong(durationColumn)
                val albumId = cursor.getLong(albumIdColumn)

                tracks += Track(
                    id = "local:$id",
                    title = cursor.getString(titleColumn)?.takeIf { it.isNotBlank() } ?: path.substringAfterLast('/'),
                    artist = cursor.getString(artistColumn)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "unknown artist",
                    album = cursor.getString(albumColumn)?.takeIf { it.isNotBlank() && it != "<unknown>" },
                    durationMs = duration,
                    artworkUri = if (albumId > 0) {
                        ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId).toString()
                    } else {
                        null
                    },
                    source = TrackSource.LOCAL,
                    localUri = uri.toString(),
                    fileSizeBytes = cursor.getLong(sizeColumn),
                    addedAt = System.currentTimeMillis(),
                )
            }
        }
        tracks
    }

    /** True when the caller may read device audio (API dependent). */
    fun hasAudioPermission(): Boolean = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
            context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        else ->
            context.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /**
     * Builds a [Track] for an imported file.
     *
     * Filenames are the fallback (the desktop derived titles the same way for its own
     * cache: `artist - title.ext`), but tags win when the file has them — and an
     * embedded cover is written next to the app's data so artwork survives offline
     * (`filesDir/artwork/<hash>.jpg`, the Android counterpart of `thumbnails/`).
     */
    fun toTrack(file: ImportedFile, durationMs: Long = 0L): Track {
        val name = file.displayName?.substringBeforeLast('.') ?: "imported track"
        val parts = name.split(" - ", limit = 2)
        val fallbackArtist = if (parts.size == 2) parts[0].trim() else "unknown artist"
        val fallbackTitle = if (parts.size == 2) parts[1].trim() else name.trim()

        val embedded = readEmbeddedMetadata(file)
        return Track(
            id = "local:${file.uri.hashCode().toUInt()}",
            title = embedded?.title?.ifBlank { null } ?: fallbackTitle.ifBlank { name },
            artist = embedded?.artist?.ifBlank { null } ?: fallbackArtist,
            album = embedded?.album?.ifBlank { null },
            durationMs = if (durationMs > 0) durationMs else (embedded?.durationMs ?: 0L),
            artworkUri = embedded?.artworkUri,
            source = TrackSource.LOCAL,
            localUri = file.uri,
            fileSizeBytes = file.sizeBytes,
            addedAt = System.currentTimeMillis(),
        )
    }

    private data class EmbeddedMetadata(
        val title: String?,
        val artist: String?,
        val album: String?,
        val durationMs: Long,
        val artworkUri: String?,
    )

    /** `MediaMetadataRetriever` is the only public metadata API; failures are fine. */
    private fun readEmbeddedMetadata(file: ImportedFile): EmbeddedMetadata? = runCatching {
        val retriever = android.media.MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(file.uri))
            val duration = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            EmbeddedMetadata(
                title = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE),
                artist = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                album = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM),
                durationMs = duration,
                artworkUri = cacheEmbeddedArtwork(retriever, file),
            )
        } finally {
            runCatching { retriever.release() }
        }
    }.getOrNull()

    private fun cacheEmbeddedArtwork(
        retriever: android.media.MediaMetadataRetriever,
        file: ImportedFile,
    ): String? = runCatching {
        val bytes = retriever.embeddedPicture ?: return@runCatching null
        if (bytes.size < 1024) return@runCatching null
        val dir = java.io.File(context.filesDir, ARTWORK_DIR).apply { mkdirs() }
        val target = java.io.File(dir, "${file.uri.hashCode().toUInt()}.jpg")
        if (!target.exists()) target.writeBytes(bytes)
        Uri.fromFile(target).toString()
    }.getOrNull()

    companion object {
        const val MEDIA_AUDIO_PERMISSION = android.Manifest.permission.READ_MEDIA_AUDIO
        const val LEGACY_STORAGE_PERMISSION = android.Manifest.permission.READ_EXTERNAL_STORAGE

        /** Mime types accepted by the SAF pickers. */
        val AUDIO_MIME_TYPES = arrayOf(
            "audio/*",
            "audio/mpeg",
            "audio/mp4",
            "audio/ogg",
            "audio/flac",
            "audio/x-flac",
            "audio/wav",
            "audio/webm",
        )

        fun contentTypeFor(path: String): String = AudioMime.contentTypeForPath(path)

        /** Offline artwork cache (desktop kept thumbnails in `thumbnails/`). */
        const val ARTWORK_DIR = "artwork"
    }
}
