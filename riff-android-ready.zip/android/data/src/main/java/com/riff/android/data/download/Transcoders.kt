package com.riff.android.data.download

import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.repo.AudioTranscoder
import com.riff.android.domain.repo.TranscodeResult

/**
 * Default transcoder: leaves the file in the container the source provided.
 *
 * Why: the desktop app runs `ffmpeg -x --audio-format opus/mp3` through yt-dlp.
 * Android has no ffmpeg in the platform, the official FFmpegKit project was
 * retired (Jan 2025) and its maintained forks ship source-only or require adding
 * large AARs per ABI. ExoPlayer/MediaCodec play all containers we download
 * (opus/webm, m4a/aac, mp3, flac), so the default pipeline needs no transcode at
 * all. See android/PORTING.md for the full discussion and how to plug FfmpegKit
 * in (transcoding is isolated behind [AudioTranscoder]).
 */
class NoOpTranscoder : AudioTranscoder {
    override val id: String = "noop"
    override val available: Boolean = false

    override suspend fun transcode(
        sourcePath: String,
        targetFormat: DownloadFormat,
        quality: DownloadQuality,
    ): TranscodeResult = TranscodeResult.Skipped
}

/**
 * Looks up an optional, externally provided transcoder (for example a build with
 * `com.arthenica:ffmpeg-kit-*` / FFmpegKitNext wired in). The class is loaded by
 * name so the default APK stays free of the ~40 MB native payload.
 */
object Transcoders {

    private const val EXTERNAL_TRANSCODER_CLASS = "com.riff.android.data.ffmpeg.FfmpegKitTranscoder"

    fun default(): AudioTranscoder {
        val external = runCatching {
            val clazz = Class.forName(EXTERNAL_TRANSCODER_CLASS)
            clazz.getDeclaredConstructor().newInstance() as AudioTranscoder
        }.getOrNull()
        return external ?: NoOpTranscoder()
    }
}
