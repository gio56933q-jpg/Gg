package com.riff.android.data.provider

import com.riff.android.core.util.HttpClientProvider
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.repo.MusicSearchProvider
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Request
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/**
 * Search provider backed by NewPipeExtractor.
 *
 * Port of `handleSearch()` in server.js for the `ytsearch<n>:` / `scsearch<n>:`
 * branches, including the result shape: `{title, artist: uploader, duration,
 * thumbnail, url, platform}` — mapped here to the single domain [Track].
 *
 * The desktop also scraped `youtube.com/results` directly as a fast path; that is a
 * performance optimisation, not a behaviour, and NewPipe's search page is the same
 * data, so the Android app relies on the extractor alone (one code path, no
 * scraping to maintain).
 */
class NewPipeSearchProvider(
    override val platform: SearchPlatform,
) : MusicSearchProvider {

    override val id: String = "newpipe-${platform.id}"
    override val label: String = "On-device (${platform.label})"

    override suspend fun search(query: String, limit: Int): List<Track> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        NewPipeService.ensureInitialized()

        val service = when (platform) {
            SearchPlatform.YOUTUBE -> ServiceList.YouTube
            SearchPlatform.SOUNDCLOUD -> ServiceList.SoundCloud
        }

        runCatching {
            val extractor = service.getSearchExtractor(query)
            extractor.fetchPage()
            val items = extractor.initialPage?.items.orEmpty()
            items.filterIsInstance<StreamInfoItem>()
                .asSequence()
                .map { it.toTrack(platform) }
                .filter { it.title.isNotBlank() }
                .take(limit)
                .toList()
        }.getOrElse { emptyList() }
    }

    private fun StreamInfoItem.toTrack(platform: SearchPlatform): Track {
        val source = when (platform) {
            SearchPlatform.YOUTUBE -> TrackSource.YOUTUBE
            SearchPlatform.SOUNDCLOUD -> TrackSource.SOUNDCLOUD
        }
        val pageUrl = url
        val sourceId = when (platform) {
            SearchPlatform.YOUTUBE -> extractYouTubeId(pageUrl)
            SearchPlatform.SOUNDCLOUD -> pageUrl.substringAfterLast('/').ifBlank { null }
        }
        val durationMs = duration.takeIf { it > 0 }?.times(1000L) ?: 0L

        // Desktop picks the largest thumbnail (`thumbnails[0]` after the playlist
        // sort by height); NewPipe returns them largest first already, but be safe.
        val artwork = thumbnails.orEmpty()
            .filter { !it.url.isNullOrBlank() }
            .maxByOrNull { it.height }

        return Track(
            id = TrackText.canonicalId(source, sourceId, pageUrl, name, uploaderName, (durationMs / 1000L).toInt()),
            title = name,
            artist = uploaderName?.takeIf { it.isNotBlank() } ?: "unknown artist",
            album = null,
            durationMs = durationMs,
            artworkUri = artwork?.url,
            source = source,
            sourceId = sourceId,
            sourceUrl = pageUrl,
        )
    }

}

/**
 * YouTube video id extraction (`watch?v=`, `youtu.be/<id>` and `/shorts/<id>`).
 * Top-level and internal so the parsing rules can be unit tested without a network.
 */
internal fun extractYouTubeId(url: String?): String? {
    val value = url ?: return null
    val direct = Regex("""[?&]v=([A-Za-z0-9_-]{6,})""").find(value)?.groupValues?.getOrNull(1)
    if (direct != null) return direct
    return Regex("""(?:youtu\.be/|/shorts/)([A-Za-z0-9_-]{6,})""").find(value)?.groupValues?.getOrNull(1)
}

/**
 * Search provider for a running Riff backend (the desktop `server.js`).
 *
 * Endpoint: `GET /api/search?q=&platform=&limit=` — the exact contract the desktop
 * renderer consumes, including the `isCached` flag which is preserved through
 * [RemoteSearchHit.isCached] into the app's cache badge.
 */
class RiffServerSearchProvider(
    private val baseUrlProvider: suspend () -> String,
    override val platform: SearchPlatform,
) : MusicSearchProvider {

    override val id: String = "riff-server-${platform.id}"
    override val label: String = "Riff server (${platform.label})"

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun search(query: String, limit: Int): List<Track> = withContext(Dispatchers.IO) {
        val base = baseUrlProvider().trimEnd('/')
        if (base.isBlank() || query.isBlank()) return@withContext emptyList()

        val url = "$base/api/search?q=${TrackText.urlEncode(query)}&platform=${platform.id}&limit=$limit"
        runCatching {
            val request = Request.Builder().url(url).header("User-Agent", HttpClientProvider.USER_AGENT).build()
            HttpClientProvider.client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                RiffSearchJson.parse(body, platform)
            }
        }.getOrElse { emptyList() }
    }

}

/**
 * `/api/search` response parsing (server.js `handleSearch`).
 *
 * Kept as a top-level mapper so the wire format is testable: the payload is
 * `{ success, tracks: [{ id, title, artist, duration, thumbnail, url, platform,
 * isCached }] }`, where `isCached` means the desktop already has the file (Android
 * treats an imported/downloaded file the same way, via `localUri`).
 */
internal object RiffSearchJson {

    private val json = Json { ignoreUnknownKeys = true }

    fun parse(body: String, platform: SearchPlatform): List<Track> {
        val payload = runCatching {
            json.decodeFromString(RiffSearchResponse.serializer(), body)
        }.getOrNull() ?: return emptyList()
        return payload.tracks.mapNotNull { it.toTrack(platform) }
    }

    @Serializable
    internal data class RiffSearchResponse(
        val success: Boolean = false,
        val tracks: List<RemoteSearchHit> = emptyList(),
    )

    @Serializable
    internal data class RemoteSearchHit(
        val id: String? = null,
        val title: String = "",
        val artist: String = "",
        val duration: Long = 0,
        val thumbnail: String? = null,
        val url: String? = null,
        val platform: String? = null,
        val searchQuery: String? = null,
        val isCached: Boolean = false,
        val isLocal: Boolean = false,
    ) {
        fun toTrack(platform: SearchPlatform): Track? {
            if (title.isBlank()) return null
            val source = TrackSource.fromId(this.platform ?: platform.id)
            val durationMs = if (duration > 0) duration * 1000L else 0L
            return Track(
                id = id?.takeIf { it.isNotBlank() }
                    ?: TrackText.canonicalId(source, null, url, title, artist, duration.toInt()),
                title = title,
                artist = artist.ifBlank { "unknown artist" },
                durationMs = durationMs,
                artworkUri = thumbnail,
                source = source,
                sourceId = null,
                sourceUrl = url,
                searchQuery = searchQuery,
            )
        }
    }
}
