package com.riff.android.data.repository

import androidx.room.withTransaction
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.toDomain
import com.riff.android.domain.model.HISTORY_LIMIT
import com.riff.android.domain.model.HistoryEntry
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.HistoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * Listening history.
 *
 * Desktop equivalent: `state.history` (array, newest first, deduped by track, capped
 * at 100 in `pushHistory()`). Playback itself records through
 * `LibraryRepository.recordPlayed()`, which keeps the track row and the history table
 * consistent; this repository exists for the history screen and "clear history".
 */
class HistoryRepositoryImpl(private val database: RiffDatabase) : HistoryRepository {

    private val history = database.history()

    override fun observeHistory(): Flow<List<HistoryEntry>> =
        history.observe(HISTORY_LIMIT).map { rows -> rows.map { it.toDomain() } }

    override suspend fun record(track: Track, at: Long) = withContext(Dispatchers.IO) {
        withTransaction {
            val previous = history.get(track.id)
            history.upsert(
                com.riff.android.data.local.HistoryEntity(
                    trackId = track.id,
                    playedAt = at,
                    playCount = (previous?.playCount ?: 0) + 1,
                ),
            )
            history.trim(HISTORY_LIMIT)
        }
    }

    override suspend fun clear() = withContext(Dispatchers.IO) {
        history.clear()
    }

    private suspend fun <T> withTransaction(block: suspend () -> T): T = database.withTransaction(block)
}
