package com.riff.android.data.download

import com.riff.android.core.util.HttpClientProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.IOException

/**
 * Streams an audio url to disk with progress reporting.
 *
 * Desktop equivalent: the `yt-dlp -x --audio-format opus` child process writing
 * `<id>.temp.opus` and renaming it to `<id>.opus` when it is bigger than 60 kB
 * (`downloadTrackToDisk` / `findCachedFile` in server.js). The same size guard and
 * temp-file-then-rename dance is used here so a half written file is never
 * treated as a valid download.
 */
object AudioFileWriter {

    const val MIN_VALID_BYTES = 60_000L

    class Result(val file: File, val bytes: Long, val mimeType: String?)

    suspend fun download(
        url: String,
        targetFile: File,
        onProgress: suspend (downloaded: Long, total: Long) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val tempFile = File(targetFile.parentFile, "${targetFile.name}.temp")
        tempFile.parentFile?.mkdirs()

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", HttpClientProvider.USER_AGENT)
            .header("Accept", "*/*")
            .build()

        try {
            HttpClientProvider.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("HTTP ${response.code} while downloading audio")
                }
                val body = response.body ?: throw IOException("empty response body")
                val total = body.contentLength()
                var downloaded = 0L
                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        while (true) {
                            if (!isActive) {
                                throw CancellationException("download canceled")
                            }
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            onProgress(downloaded, total)
                        }
                        output.flush()
                    }
                }

                if (downloaded < MIN_VALID_BYTES) {
                    tempFile.delete()
                    throw IOException("downloaded file is too small ($downloaded bytes)")
                }

                if (targetFile.exists()) targetFile.delete()
                if (!tempFile.renameTo(targetFile)) {
                    tempFile.copyTo(targetFile, overwrite = true)
                    tempFile.delete()
                }
                Result(targetFile, downloaded, response.header("Content-Type"))
            }
        } catch (e: CancellationException) {
            tempFile.delete()
            throw e
        } catch (e: Exception) {
            tempFile.delete()
            throw e
        }
    }
}
