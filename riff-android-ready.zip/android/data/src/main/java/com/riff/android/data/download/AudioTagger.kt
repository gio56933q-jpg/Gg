package com.riff.android.data.download

import android.util.Log
import com.riff.android.domain.model.Track
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.File
import java.io.RandomAccessFile

/**
 * Writes title/artist/album and the cover into the downloaded file.
 *
 * Desktop equivalent: the yt-dlp flags `--embed-thumbnail --add-metadata` in
 * `handleDownload()`. Android has no yt-dlp, so the same job is done with
 * jaudiotagger (pure Java, works for mp3/m4a/flac/ogg/opus).
 *
 * Failures are never fatal: the file stays playable, the library row still carries
 * the metadata and the artwork is cached by Coil/the artwork cache. This mirrors the
 * desktop, which also continued when `--embed-thumbnail` failed.
 */
object AudioTagger {

    private const val TAG = "RiffTagger"

    fun write(file: File, track: Track, artworkBytes: ByteArray?) {
        val extension = file.extension.lowercase()
        if (extension !in SUPPORTED) return

        runCatching {
            val audioFile = AudioFileIO.read(file)
            val tag = audioFile.tagOrCreateAndSetDefault

            tag.setField(FieldKey.TITLE, track.title)
            tag.setField(FieldKey.ARTIST, track.artist)
            track.album?.takeIf { it.isNotBlank() }?.let { tag.setField(FieldKey.ALBUM, it) }
            if (track.durationMs > 0) {
                runCatching { tag.setField(FieldKey.COMMENT, "Riff • ${track.source.id}") }
            }

            artworkBytes?.takeIf { it.size > 1024 }?.let { bytes ->
                runCatching {
                    // jaudiotagger only reads artwork from a file, so buffer it.
                    val artworkFile = File.createTempFile("riff-artwork", ".jpg", file.parentFile)
                    artworkFile.writeBytes(bytes)
                    val artwork = ArtworkFactory.createArtworkFromFile(artworkFile)
                    tag.deleteArtworkField()
                    tag.addField(artwork)
                    artworkFile.delete()
                }
            }

            audioFile.commit()
        }.onFailure { error ->
            Log.w(TAG, "could not write tags for ${file.name}: ${error.message}")
        }
    }

    private val SUPPORTED = setOf("mp3", "m4a", "flac", "ogg", "opus")

    /** Used by tests: verifies the file is a readable audio container. */
    fun canRead(file: File): Boolean = runCatching {
        RandomAccessFile(file, "r").use { it.length() > 0 }
    }.getOrDefault(false)
}
