package com.riff.android.data.di

import android.content.Context
import com.riff.android.data.download.CompositeDownloadProvider
import com.riff.android.data.download.OnDeviceDownloadProvider
import com.riff.android.data.download.RiffServerDownloadProvider
import com.riff.android.data.export.AudioExporter
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.media.MediaStoreImporter
import com.riff.android.data.provider.BackendAwareStreamResolver
import com.riff.android.data.provider.DeezerArtistProvider
import com.riff.android.data.provider.LrclibLyricsProvider
import com.riff.android.data.provider.NewPipeSearchProvider
import com.riff.android.data.provider.NewPipeStreamResolver
import com.riff.android.data.provider.RiffServerSearchProvider
import com.riff.android.data.provider.RiffServerStreamResolver
import com.riff.android.data.provider.SoundCloudFallbackResolver
import com.riff.android.data.repository.ArtistRepositoryImpl
import com.riff.android.data.repository.DownloadRepositoryImpl
import com.riff.android.data.repository.HistoryRepositoryImpl
import com.riff.android.data.repository.LibraryRepositoryImpl
import com.riff.android.data.repository.LyricsRepositoryImpl
import com.riff.android.data.repository.PlaybackStateRepositoryImpl
import com.riff.android.data.repository.PlaylistRepositoryImpl
import com.riff.android.data.repository.RecommendationRepositoryImpl
import com.riff.android.data.repository.SearchRepositoryImpl
import com.riff.android.data.settings.SettingsStore
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.recommend.RecommendationEngine
import com.riff.android.domain.repo.ArtistInfoProvider
import com.riff.android.domain.repo.ArtistRepository
import com.riff.android.domain.repo.AudioTranscoder
import com.riff.android.domain.repo.DownloadProvider
import com.riff.android.domain.repo.DownloadRepository
import com.riff.android.domain.repo.ExportRepository
import com.riff.android.domain.repo.HistoryRepository
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.repo.LyricsProvider
import com.riff.android.domain.repo.LyricsRepository
import com.riff.android.domain.repo.MusicSearchProvider
import com.riff.android.domain.repo.PlaybackStateRepository
import com.riff.android.domain.repo.PlaylistRepository
import com.riff.android.domain.repo.RecommendationRepository
import com.riff.android.domain.repo.SearchRepository
import com.riff.android.domain.repo.SettingsRepository
import com.riff.android.domain.repo.StreamResolver

/**
 * The application's object graph (lightweight DI).
 *
 * The task asks for lightweight dependency injection; a hand-written container of
 * ~30 singletons is easier to follow than a code-generated graph at this size, and
 * every dependency is a constructor parameter, so swapping an implementation is a
 * one-line change. The container is created once in `RiffApplication` and handed to
 * the Compose tree through `LocalAppContainer`; ViewModels never touch `:data`.
 *
 * Wiring summary:
 *
 *  search   → NewPipeSearchProvider (YouTube/SoundCloud, on-device)
 *             + RiffServerSearchProvider (optional remote Riff backend)
 *  streams  → BackendAwareStreamResolver(on-device, remote, SoundCloud fallback)
 *  downloads→ CompositeDownloadProvider(on-device, RiffServer), executed by
 *             DownloadWorker through WorkManager
 *  lyrics   → LrclibLyricsProvider behind LyricsRepository
 *  artists  → DeezerArtistProvider (Deezer + Wikipedia)
 *  storage  → Room (RiffDatabase) + DataStore (SettingsStore)
 */
class AppContainer(context: Context) : RiffContainer {

    private val appContext = context.applicationContext

    private val database: RiffDatabase = RiffDatabase.build(appContext)
    private val importer = MediaStoreImporter(appContext)

    override val settings: SettingsRepository = SettingsStore(appContext)

    // --- search providers ---------------------------------------------------

    override val searchProviders: List<MusicSearchProvider> = listOf(
        NewPipeSearchProvider(SearchPlatform.YOUTUBE),
        NewPipeSearchProvider(SearchPlatform.SOUNDCLOUD),
        RiffServerSearchProvider({ runCatching { settings.current() }.getOrNull()?.backend?.baseUrl.orEmpty() }, SearchPlatform.YOUTUBE),
        RiffServerSearchProvider({ runCatching { settings.current() }.getOrNull()?.backend?.baseUrl.orEmpty() }, SearchPlatform.SOUNDCLOUD),
    )

    // --- stream resolution --------------------------------------------------

    private val remoteStreamResolver = RiffServerStreamResolver({
        runCatching { settings.current() }.getOrNull()?.backend?.baseUrl.orEmpty()
    })

    override val streamResolver: StreamResolver = BackendAwareStreamResolver(
        settings = settings,
        onDevice = NewPipeStreamResolver(),
        remote = remoteStreamResolver,
        fallback = SoundCloudFallbackResolver(
            searchProviders.first { it.platform == SearchPlatform.SOUNDCLOUD },
        ),
    )

    // --- repositories -------------------------------------------------------

    override val library: LibraryRepository by lazy { LibraryRepositoryImpl(database, importer) }

    override val playlists: PlaylistRepository by lazy { PlaylistRepositoryImpl(database) }

    override val history: HistoryRepository by lazy { HistoryRepositoryImpl(database) }

    override val lyricsProviders: List<LyricsProvider> = listOf(LrclibLyricsProvider(settings))

    override val lyrics: LyricsRepository by lazy { LyricsRepositoryImpl(database, lyricsProviders) }

    override val search: SearchRepository by lazy {
        SearchRepositoryImpl(appContext, searchProviders, library)
    }

    override val recommendations: RecommendationRepository by lazy {
        RecommendationRepositoryImpl(database, library, search, RecommendationEngine())
    }

    override val artistInfoProvider: ArtistInfoProvider = DeezerArtistProvider()

    override val artists: ArtistRepository by lazy { ArtistRepositoryImpl(library, artistInfoProvider) }

    override val downloads: DownloadRepository by lazy {
        DownloadRepositoryImpl(appContext, database, library, settings)
    }

    override val exports: ExportRepository by lazy { AudioExporter(appContext, library) }

    override val playbackState: PlaybackStateRepository by lazy { PlaybackStateRepositoryImpl(database) }

    // --- downloads ----------------------------------------------------------

    /** No bundled ffmpeg/FFmpegKit: streams are downloaded in their source container. */
    override val transcoder: AudioTranscoder = NoTranscoder

    private val onDeviceDownloader: DownloadProvider by lazy {
        OnDeviceDownloadProvider(appContext, streamResolver)
    }

    override val remoteDownloadProvider: DownloadProvider by lazy {
        RiffServerDownloadProvider(
            appContext,
            { runCatching { settings.current() }.getOrNull()?.backend?.baseUrl.orEmpty() },
        )
    }

    override val downloadProvider: DownloadProvider by lazy {
        CompositeDownloadProvider(settings, onDeviceDownloader, remoteDownloadProvider)
    }
}

/**
 * The default transcoder: it does nothing.
 *
 * Why: the desktop app runs `ffmpeg -x --audio-format opus` through yt-dlp, but
 * Android has no bundled ffmpeg, the official FFmpegKit was retired (January 2025)
 * and its maintained forks ship source-only (or as per-ABI AARs that would add tens
 * of megabytes). Every container the app downloads (Opus/WebM, M4A/AAC, MP3, FLAC)
 * plays natively through MediaCodec/ExoPlayer, so transcoding is opt-in rather than
 * required. See android/PORTING.md for how to plug a transcoder back in — the
 * `AudioTranscoder` interface is the only thing a build has to implement.
 */
object NoTranscoder : AudioTranscoder {
    override val id: String = "none"
    override val available: Boolean = false

    override suspend fun transcode(
        sourcePath: String,
        targetFormat: com.riff.android.domain.model.DownloadFormat,
        quality: com.riff.android.domain.model.DownloadQuality,
    ): com.riff.android.domain.repo.TranscodeResult = com.riff.android.domain.repo.TranscodeResult.Skipped
}
