package com.riff.android.data.provider

import com.riff.android.core.util.HttpClientProvider
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.LyricsProvider
import com.riff.android.domain.repo.SettingsRepository
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Request

/**
 * lrclib.net provider.
 *
 * Direct port of the lyrics lookup in `handleLyrics()` (server.js):
 *  1. `GET https://lrclib.net/api/get?track_name&artist_name` (exact match),
 *  2. on 404: `GET https://lrclib.net/api/search?q=<artist> <title>`,
 *     preferring entries that carry **synced** lyrics (LRC) over plain text.
 *
 * The query is built from `sanitizeForLyrics()` exactly like the desktop does
 * (brackets, "official audio", "ft.", "- Topic" … stripped), which is what makes
 * YouTube titles match at all.
 */
class LrclibLyricsProvider(
    private val settings: SettingsRepository,
) : LyricsProvider {

    override val id: String = "lrclib"
    override val label: String = "lrclib.net"

    override fun isEnabled(): Boolean = true

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    override suspend fun fetch(track: Track): String? = withContext(Dispatchers.IO) {
        // Online lookups are a user setting (desktop `riff_adv_online_lyrics`).
        val enabled = runCatching { settings.observeSettings().first() }.getOrNull()?.lyrics?.onlineEnabled ?: true
        if (!enabled) return@withContext null

        val (cleanTitle, cleanArtist) = TrackText.sanitizeForLyrics(track.title, track.artist)
        if (cleanTitle.isBlank() && cleanArtist.isBlank()) return@withContext null

        exact(cleanTitle, cleanArtist) ?: search(cleanTitle, cleanArtist)
    }

    private fun exact(title: String, artist: String): String? = runCatching {
        val url = "https://lrclib.net/api/get?track_name=${TrackText.urlEncode(title)}" +
            "&artist_name=${TrackText.urlEncode(artist)}"
        val body = get(url)
        val hit = json.decodeFromString(LrclibGet.serializer(), body)
        hit.syncedLyrics?.takeIf { it.isNotBlank() } ?: hit.plainLyrics?.takeIf { it.isNotBlank() }
    }.getOrNull()

    private fun search(title: String, artist: String): String? = runCatching {
        val query = "$artist $title".trim()
        val body = get("https://lrclib.net/api/search?q=${TrackText.urlEncode(query)}")
        val results = json.decodeFromString(kotlinx.serialization.builtins.ListSerializer(LrclibGet.serializer()), body)
        val withSync = results.firstOrNull { !it.syncedLyrics.isNullOrBlank() }
        withSync?.syncedLyrics?.takeIf { it.isNotBlank() } ?: results.firstOrNull()?.plainLyrics?.takeIf { it.isNotBlank() }
    }.getOrNull()

    private fun get(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", HttpClientProvider.USER_AGENT).build()
        HttpClientProvider.client.newCall(request).execute().use { response ->
            return response.body?.string().orEmpty()
        }
    }

    @Serializable
    private data class LrclibGet(
        val id: Long = 0,
        val trackName: String? = null,
        val artistName: String? = null,
        val albumName: String? = null,
        val duration: Double = 0.0,
        val instrumental: Boolean = false,
        val plainLyrics: String? = null,
        val syncedLyrics: String? = null,
    )
}
