package com.riff.android.data.download

import android.content.Context
import com.riff.android.core.util.HttpClientProvider
import com.riff.android.domain.model.BackendMode
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.DownloadResult
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.DownloadProvider
import com.riff.android.domain.repo.SettingsRepository
import com.riff.android.domain.repo.StreamResolver
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.isActive

/**
 * Download backends.
 *
 * The desktop app has exactly one: `downloadTrackToDisk()` in server.js spawns
 * yt-dlp (`-x --audio-format opus --quality 128K`) into
 * `%LOCALAPPDATA%/Riff/tracks`, keeping a `downloadingSet` to avoid duplicate work
 * and validating the result (> 60 kB).
 *
 * Android cannot ship yt-dlp/ffmpeg, so the requirement is an abstraction with two
 * real implementations:
 *
 *  - [OnDeviceDownloadProvider]   — NewPipeExtractor resolves the stream, OkHttp
 *    writes it into app storage (`filesDir/music`), which needs **no** storage
 *    permission and is deleted with the app, exactly like the desktop cache dir.
 *  - [RiffServerDownloadProvider] — a running Riff backend resolves *and*
 *    transcodes with its own yt-dlp + ffmpeg, and the app streams the finished file
 *    (`GET /api/download?url=&title=&artist=&format=&quality=`, desktop parity).
 *
 * Both honour the same contract, so nothing else in the app changes when the user
 * switches between them (Settings → Downloads → backend).
 */
interface FileNamer {
    fun fileNameFor(track: Track, format: DownloadFormat): String
}

object DefaultFileNamer : FileNamer {
    override fun fileNameFor(track: Track, format: DownloadFormat): String {
        // Desktop: `sanitizeFilename(`${artist} - ${title}`)` + the format extension.
        val base = TrackText.sanitizeFilename("${track.artist} - ${track.title}")
            .ifBlank { TrackText.sanitizeFilename(track.id) }
            .take(120)
        return "$base.${format.extension}"
    }
}

/** Desktop cache validation: anything below this is treated as a broken download. */
internal const val MIN_VALID_BYTES = 60_000L

/** Progress is reported at most every 256 kB (and once when the size is known). */
internal const val PROGRESS_STEP_BYTES = 256 * 1024L

/** Shared streaming download with progress + the desktop's "too small = failed" guard. */
internal suspend fun streamToFile(
    context: Context,
    url: String,
    target: File,
    onProgress: suspend (Long, Long) -> Unit,
    cancelled: AtomicBoolean,
): Long = withContext(Dispatchers.IO) {
    target.parentFile?.mkdirs()
    val temp = File(target.parentFile, "${target.name}.temp")

    val request = Request.Builder()
        .url(url)
        .header("User-Agent", HttpClientProvider.USER_AGENT)
        .build()

    try {
        HttpClientProvider.client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code} while downloading")
            val body = response.body ?: throw IOException("empty response body")
            val total = body.contentLength().coerceAtLeast(0L)

            RandomAccessFile(temp, "rw").use { file ->
                body.byteStream().use { input ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var downloaded = 0L
                    var lastReport = 0L
                    while (true) {
                        if (cancelled.get() || !coroutineContext.isActive) throw IOException("cancelled")
                        val read = input.read(buffer)
                        if (read == -1) break
                        file.write(buffer, 0, read)
                        downloaded += read
                        if (downloaded - lastReport >= PROGRESS_STEP_BYTES || downloaded == total) {
                            lastReport = downloaded
                            onProgress(downloaded, total)
                        }
                    }

                    // Desktop macOS path checked for files < 1000 bytes, the general
                    // cache validation needs > 60 kB; apply the strict variant.
                    if (downloaded < MIN_VALID_BYTES) {
                        file.close()
                        temp.delete()
                        throw IOException("downloaded file is too small ($downloaded bytes)")
                    }
                }
            }
        }

        if (target.exists()) target.delete()
        if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            temp.delete()
        }
        target.length()
    } catch (error: Exception) {
        // Never leave half-written files behind: `findCachedFile()` would treat a
        // truncated file as valid on the next launch.
        temp.delete()
        throw error
    }
}

/** On-device: NewPipeExtractor + OkHttp. */
class OnDeviceDownloadProvider(
    private val context: Context,
    private val streamResolver: StreamResolver,
    private val cancellation: () -> AtomicBoolean = { AtomicBoolean(false) },
) : DownloadProvider {

    override val id: String = "on-device"
    override val label: String = "On-device (no server needed)"

    override suspend fun isAvailable(): Boolean = true

    override suspend fun download(
        track: Track,
        format: DownloadFormat,
        quality: DownloadQuality,
        destinationFileName: String,
        onProgress: suspend (Long, Long) -> Unit,
    ): DownloadResult = withContext(Dispatchers.IO) {
        val cancelled = cancellation()
        try {
            val streamUrl = streamResolver.resolve(track)
            val container = if (streamUrl.contains(".m3u8")) DownloadFormat.M4A else format
            val target = File(musicDir(context), DefaultFileNamer.fileNameFor(track, container))
            val bytes = streamToFile(context, streamUrl, target, onProgress, cancelled)
            DownloadResult.Success(
                localUri = target.toURI().toString(),
                bytes = bytes,
                mimeType = com.riff.android.core.util.AudioMime.contentTypeForPath(target.name),
            )
        } catch (error: kotlinx.coroutines.CancellationException) {
            DownloadResult.Canceled
        } catch (error: Exception) {
            DownloadResult.Failure(error.message ?: "download failed", retryable = isTransient(error))
        }
    }

    private fun isTransient(error: Exception): Boolean = when (error) {
        is java.net.SocketTimeoutException, is java.net.UnknownHostException, is IOException -> true
        else -> false
    }

    companion object {
        private const val MUSIC_DIR = "music"

        /** App-private storage: no permission needed, removed with the app. */
        fun musicDir(context: Context): File = File(context.filesDir, MUSIC_DIR)
    }
}

/** Remote: a Riff backend does the extraction/transcoding and serves the file. */
class RiffServerDownloadProvider(
    private val context: Context,
    private val baseUrlProvider: suspend () -> String,
    private val cancellation: () -> AtomicBoolean = { AtomicBoolean(false) },
) : DownloadProvider {

    override val id: String = "riff-server"
    override val label: String = "Riff server (yt-dlp + ffmpeg)"

    override suspend fun isAvailable(): Boolean = baseUrlProvider().isNotBlank()

    override suspend fun download(
        track: Track,
        format: DownloadFormat,
        quality: DownloadQuality,
        destinationFileName: String,
        onProgress: suspend (Long, Long) -> Unit,
    ): DownloadResult = withContext(Dispatchers.IO) {
        val base = baseUrlProvider().trimEnd('/')
        if (base.isBlank()) {
            return@withContext DownloadResult.Failure("no Riff server configured", retryable = false)
        }

        val url = buildString {
            append(base)
            append("/api/download?url=").append(TrackText.urlEncode(track.sourceUrl.orEmpty()))
            append("&title=").append(TrackText.urlEncode(track.title))
            append("&artist=").append(TrackText.urlEncode(track.artist))
            append("&format=").append(format.extension)
            append("&quality=").append(quality.id)
        }

        val cancelled = cancellation()
        try {
            val target = File(OnDeviceDownloadProvider.musicDir(context), DefaultFileNamer.fileNameFor(track, format))
            val bytes = streamToFile(context, url, target, onProgress, cancelled)
            DownloadResult.Success(
                localUri = target.toURI().toString(),
                bytes = bytes,
                mimeType = com.riff.android.core.util.AudioMime.contentTypeForPath(target.name),
            )
        } catch (error: kotlinx.coroutines.CancellationException) {
            DownloadResult.Canceled
        } catch (error: Exception) {
            DownloadResult.Failure(error.message ?: "download failed", retryable = true)
        }
    }
}

/**
 * Picks the backend from the user's setting, with the same semantics as the stream
 * resolver: ON_DEVICE never touches a server, RIFF_SERVER requires one, AUTO prefers
 * the server and falls back to the device.
 */
class CompositeDownloadProvider(
    private val settings: SettingsRepository,
    private val onDevice: DownloadProvider,
    private val remote: DownloadProvider,
) : DownloadProvider {

    override val id: String = "composite"
    override val label: String = "Automatic"

    override suspend fun isAvailable(): Boolean = true

    override suspend fun download(
        track: Track,
        format: DownloadFormat,
        quality: DownloadQuality,
        destinationFileName: String,
        onProgress: suspend (Long, Long) -> Unit,
    ): DownloadResult {
        val settingsSnapshot = runCatching { settings.current() }.getOrNull()
        val mode = settingsSnapshot?.backend?.mode ?: BackendMode.ON_DEVICE
        val baseUrl = settingsSnapshot?.backend?.baseUrl.orEmpty()

        return when (mode) {
            BackendMode.ON_DEVICE -> onDevice.download(track, format, quality, destinationFileName, onProgress)
            BackendMode.RIFF_SERVER ->
                if (baseUrl.isBlank()) DownloadResult.Failure("no Riff server configured", retryable = false)
                else remote.download(track, format, quality, destinationFileName, onProgress)
            BackendMode.AUTO ->
                if (baseUrl.isNotBlank()) {
                    val remoteResult = remote.download(track, format, quality, destinationFileName, onProgress)
                    if (remoteResult is DownloadResult.Failure && remoteResult.retryable) {
                        onDevice.download(track, format, quality, destinationFileName, onProgress)
                    } else {
                        remoteResult
                    }
                } else {
                    onDevice.download(track, format, quality, destinationFileName, onProgress)
                }
        }
    }
}
