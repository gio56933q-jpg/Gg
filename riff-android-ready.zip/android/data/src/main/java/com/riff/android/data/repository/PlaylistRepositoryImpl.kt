package com.riff.android.data.repository

import androidx.room.withTransaction
import com.riff.android.data.local.PlaylistEntity
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.toDomain
import com.riff.android.data.local.toEntity
import com.riff.android.domain.model.Playlist
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.PlaylistRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * Playlists.
 *
 * Desktop equivalent: `state.playlists` in app.js — `{id: 'pl_' + Date.now(), name,
 * tracks: [...]}` persisted in `devsize_playlists`, reorderable by drag & drop
 * (`initListReordering`), with a 2x2 mosaic cover built from the first tracks
 * (`renderPlaylistCover`).
 */
class PlaylistRepositoryImpl(private val database: RiffDatabase) : PlaylistRepository {

    private val playlists = database.playlists()
    private val tracks = database.tracks()

    override fun observePlaylists(): Flow<List<Playlist>> =
        playlists.observeAll().map { rows ->
            rows.map { entity ->
                entity.toDomain(
                    coverUris = playlists.coverUris(entity.id, limit = 4).filter { it.isNotBlank() },
                    trackCount = playlists.count(entity.id),
                )
            }
        }

    override fun observePlaylist(playlistId: String): Flow<Playlist?> =
        playlists.observe(playlistId).map { entity ->
            entity?.toDomain(
                coverUris = playlists.coverUris(playlistId, limit = 4).filter { it.isNotBlank() },
                trackCount = playlists.count(playlistId),
            )
        }

    override fun observePlaylistTracks(playlistId: String): Flow<List<Track>> =
        playlists.observeTracks(playlistId).map { rows -> rows.map { it.toDomain() } }

    override suspend fun createPlaylist(name: String): Playlist = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val entity = PlaylistEntity(
            // Desktop: `pl_${Date.now()}`. A monotonic suffix keeps ids unique even
            // when two playlists are created in the same millisecond.
            id = "pl_$now${(0..0xFFFF).random().toString(16)}",
            name = name.trim().ifBlank { "New playlist" },
            createdAt = now,
            updatedAt = now,
        )
        playlists.upsertPlaylist(entity)
        entity.toDomain()
    }

    override suspend fun renamePlaylist(playlistId: String, name: String) { withContext(Dispatchers.IO) {
        playlists.get(playlistId)?.let { row ->
            playlists.upsertPlaylist(
                row.copy(name = name.trim().ifBlank { row.name }, updatedAt = System.currentTimeMillis()),
            )
        }
    }
    }

    override suspend fun deletePlaylist(playlistId: String) = withContext(Dispatchers.IO) {
        database.withTransaction {
            playlists.clearTracks(playlistId)
            playlists.deletePlaylist(playlistId)
        }
    }

    override suspend fun addTrack(playlistId: String, track: Track) {
        addTracks(playlistId, listOf(track))
    }

    override suspend fun addTracks(playlistId: String, tracksToAdd: List<Track>) { withContext(Dispatchers.IO) {
        if (tracksToAdd.isEmpty()) return@withContext
        database.withTransaction {
            // A playlist row is a join table, so the track row must exist first.
            tracksToAdd.forEach { track ->
                val existing = tracks.get(track.id) ?: tracks.findByKey(track.normalizedKey)
                tracks.upsert(track.toEntity(existing))
            }
            val existingIds = playlists.trackIds(playlistId).toSet()
            val newIds = tracksToAdd.map { it.id }.filterNot { it in existingIds }
            if (newIds.isNotEmpty()) {
                playlists.addTracks(playlistId, newIds, System.currentTimeMillis())
            }
            playlists.get(playlistId)?.let { row ->
                playlists.upsertPlaylist(row.copy(updatedAt = System.currentTimeMillis()))
            }
        }
    }
    }

    override suspend fun removeTrack(playlistId: String, trackId: String) { withContext(Dispatchers.IO) {
        database.withTransaction {
            playlists.removeTrack(playlistId, trackId)
            renumber(playlistId)
            playlists.get(playlistId)?.let { row ->
                playlists.upsertPlaylist(row.copy(updatedAt = System.currentTimeMillis()))
            }
        }
    }
    }

    override suspend fun moveTrack(playlistId: String, fromIndex: Int, toIndex: Int) { withContext(Dispatchers.IO) {
        database.withTransaction {
            playlists.moveTrack(playlistId, fromIndex, toIndex)
            playlists.get(playlistId)?.let { row ->
                playlists.upsertPlaylist(row.copy(updatedAt = System.currentTimeMillis()))
            }
        }
    }
    }

    /** Removes gaps left by [removeTrack] (desktop re-rendered the whole array). */
    private suspend fun renumber(playlistId: String) {
        val ids = playlists.trackIds(playlistId)
        val rows = ids.mapIndexed { index, trackId ->
            com.riff.android.data.local.PlaylistTrackEntity(
                playlistId = playlistId,
                trackId = trackId,
                position = index,
                addedAt = System.currentTimeMillis(),
            )
        }
        playlists.clearTracks(playlistId)
        rows.forEach { playlists.insertTrack(it) }
    }
}
