package com.riff.android.data.repository

import android.net.Uri
import androidx.room.withTransaction
import com.riff.android.data.local.HistoryEntity
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.toDomain
import com.riff.android.data.local.toEntity
import com.riff.android.data.media.MediaStoreImporter
import com.riff.android.domain.model.Album
import com.riff.android.domain.model.HISTORY_LIMIT
import com.riff.android.domain.model.Artist
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Library repository.
 *
 * Desktop equivalents:
 *  - `/api/offline-library` (downloaded tracks + `metadata.json` metadata),
 *  - `devsize_favorites` / `devsize_history` (localStorage arrays, history deduped
 *    and capped at 100 by `pushHistory()`),
 *  - the track objects embedded in `devsize_playlists`.
 *
 * Everything is a Flow here, so a download finishing or a track being favourited
 * updates every screen without polling — the desktop re-rendered on every state
 * mutation instead.
 */
class LibraryRepositoryImpl(
    private val database: RiffDatabase,
    private val importer: MediaStoreImporter,
) : LibraryRepository {

    private val tracks = database.tracks()
    private val history = database.history()

    override fun observeLibrary(): Flow<List<Track>> =
        tracks.observeLibrary().map { rows -> rows.map { it.toDomain() } }

    override fun observeFavorites(): Flow<List<Track>> =
        tracks.observeFavorites().map { rows -> rows.map { it.toDomain() } }

    override fun observeHistory(): Flow<List<Track>> =
        tracks.observeHistoryOrdered(HISTORY_LIMIT).map { rows -> rows.map { it.toDomain() } }

    override fun observeDownloads(): Flow<List<Track>> =
        tracks.observeDownloads().map { rows -> rows.map { it.toDomain() } }

    override fun searchLocal(query: String): Flow<List<Track>> {
        val needle = query.trim().lowercase()
        return tracks.observeLibrary().map { rows ->
            if (needle.isBlank()) {
                rows.map { it.toDomain() }
            } else {
                rows.map { it.toDomain() }.filter { track ->
                    track.title.lowercase().contains(needle) ||
                        track.artist.lowercase().contains(needle) ||
                        track.displayAlbum.lowercase().contains(needle)
                }
            }
        }
    }

    override fun observeArtists(): Flow<List<Artist>> =
        tracks.observeArtists().map { rows -> rows.map { it.toDomain() } }

    override fun observeAlbums(): Flow<List<Album>> =
        tracks.observeAlbums().map { rows -> rows.map { it.toDomain() } }

    override suspend fun get(trackId: String): Track? = withContext(Dispatchers.IO) {
        tracks.get(trackId)?.toDomain()
    }

    override suspend fun getMany(trackIds: List<String>): List<Track> = withContext(Dispatchers.IO) {
        if (trackIds.isEmpty()) return@withContext emptyList()
        val byId = tracks.getByIds(trackIds).associateBy { it.id }
        trackIds.mapNotNull { id -> byId[id]?.toDomain() }
    }

    override suspend fun findLocalByKey(normalizedKey: String): Track? = withContext(Dispatchers.IO) {
        tracks.findByKey(normalizedKey)?.toDomain()
    }

    override suspend fun upsert(track: Track): Track = withContext(Dispatchers.IO) {
        val existing = tracks.get(track.id) ?: tracks.findByKey(track.normalizedKey.ifBlank { track.id })
        val entity = track.toEntity(existing)
        tracks.upsert(entity)
        entity.toDomain()
    }

    override suspend fun upsertAll(tracksToInsert: List<Track>) = withContext(Dispatchers.IO) {
        if (tracksToInsert.isEmpty()) return@withContext
        database.withTransaction {
            tracksToInsert.forEach { track ->
                val existing = tracks.get(track.id) ?: tracks.findByKey(track.normalizedKey.ifBlank { track.id })
                tracks.upsert(track.toEntity(existing))
            }
        }
    }

    override suspend fun setFavorite(track: Track, favorite: Boolean): Track = withContext(Dispatchers.IO) {
        val existing = tracks.get(track.id) ?: tracks.findByKey(track.normalizedKey)
        val base = track.toEntity(existing)
        val updated = base.copy(
            favorite = favorite,
            favoritedAt = if (favorite) (existing?.favoritedAt ?: System.currentTimeMillis()) else null,
        )
        tracks.upsert(updated)
        updated.toDomain()
    }

    override suspend fun recordPlayed(track: Track, playedAt: Long): Track = withContext(Dispatchers.IO) {
        database.withTransaction {
            val existing = tracks.get(track.id) ?: tracks.findByKey(track.normalizedKey)
            val entity = track.toEntity(existing).copy(
                lastPlayedAt = playedAt,
                playCount = (existing?.playCount ?: 0) + 1,
            )
            tracks.upsert(entity)

            // Desktop `pushHistory()`: dedupe by track, newest first, cap 100 (plus a
            // per-track play counter which the desktop kept in the same array).
            val previous = history.get(track.id)
            history.upsert(
                HistoryEntity(
                    trackId = track.id,
                    playedAt = playedAt,
                    playCount = (previous?.playCount ?: 0) + 1,
                ),
            )
            history.trim(HISTORY_LIMIT)
            entity.toDomain()
        }
    }

    override suspend fun clearHistory() = withContext(Dispatchers.IO) {
        database.withTransaction {
            history.clear()
            tracks.all().forEach { row ->
                if (row.lastPlayedAt != null) {
                    tracks.upsert(row.copy(lastPlayedAt = null))
                }
            }
        }
    }

    override suspend fun deleteDownloaded(trackId: String, deleteFile: Boolean) = withContext(Dispatchers.IO) {
        val row = tracks.get(trackId)
        if (deleteFile) deleteLocalFile(row?.localUri)

        database.withTransaction {
            history.delete(trackId)
            if (row == null) return@withTransaction
            // Keep the row when it still matters (favourite/history), otherwise drop it
            // — the same net effect as deleting the cached file and its metadata entry.
            if (row.favorite || row.lastPlayedAt != null) {
                tracks.upsert(row.copy(localUri = null, downloadedAt = null, fileSizeBytes = 0, inLibrary = false))
            } else {
                tracks.delete(trackId)
            }
        }
    }

    override suspend fun clearDownloads() = withContext(Dispatchers.IO) {
        val rows = tracks.local()
        database.withTransaction {
            rows.forEach { row ->
                deleteLocalFile(row.localUri)
                if (row.favorite || row.lastPlayedAt != null) {
                    tracks.upsert(row.copy(localUri = null, downloadedAt = null, fileSizeBytes = 0, inLibrary = false))
                } else {
                    tracks.delete(row.id)
                }
            }
        }
    }

    override suspend fun totalDownloadBytes(): Long = withContext(Dispatchers.IO) { tracks.totalDownloadBytes() }

    override suspend fun importLocalFile(
        uri: String,
        displayName: String?,
        mimeType: String?,
        sizeBytes: Long,
    ): Track? = withContext(Dispatchers.IO) {
        val parsed = runCatching { Uri.parse(uri) }.getOrNull() ?: return@withContext null
        // Metadata (name/size/mime) is read here so callers only pass a uri.
        val file = importer.readFile(parsed)
            ?: MediaStoreImporter.ImportedFile(uri, displayName, mimeType, sizeBytes)
        val track = importer.toTrack(file)
        val entity = track.toEntity(inLibrary = true).copy(inLibrary = true)
        tracks.upsert(entity)
        entity.toDomain()
    }

    override suspend fun syncMediaStore(excludedFolders: Set<String>): Int = withContext(Dispatchers.IO) {
        val found = importer.scan(excludedFolders)
        if (found.isEmpty()) return@withContext 0

        database.withTransaction {
            found.forEach { track ->
                val existing = tracks.get(track.id) ?: tracks.findByKey(track.normalizedKey)
                val entity = track.toEntity(existing, inLibrary = true).copy(
                    inLibrary = true,
                    addedAt = existing?.addedAt ?: System.currentTimeMillis(),
                )
                tracks.upsert(entity)
            }
        }
        found.size
    }

    /** Files inside app storage are ours; `content://` uris belong to the user. */
    private fun deleteLocalFile(uri: String?) {
        if (uri.isNullOrBlank()) return
        if (uri.startsWith("file://")) {
            runCatching {
                val path = uri.removePrefix("file://")
                File(java.net.URLDecoder.decode(path, "UTF-8")).delete()
            }
        }
    }
}
