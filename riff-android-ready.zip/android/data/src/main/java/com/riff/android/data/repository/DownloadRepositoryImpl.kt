package com.riff.android.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.riff.android.data.download.DownloadWorker
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.toDomain
import com.riff.android.data.local.toEntity
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.DownloadState
import com.riff.android.domain.model.DownloadTask
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.DownloadRepository
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.repo.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Download bookkeeping + scheduling.
 *
 * Desktop equivalent: `/api/download` (the Downloads screen format chips) and the
 * automatic "cache as you stream" path in `downloadTrackToDisk()`, guarded by the
 * in-memory `downloadingSet`. Here the guard is WorkManager's unique work
 * (`download-<trackId>`) and the state lives in Room so every screen — and the
 * notification-free Downloads list — observes the same rows.
 */
class DownloadRepositoryImpl(
    private val context: Context,
    private val database: RiffDatabase,
    private val library: LibraryRepository,
    private val settings: SettingsRepository,
) : DownloadRepository {

    private val dao = database.downloads()
    private val tracks = database.tracks()

    override fun observeAll(): Flow<List<DownloadTask>> =
        dao.observeAll().map { rows -> rows.map { it.toDomain() } }

    override fun observe(trackId: String): Flow<DownloadTask?> =
        dao.observe(trackId).map { it?.toDomain() }

    override fun observeActive(): Flow<List<DownloadTask>> =
        dao.observeActive().map { rows -> rows.map { it.toDomain() } }

    override suspend fun enqueue(
        track: Track,
        format: DownloadFormat,
        quality: DownloadQuality,
        providerId: String?,
    ): Boolean = withContext(Dispatchers.IO) {
        val existing = dao.get(track.id)
        if (existing != null && existing.state in setOf(DownloadState.QUEUED.name, DownloadState.RUNNING.name)) {
            return@withContext false // desktop `downloadingSet.has(id)`
        }

        val trackRow = tracks.get(track.id) ?: tracks.findByKey(track.normalizedKey)
        tracks.upsert(track.toEntity(trackRow))

        val now = System.currentTimeMillis()
        val task = (existing?.toDomain() ?: DownloadTask(trackId = track.id, requestedAt = now)).copy(
            state = DownloadState.QUEUED,
            format = format,
            quality = quality,
            progress = 0f,
            bytesDownloaded = 0L,
            error = null,
            requestedAt = now,
            providerId = providerId.orEmpty(),
        )
        dao.upsert(task.toEntity())

        val wifiOnly = settings.current().advanced.downloadOverWifiOnly
        DownloadWorker.enqueue(context, track.id, format, quality, wifiOnly = wifiOnly)
        true
    }

    override suspend fun cancel(trackId: String) = withContext(Dispatchers.IO) {
        DownloadWorker.cancel(context, trackId)
        markCanceled(trackId)
    }

    override suspend fun retry(trackId: String) = withContext(Dispatchers.IO) {
        val task = dao.get(trackId)?.toDomain() ?: return@withContext
        val format = task.format
        val quality = task.quality
        val attempts = (task.attempts).coerceAtMost(DownloadWorker.MAX_ATTEMPTS - 1)
        val wifiOnly = settings.current().advanced.downloadOverWifiOnly

        DownloadWorker.enqueue(
            context = context,
            trackId = trackId,
            format = format,
            quality = quality,
            attempt = attempts,
            replace = true,
            wifiOnly = wifiOnly,
        )
        dao.upsert(task.copy(state = DownloadState.QUEUED, error = null, progress = 0f).toEntity())
    }

    override suspend fun remove(trackId: String, deleteFile: Boolean) = withContext(Dispatchers.IO) {
        DownloadWorker.cancel(context, trackId)
        database.withTransaction {
            dao.delete(trackId)
            if (deleteFile) {
                val row = tracks.get(trackId)
                if (row?.localUri != null && row.localUri.startsWith("file://")) {
                    runCatching { File(java.net.URI(row.localUri)).delete() }
                }
                if (row != null) {
                    tracks.upsert(row.copy(localUri = null, downloadedAt = null, fileSizeBytes = 0, inLibrary = false))
                }
            }
        }
    }

    override suspend fun clearFinished() = withContext(Dispatchers.IO) { dao.clearFinished() }

    override suspend fun markRunning(trackId: String, providerId: String) = withContext(Dispatchers.IO) {
        val task = dao.get(trackId)?.toDomain() ?: return@withContext
        dao.upsert(task.copy(state = DownloadState.RUNNING, providerId = providerId, error = null).toEntity())
    }

    override suspend fun updateProgress(trackId: String, bytesDownloaded: Long, totalBytes: Long) =
        withContext(Dispatchers.IO) {
            val task = dao.get(trackId)?.toDomain() ?: return@withContext
            val progress = if (totalBytes > 0) {
                (bytesDownloaded.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
            } else {
                task.progress
            }
            dao.upsert(
                task.copy(
                    state = DownloadState.RUNNING,
                    bytesDownloaded = bytesDownloaded,
                    totalBytes = maxOf(totalBytes, task.totalBytes),
                    progress = progress,
                ).toEntity(),
            )
        }

    override suspend fun markCompleted(trackId: String, localUri: String, bytes: Long) = withContext(Dispatchers.IO) {
        val task = dao.get(trackId)?.toDomain() ?: return@withContext
        dao.upsert(
            task.copy(
                state = DownloadState.COMPLETED,
                progress = 1f,
                bytesDownloaded = bytes,
                totalBytes = maxOf(bytes, task.totalBytes),
                completedAt = System.currentTimeMillis(),
                error = null,
            ).toEntity(),
        )
        // Belt and braces: the worker also updates the track row, but a completed
        // download must always end up in the offline library.
        val row = tracks.get(trackId)
        if (row != null && row.localUri.isNullOrBlank()) {
            tracks.upsert(row.copy(localUri = localUri, downloadedAt = System.currentTimeMillis(), fileSizeBytes = bytes, inLibrary = true))
        }
    }

    override suspend fun markFailed(trackId: String, error: String, attempts: Int) = withContext(Dispatchers.IO) {
        val task = dao.get(trackId)?.toDomain() ?: return@withContext
        dao.upsert(
            task.copy(
                state = DownloadState.FAILED,
                error = error,
                attempts = attempts,
                progress = 0f,
            ).toEntity(),
        )
    }

    override suspend fun markCanceled(trackId: String) = withContext(Dispatchers.IO) {
        val task = dao.get(trackId)?.toDomain() ?: return@withContext
        dao.upsert(task.copy(state = DownloadState.CANCELED, error = null).toEntity())
    }
}
