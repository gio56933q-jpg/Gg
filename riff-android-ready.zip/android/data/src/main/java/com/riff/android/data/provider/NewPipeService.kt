package com.riff.android.data.provider

import com.riff.android.core.util.HttpClientProvider
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import java.io.IOException
import java.util.Locale

/**
 * NewPipeExtractor bootstrap.
 *
 * Why NewPipe: the desktop app shells out to `yt-dlp` (`server.js` spawns
 * `bin/yt-dlp` / a downloaded build). Shipping a yt-dlp binary inside an APK is not
 * possible (it is a Python program plus ffmpeg), so the on-device replacement is
 * NewPipeExtractor — the same extraction logic the NewPipe app uses, pure Java, no
 * native binaries, and it covers YouTube and SoundCloud, i.e. exactly the two
 * platforms the desktop app supports.
 *
 * The alternative "remote" backend (`RiffServerSearchProvider` /
 * `RiffServerStreamResolver`) keeps talking to a real Riff server running
 * yt-dlp + ffmpeg, so nothing about the app has to change when a desktop machine
 * is available.
 */
object NewPipeService {

    @Volatile
    private var initialized = false

    fun ensureInitialized() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            val locale = Locale.getDefault()
            NewPipe.init(
                RiffDownloader(),
                Localization.fromLocale(locale),
                ContentCountry(locale.country.ifBlank { Locale.US.country }),
            )
            initialized = true
        }
    }
}

/**
 * [Downloader] implementation on top of the shared OkHttp client.
 * Mirrors what the NewPipe app does with its own client: browser User-Agent,
 * `Accept-Language`, and 429 → [ReCaptchaException] so the extractor reports a
 * rate limit instead of a generic HTTP error.
 */
class RiffDownloader : Downloader() {

    private val client = HttpClientProvider.client

    @Throws(IOException::class, ReCaptchaException::class)
    override fun execute(request: Request): Response {
        val httpMethod = request.httpMethod()
        val url = request.url()
        val headers = request.headers()
        val data = request.dataToSend()

        val body = if (data == null || data.isEmpty() || httpMethod == "GET" || httpMethod == "HEAD") {
            null
        } else {
            val contentType = headers["Content-Type"]?.firstOrNull() ?: "application/json"
            data.toRequestBody(contentType.toMediaTypeOrNull())
        }

        val builder = okhttp3.Request.Builder()
            .method(httpMethod, body)
            .url(url)
            .addHeader("User-Agent", HttpClientProvider.USER_AGENT)
            .addHeader("Accept-Language", Locale.getDefault().toLanguageTag())

        headers.forEach { (name, values) ->
            if (name.equals("User-Agent", ignoreCase = true)) return@forEach
            values.forEach { value -> builder.addHeader(name, value) }
        }

        client.newCall(builder.build()).execute().use { response ->
            if (response.code == 429) {
                throw ReCaptchaException("reCaptcha challenge requested (HTTP 429)", url)
            }

            val bodyText = response.body?.string().orEmpty()
            val responseHeaders = response.headers.toMultimap()

            return Response(
                response.code,
                response.message,
                responseHeaders,
                bodyText,
                response.request.url.toString(),
            )
        }
    }
}
