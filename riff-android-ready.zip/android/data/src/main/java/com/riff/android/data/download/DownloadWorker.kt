package com.riff.android.data.download

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.riff.android.core.player.RiffServiceHost
import com.riff.android.core.util.HttpClientProvider
import com.riff.android.core.util.NetworkMonitor
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.DownloadResult
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.DownloadProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Background download worker.
 *
 * Desktop equivalent: `downloadTrackToDisk()` (server.js) — a child yt-dlp process
 * with progress parsing and a `downloadingSet` guard against duplicates. Here:
 *  - WorkManager guarantees the work survives backgrounding, process death and reboot
 *    (`NetworkType.CONNECTED` constraint, exponential backoff, unique work name),
 *  - duplicates are prevented by the unique work name `download-<trackId>`,
 *  - progress and state are written to Room so any screen can observe them,
 *  - nothing runs on the UI thread: the worker talks to repositories only.
 */
class DownloadWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as? RiffServiceHost)?.container ?: return Result.failure()
        val trackId = inputData.getString(KEY_TRACK_ID) ?: return Result.failure()
        val attempt = inputData.getInt(KEY_ATTEMPT, 0)

        val track = container.library.get(trackId) ?: return Result.failure()
        if (track.isDownloaded) {
            // Already on disk (e.g. the same track was downloaded twice).
            container.downloads.markCompleted(trackId, track.localUri.orEmpty(), track.fileSizeBytes)
            return Result.success()
        }

        val settings = container.settings.current()
        if (settings.advanced.downloadOverWifiOnly && !NetworkMonitor.isUnmetered(applicationContext)) {
            return Result.retry()
        }

        val format = DownloadFormat.fromId(inputData.getString(KEY_FORMAT))
        val quality = DownloadQuality.fromId(inputData.getString(KEY_QUALITY))

        val provider: DownloadProvider = container.downloadProvider
        container.downloads.markRunning(trackId, provider.id)

        val fileName = com.riff.android.domain.text.TrackText
            .sanitizeFilename("${track.artist} - ${track.title}")
            .ifBlank { track.id }

        val result = try {
            provider.download(
                track = track,
                format = format,
                quality = quality,
                destinationFileName = fileName,
                onProgress = { downloaded, total ->
                    container.downloads.updateProgress(trackId, downloaded, total)
                },
            )
        } catch (error: Exception) {
            DownloadResult.Failure(error.message ?: "download failed", retryable = true)
        }

        return when (result) {
            is DownloadResult.Success -> {
                // Metadata + artwork embedding (desktop: `--embed-thumbnail --add-metadata`).
                if (settings.advanced.embedMetadataAndArtwork) {
                    embedTags(result.localUri, track)
                }

                val stored = track.copy(
                    localUri = result.localUri,
                    downloadedAt = System.currentTimeMillis(),
                    fileSizeBytes = result.bytes,
                    // Downloaded tracks are part of the offline library even when the
                    // artwork was not cached separately.
                    artworkUri = track.artworkUri,
                    addedAt = if (track.addedAt > 0) track.addedAt else System.currentTimeMillis(),
                )
                container.library.upsert(stored)
                container.downloads.markCompleted(trackId, result.localUri, result.bytes)
                Result.success()
            }

            is DownloadResult.Failure -> {
                container.downloads.markFailed(trackId, result.message, attempt + 1)
                if (result.retryable && attempt + 1 < MAX_ATTEMPTS) {
                    Result.retry()
                } else {
                    Result.failure()
                }
            }

            DownloadResult.Canceled -> {
                container.downloads.markCanceled(trackId)
                Result.failure()
            }
        }
    }

    private suspend fun embedTags(localUri: String, track: Track) = withContext(Dispatchers.IO) {
        val file = runCatching { File(java.net.URI(localUri)) }.getOrNull() ?: return@withContext
        if (!file.exists()) return@withContext

        val artwork = track.artworkUri
            ?.takeIf { it.startsWith("http") }
            ?.let { url ->
                runCatching {
                    val request = okhttp3.Request.Builder()
                        .url(url)
                        .header("User-Agent", HttpClientProvider.USER_AGENT)
                        .build()
                    HttpClientProvider.client.newCall(request).execute().use { response -> response.body?.bytes() }
                }.getOrNull()
            }

        AudioTagger.write(file, track, artwork)
    }

    companion object {
        const val KEY_TRACK_ID = "trackId"
        const val KEY_FORMAT = "format"
        const val KEY_QUALITY = "quality"
        const val KEY_ATTEMPT = "attempt"

        /** Desktop retried a failed yt-dlp download once; three tries is friendlier. */
        const val MAX_ATTEMPTS = 3

        /**
         * Queues a download. The unique name is the Android equivalent of the desktop
         * `downloadingSet`: while one worker for this track is queued or running, the
         * second enqueue is a no-op.
         */
        fun enqueue(
            context: Context,
            trackId: String,
            format: DownloadFormat,
            quality: DownloadQuality,
            attempt: Int = 0,
            replace: Boolean = false,
            wifiOnly: Boolean = false,
        ) {
            val request = OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(
                    Data.Builder()
                        .putString(KEY_TRACK_ID, trackId)
                        .putString(KEY_FORMAT, format.extension)
                        .putString(KEY_QUALITY, quality.id)
                        .putInt(KEY_ATTEMPT, attempt)
                        .build(),
                )
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                        .build(),
                )
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                uniqueName(trackId),
                if (replace) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
                request,
            )
        }

        fun cancel(context: Context, trackId: String) {
            WorkManager.getInstance(context).cancelUniqueWork(uniqueName(trackId))
        }

        fun uniqueName(trackId: String): String = "download-$trackId"
    }
}
