package com.riff.android.data.repository

import com.riff.android.core.util.NetworkMonitor
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.SearchResult
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.repo.MusicSearchProvider
import com.riff.android.domain.repo.SearchRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Search orchestration.
 *
 * Desktop equivalent: `/api/search` in server.js — including its 5 minute result
 * cache for the same `platform:query:limit` key, and the SoundCloud fallback that
 * kicks in when YouTube returns nothing.
 *
 * Results are persisted into the track table as they arrive (that is what makes
 * "add to playlist" / "download" work on a track the user just found), while the
 * `Track` objects returned to the UI stay plain domain objects.
 */
class SearchRepositoryImpl(
    private val context: android.content.Context,
    private val providers: List<MusicSearchProvider>,
    private val library: LibraryRepository,
    private val cacheTtlMs: Long = 5 * 60 * 1000L,
) : SearchRepository {

    private class CacheEntry(val result: SearchResult, val fetchedAt: Long) {
        fun isFresh(ttl: Long) = System.currentTimeMillis() - fetchedAt < ttl
    }

    private val cache = ConcurrentHashMap<String, CacheEntry>()

    override suspend fun search(query: String, platform: SearchPlatform, limit: Int): SearchResult =
        withContext(Dispatchers.IO) {
            val trimmed = query.trim()
            if (trimmed.isBlank()) return@withContext SearchResult(emptyList(), platform, trimmed)

            val key = "${platform.id}:${trimmed.lowercase()}:$limit"
            cache[key]?.let { if (it.isFresh(cacheTtlMs)) return@withContext it.result.copy(fromCache = true) }

            if (!NetworkMonitor.isOnline(context)) {
                return@withContext SearchResult(
                    tracks = emptyList(),
                    platform = platform,
                    query = trimmed,
                    error = "offline — only downloaded tracks can be searched right now",
                )
            }

            val primary = providers.filter { it.platform == platform }
            var tracks = emptyList<Track>()
            var error: String? = null

            for (provider in primary) {
                val result = runCatching { provider.search(trimmed, limit) }
                tracks = result.getOrElse { failure ->
                    error = failure.message ?: "search failed"
                    emptyList()
                }
                if (tracks.isNotEmpty()) break
            }

            // Desktop fallback: a SoundCloud search for the same query when the
            // platform provider returns nothing (server.js tries both engines).
            if (tracks.isEmpty()) {
                val fallbackPlatform = if (platform == SearchPlatform.YOUTUBE) SearchPlatform.SOUNDCLOUD else SearchPlatform.YOUTUBE
                providers.firstOrNull { it.platform == fallbackPlatform }?.let { fallback ->
                    tracks = runCatching { fallback.search(trimmed, limit) }.getOrDefault(emptyList())
                }
            }

            val result = SearchResult(tracks = tracks, platform = platform, query = trimmed, error = error)
            if (tracks.isNotEmpty()) {
                // Persist so favourites/history/playlists can reference the track id.
                library.upsertAll(tracks)
                cache[key] = CacheEntry(result, System.currentTimeMillis())
            }
            result
        }

    override suspend fun searchLibrary(query: String): List<Track> = withContext(Dispatchers.IO) {
        library.searchLocal(query).first()
    }

    override suspend fun clearCache() {
        cache.clear()
    }

    /** Track ids are stable across providers, so the same track keeps its state. */
    fun platformFor(source: TrackSource): SearchPlatform? = when (source) {
        TrackSource.YOUTUBE -> SearchPlatform.YOUTUBE
        TrackSource.SOUNDCLOUD -> SearchPlatform.SOUNDCLOUD
        else -> null
    }
}
