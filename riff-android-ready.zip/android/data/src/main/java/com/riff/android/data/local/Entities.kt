package com.riff.android.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * The single track table.
 *
 * Desktop equivalent: the (deduplicated) track objects in `localStorage` —
 * `devsize_favorites`, `devsize_history`, `devsize_playlists` — plus the per-file
 * `metadata.json` index the server keeps next to the cached audio files
 * (`saveTrackMetadata()` in server.js).
 *
 * One row per track, whatever brought it in (search, favorite, download, history,
 * MediaStore import). `inLibrary` marks the rows the user actually owns
 * (downloaded or imported), which is what the Library screen lists; favorites and
 * history can legitimately point at remote-only tracks.
 */
@Entity(
    tableName = "tracks",
    indices = [
        Index("normalizedKey"),
        Index("favorite"),
        Index("localUri"),
        Index("lastPlayedAt"),
        Index("inLibrary"),
    ],
)
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String?,
    val durationMs: Long,
    val artworkUri: String?,
    /** `TrackSource.id` — youtube / soundcloud / local / riff. */
    val source: String,
    val sourceId: String?,
    val sourceUrl: String?,
    /** Deezer-backed artist rows only carry a search query (desktop `searchQuery`). */
    val searchQuery: String?,
    /** Local playback source: downloaded file or imported `content://` uri. */
    val localUri: String?,
    val downloadedAt: Long?,
    val fileSizeBytes: Long,
    val favorite: Boolean,
    val favoritedAt: Long?,
    val lastPlayedAt: Long?,
    val playCount: Int,
    val addedAt: Long,
    /** `artist::title` dedupe key (port of `getTrackNormalizedKey()`). */
    val normalizedKey: String,
    /** True for downloaded/imported tracks: the Library screen filters on this. */
    val inLibrary: Boolean,
)

/** Playlists (`state.playlists` in app.js: `{id, name, tracks[]}`). */
@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
)

/** Ordered playlist contents. `position` mirrors the array order the desktop keeps. */
@Entity(
    tableName = "playlist_tracks",
    primaryKeys = ["playlistId", "trackId"],
    indices = [Index("playlistId"), Index("position")],
)
data class PlaylistTrackEntity(
    val playlistId: String,
    val trackId: String,
    val position: Int,
    val addedAt: Long,
)

/** History: deduped by track, newest first, capped at 100 (`pushHistory()`). */
@Entity(tableName = "history", indices = [Index("playedAt")])
data class HistoryEntity(
    @PrimaryKey val trackId: String,
    val playedAt: Long,
    val playCount: Int,
)

/** Downloads. Desktop kept this in memory (`downloadingSet`); it must survive now. */
@Entity(tableName = "downloads", indices = [Index("state")])
data class DownloadEntity(
    @PrimaryKey val trackId: String,
    val state: String,
    val progress: Float,
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val format: String,
    val quality: String,
    val error: String?,
    val attempts: Int,
    val requestedAt: Long,
    val completedAt: Long?,
    val providerId: String,
)

/** Lyrics cache. Desktop keeps `custom-lyrics/` and `lyrics/` as `.lrc` files. */
@Entity(tableName = "lyrics", indices = [Index("trackKey")])
data class LyricsEntity(
    @PrimaryKey val trackKey: String,
    val content: String,
    val synced: Boolean,
    val custom: Boolean,
    val source: String,
    val updatedAt: Long,
)

/**
 * The recommendation engine's "recently recommended" windows (100 ids / 100 keys in
 * server.js). Persisted so a restart does not immediately repeat My Wave.
 */
@Entity(tableName = "seen_recommendations", indices = [Index("seenAt"), Index("kind")])
data class SeenRecommendationEntity(
    @PrimaryKey val value: String,
    val kind: String,
    val seenAt: Long,
)

/** Persisted queue (desktop kept it in memory; resuming after restart is required). */
@Entity(tableName = "queue_items", indices = [Index("position")])
data class QueueItemEntity(
    @PrimaryKey val position: Int,
    val trackId: String,
    val contextKey: String,
    val waveActive: Boolean,
)

/** Single-row playback snapshot: current track, position, modes. */
@Entity(tableName = "playback_state")
data class PlaybackStateEntity(
    @PrimaryKey val id: Int = 1,
    val currentTrackId: String?,
    val positionMs: Long,
    val queueIndex: Int,
    val isPlaying: Boolean,
    val repeatMode: String,
    val shuffle: Boolean,
    val updatedAt: Long,
)

/** Imported MediaStore folders the user excluded (settings mirror). */
@Entity(tableName = "imported_folders")
data class ImportedFolderEntity(
    @PrimaryKey val path: String,
    val importedAt: Long,
)
