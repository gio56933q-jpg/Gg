package com.riff.android.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.riff.android.domain.model.AdvancedSettings
import com.riff.android.domain.model.AudioSettings
import com.riff.android.domain.model.BackendMode
import com.riff.android.domain.model.BackendSettings
import com.riff.android.domain.model.HqEngine
import com.riff.android.domain.model.HqSettings
import com.riff.android.domain.model.LyricsSettings
import com.riff.android.domain.model.PaletteStyle
import com.riff.android.domain.model.PlaybackSettings
import com.riff.android.domain.model.RepeatMode
import com.riff.android.domain.model.RiffPreset
import com.riff.android.domain.model.RiffSettings
import com.riff.android.domain.model.ThemeMode
import com.riff.android.domain.model.ThemeSettings
import com.riff.android.domain.repo.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Settings persistence.
 *
 * Desktop equivalent: the `devsize_*` / `riff_adv_*` localStorage keys read by
 * `loadSettings()` in app.js — theme mode, accent, intensity, brightness, palette
 * style, mesh brightness, audio settings, HQ settings, custom presets, active preset,
 * volume, backend/downloader flags.
 *
 * The Android app keeps the whole document as one JSON blob in DataStore: a single
 * atomic write per change, observable as a Flow, and no schema churn when a setting
 * is added (the JSON decoder ignores unknown keys and fills defaults).
 */
private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "riff_settings")

class SettingsStore(private val context: Context) : SettingsRepository {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val key = stringPreferencesKey(KEY_SETTINGS)

    override fun observeSettings(): Flow<RiffSettings> = context.settingsDataStore.data.map { prefs ->
        prefs[key]
            ?.let { raw -> runCatching { json.decodeFromString(SettingsDocument.serializer(), raw).toDomain() }.getOrNull() }
            ?: RiffSettings()
    }

    override suspend fun current(): RiffSettings = observeSettings().first()

    private suspend fun update(transform: (RiffSettings) -> RiffSettings) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[key]
                ?.let { raw -> runCatching { json.decodeFromString(SettingsDocument.serializer(), raw).toDomain() }.getOrNull() }
                ?: RiffSettings()
            prefs[key] = json.encodeToString(SettingsDocument.serializer(), SettingsDocument.from(transform(current)))
        }
    }

    override suspend fun setTheme(theme: ThemeSettings) = update { it.copy(theme = theme) }

    override suspend fun setPlayback(playback: PlaybackSettings) = update { it.copy(playback = playback) }

    override suspend fun setLyrics(lyrics: LyricsSettings) = update { it.copy(lyrics = lyrics) }

    override suspend fun setAdvanced(advanced: AdvancedSettings) = update { it.copy(advanced = advanced) }

    override suspend fun setBackend(backend: BackendSettings) = update { it.copy(backend = backend) }

    override suspend fun setAudio(audio: AudioSettings) = update { it.copy(audio = audio) }

    override suspend fun setHq(hq: HqSettings, enabled: Boolean) =
        update { it.copy(hq = hq, playback = it.playback.copy(hqEnabled = enabled)) }

    override suspend fun setActivePreset(presetId: String) = update { it.copy(activePresetId = presetId) }

    override suspend fun saveCustomPreset(preset: RiffPreset) = update { settings ->
        settings.copy(customPresets = settings.customPresets.filterNot { it.id == preset.id } + preset)
    }

    override suspend fun deleteCustomPreset(presetId: String) = update { settings ->
        settings.copy(customPresets = settings.customPresets.filterNot { it.id == presetId })
    }

    // --- JSON document (mirrors the domain models 1:1) ----------------------

    @Serializable
    private data class SettingsDocument(
        val themeMode: String = ThemeMode.DARK.id,
        val accent: String = ThemeSettings.DEFAULT_ACCENT,
        val intensity: Int = 0,
        val brightness: Int = 50,
        val paletteStyle: String = PaletteStyle.CLASSIC.id,
        val meshBrightness: Int = 100,
        val dynamicColorFromArtwork: Boolean = true,
        val volume: Float = 0.85f,
        val muted: Boolean = false,
        val repeatMode: String = RepeatMode.OFF.name,
        val shuffle: Boolean = false,
        val hqEnabled: Boolean = false,
        val skipSilence: Boolean = false,
        val crossfadeMs: Long = 0L,
        val lyricsOnline: Boolean = true,
        val lyricsKaraokeWords: Boolean = true,
        val lyricsAutoScroll: Boolean = true,
        val lyricsWordMode: Boolean = false,
        val reducedMotion: Boolean = false,
        val autoExtendWave: Boolean = true,
        val prefetchSearchResults: Boolean = true,
        val downloadOverWifiOnly: Boolean = false,
        val transcodeDownloads: Boolean = false,
        val embedMetadataAndArtwork: Boolean = true,
        val backendMode: String = BackendMode.ON_DEVICE.id,
        val backendBaseUrl: String = "",
        val preferRemoteDownloads: Boolean = false,
        val speed: Float = 1f,
        val speedPitch: Float = 1f,
        val pitch: Int = 0,
        val reverb: Int = 0,
        val distortion: Int = 0,
        val presetVolume: Float = 1f,
        val echo: Int = 0,
        val hqEngine: String = HqEngine.HQ_MUSIC_3.id,
        val hqPreset: String = "studio",
        val hqVocal: Int = 0,
        val hqAir: Int = 0,
        val hqBass: Int = 0,
        val activePresetId: String = "p_default",
        val customPresets: List<PresetDocument> = emptyList(),
        val mediaStoreFolders: List<String> = emptyList(),
        val excludedMediaStoreFolders: List<String> = emptyList(),
    ) {
        fun toDomain(): RiffSettings = RiffSettings(
            theme = ThemeSettings(
                mode = ThemeMode.fromId(themeMode),
                accent = accent,
                intensity = intensity,
                brightness = brightness,
                paletteStyle = PaletteStyle.fromId(paletteStyle),
                meshBrightness = meshBrightness,
                dynamicColorFromArtwork = dynamicColorFromArtwork,
            ),
            playback = PlaybackSettings(
                volume = volume,
                muted = muted,
                repeatMode = runCatching { RepeatMode.valueOf(repeatMode) }.getOrDefault(RepeatMode.OFF),
                shuffle = shuffle,
                hqEnabled = hqEnabled,
                skipSilence = skipSilence,
                crossfadeMs = crossfadeMs,
            ),
            lyrics = LyricsSettings(
                onlineEnabled = lyricsOnline,
                karaokeWords = lyricsKaraokeWords,
                autoScroll = lyricsAutoScroll,
                showWordModeByDefault = lyricsWordMode,
            ),
            advanced = AdvancedSettings(
                reducedMotion = reducedMotion,
                autoExtendWave = autoExtendWave,
                prefetchSearchResults = prefetchSearchResults,
                downloadOverWifiOnly = downloadOverWifiOnly,
                transcodeDownloads = transcodeDownloads,
                embedMetadataAndArtwork = embedMetadataAndArtwork,
            ),
            backend = BackendSettings(
                mode = BackendMode.fromId(backendMode),
                baseUrl = backendBaseUrl,
                preferRemoteDownloads = preferRemoteDownloads,
            ),
            audio = AudioSettings(
                speed = speed,
                speedPitch = speedPitch,
                pitch = pitch,
                reverb = reverb,
                distortion = distortion,
                volume = presetVolume,
                echo = echo,
            ),
            hq = HqSettings(
                engine = HqEngine.fromId(hqEngine),
                preset = hqPreset,
                vocal = hqVocal,
                air = hqAir,
                bass = hqBass,
            ),
            activePresetId = activePresetId,
            customPresets = customPresets.map { it.toDomain() },
            mediaStoreFolders = mediaStoreFolders.toSet(),
            excludedMediaStoreFolders = excludedMediaStoreFolders.toSet(),
        )

        companion object {
            fun from(settings: RiffSettings) = SettingsDocument(
                themeMode = settings.theme.mode.id,
                accent = settings.theme.accent,
                intensity = settings.theme.intensity,
                brightness = settings.theme.brightness,
                paletteStyle = settings.theme.paletteStyle.id,
                meshBrightness = settings.theme.meshBrightness,
                dynamicColorFromArtwork = settings.theme.dynamicColorFromArtwork,
                volume = settings.playback.volume,
                muted = settings.playback.muted,
                repeatMode = settings.playback.repeatMode.name,
                shuffle = settings.playback.shuffle,
                hqEnabled = settings.playback.hqEnabled,
                skipSilence = settings.playback.skipSilence,
                crossfadeMs = settings.playback.crossfadeMs,
                lyricsOnline = settings.lyrics.onlineEnabled,
                lyricsKaraokeWords = settings.lyrics.karaokeWords,
                lyricsAutoScroll = settings.lyrics.autoScroll,
                lyricsWordMode = settings.lyrics.showWordModeByDefault,
                reducedMotion = settings.advanced.reducedMotion,
                autoExtendWave = settings.advanced.autoExtendWave,
                prefetchSearchResults = settings.advanced.prefetchSearchResults,
                downloadOverWifiOnly = settings.advanced.downloadOverWifiOnly,
                transcodeDownloads = settings.advanced.transcodeDownloads,
                embedMetadataAndArtwork = settings.advanced.embedMetadataAndArtwork,
                backendMode = settings.backend.mode.id,
                backendBaseUrl = settings.backend.baseUrl,
                preferRemoteDownloads = settings.backend.preferRemoteDownloads,
                speed = settings.audio.speed,
                speedPitch = settings.audio.speedPitch,
                pitch = settings.audio.pitch,
                reverb = settings.audio.reverb,
                distortion = settings.audio.distortion,
                presetVolume = settings.audio.volume,
                echo = settings.audio.echo,
                hqEngine = settings.hq.engine.id,
                hqPreset = settings.hq.preset,
                hqVocal = settings.hq.vocal,
                hqAir = settings.hq.air,
                hqBass = settings.hq.bass,
                activePresetId = settings.activePresetId,
                customPresets = settings.customPresets.map { PresetDocument.from(it) },
                mediaStoreFolders = settings.mediaStoreFolders.toList(),
                excludedMediaStoreFolders = settings.excludedMediaStoreFolders.toList(),
            )
        }
    }

    @Serializable
    private data class PresetDocument(
        val id: String,
        val name: String,
        val speed: Float,
        val speedPitch: Float,
        val pitch: Int,
        val reverb: Int,
        val distortion: Int,
        val volume: Float,
        val echo: Int,
    ) {
        fun toDomain() = RiffPreset(
            id = id,
            name = name,
            settings = AudioSettings(
                speed = speed,
                speedPitch = speedPitch,
                pitch = pitch,
                reverb = reverb,
                distortion = distortion,
                volume = volume,
                echo = echo,
            ),
        )

        companion object {
            fun from(preset: RiffPreset) = PresetDocument(
                id = preset.id,
                name = preset.name,
                speed = preset.settings.speed,
                speedPitch = preset.settings.speedPitch,
                pitch = preset.settings.pitch,
                reverb = preset.settings.reverb,
                distortion = preset.settings.distortion,
                volume = preset.settings.volume,
                echo = preset.settings.echo,
            )
        }
    }

    private companion object {
        const val KEY_SETTINGS = "riff_settings_json"
    }
}
