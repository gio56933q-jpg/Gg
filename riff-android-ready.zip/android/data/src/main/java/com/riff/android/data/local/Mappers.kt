package com.riff.android.data.local

import com.riff.android.domain.model.Album
import com.riff.android.domain.model.Artist
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.DownloadState
import com.riff.android.domain.model.DownloadTask
import com.riff.android.domain.model.HistoryEntry
import com.riff.android.domain.model.Lyrics
import com.riff.android.domain.model.LyricsSource
import com.riff.android.domain.model.Playlist
import com.riff.android.domain.model.RepeatMode
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.text.TrackText

/**
 * Entity <-> domain mapping. Kept in one place so the app never grows two competing
 * track representations (a hard requirement of the task): the UI only ever sees
 * `domain.model.Track`, and `TrackEntity` is a storage detail.
 *
 * These are top-level extension functions on purpose: member extensions declared in
 * an `object` cannot be imported, and every repository needs them.
 */
    fun TrackEntity.toDomain(): Track = Track(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        artworkUri = artworkUri,
        source = TrackSource.fromId(source),
        sourceId = sourceId,
        sourceUrl = sourceUrl,
        searchQuery = searchQuery,
        localUri = localUri,
        downloadedAt = downloadedAt,
        fileSizeBytes = fileSizeBytes,
        favorite = favorite,
        lastPlayedAt = lastPlayedAt,
        playCount = playCount,
        addedAt = addedAt,
    )

    /**
     * Merges a domain track into a row.
     *
     * Display fields are refreshed from the incoming value (a fresh search hit has
     * better metadata than an old row) but local state — download link, favorite
     * flag, play counters, import time — is always preserved, which is what
     * `saveTrackMetadata()` does on the desktop by merging into the existing JSON.
     */
    fun Track.toEntity(existing: TrackEntity? = null, inLibrary: Boolean = existing?.inLibrary ?: false): TrackEntity {
        val key = normalizedKey.ifBlank { TrackText.normalizeKey(artist, title) }
        return TrackEntity(
            id = id,
            title = title.ifBlank { existing?.title ?: "untitled" },
            artist = artist.ifBlank { existing?.artist ?: "unknown artist" },
            album = album ?: existing?.album,
            durationMs = if (durationMs > 0) durationMs else existing?.durationMs ?: 0L,
            artworkUri = artworkUri?.takeIf { it.isNotBlank() } ?: existing?.artworkUri,
            source = source.id,
            sourceId = sourceId ?: existing?.sourceId,
            sourceUrl = sourceUrl?.takeIf { it.isNotBlank() } ?: existing?.sourceUrl,
            searchQuery = searchQuery ?: existing?.searchQuery,
            localUri = localUri ?: existing?.localUri,
            downloadedAt = downloadedAt ?: existing?.downloadedAt,
            fileSizeBytes = if (fileSizeBytes > 0) fileSizeBytes else existing?.fileSizeBytes ?: 0L,
            favorite = favorite || (existing?.favorite ?: false),
            favoritedAt = existing?.favoritedAt ?: if (favorite) System.currentTimeMillis() else null,
            lastPlayedAt = lastPlayedAt ?: existing?.lastPlayedAt,
            playCount = maxOf(playCount, existing?.playCount ?: 0),
            addedAt = if (addedAt > 0) addedAt else existing?.addedAt ?: System.currentTimeMillis(),
            normalizedKey = key,
            inLibrary = inLibrary || localUri != null || downloadedAt != null,
        )
    }

    fun DownloadEntity.toDomain(): DownloadTask = DownloadTask(
        trackId = trackId,
        state = runCatching { DownloadState.valueOf(state) }.getOrDefault(DownloadState.QUEUED),
        progress = progress,
        bytesDownloaded = bytesDownloaded,
        totalBytes = totalBytes,
        format = DownloadFormat.fromId(format),
        quality = DownloadQuality.fromId(quality),
        error = error,
        attempts = attempts,
        requestedAt = requestedAt,
        completedAt = completedAt,
        providerId = providerId,
    )

    fun DownloadTask.toEntity(): DownloadEntity = DownloadEntity(
        trackId = trackId,
        state = state.name,
        progress = progress,
        bytesDownloaded = bytesDownloaded,
        totalBytes = totalBytes,
        format = format.extension,
        quality = quality.id,
        error = error,
        attempts = attempts,
        requestedAt = requestedAt,
        completedAt = completedAt,
        providerId = providerId,
    )

    fun PlaylistEntity.toDomain(coverUris: List<String> = emptyList(), trackCount: Int = 0): Playlist = Playlist(
        id = id,
        name = name,
        trackCount = trackCount,
        createdAt = createdAt,
        updatedAt = updatedAt,
        coverUris = coverUris,
    )

    fun ArtistRow.toDomain(): Artist = Artist(
        name = name,
        trackCount = trackCount,
        artworkUri = artworkUri?.takeIf { it.isNotBlank() },
    )

    fun AlbumRow.toDomain(): Album = Album(
        name = name,
        artist = artist,
        trackCount = trackCount,
        artworkUri = artworkUri?.takeIf { it.isNotBlank() },
    )

    fun LyricsEntity.toDomain(raw: String = content): Lyrics = Lyrics(
        trackKey = trackKey,
        lines = emptyList(),
        source = runCatching { LyricsSource.valueOf(source) }.getOrDefault(LyricsSource.NONE),
        synced = synced,
        raw = raw,
        updatedAt = updatedAt,
    )

    fun RepeatMode.toStorage(): String = name

    fun String.toRepeatMode(): RepeatMode = runCatching { RepeatMode.valueOf(this) }.getOrDefault(RepeatMode.OFF)

    fun HistoryEntity.toDomain(): HistoryEntry = HistoryEntry(trackId = trackId, playedAt = playedAt)

    /** Downloads are stored with the track id so the UI can join without a second query. */
    fun DownloadTask.trackIdOrNull(): String? = trackId.takeIf { it.isNotBlank() }
