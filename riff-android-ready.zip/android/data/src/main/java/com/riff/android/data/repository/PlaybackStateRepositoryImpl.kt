package com.riff.android.data.repository

import androidx.room.withTransaction
import com.riff.android.data.local.PlaybackStateEntity
import com.riff.android.data.local.QueueItemEntity
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.toDomain
import com.riff.android.domain.model.PlaybackSnapshot
import com.riff.android.domain.model.RepeatMode
import com.riff.android.domain.model.Track
import com.riff.android.domain.repo.PlaybackStateRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * Resume state.
 *
 * The desktop app kept the queue in memory and persisted only history, so a restart
 * lost everything. The task explicitly requires resuming after a restart, so the
 * current item, the position, the queue, repeat/shuffle are written to Room by the
 * playback service (every 5 s while playing, on every transition, and on shutdown).
 *
 * The queue itself is stored as an ordered id list; the tracks come from the library
 * table so a resumed session always has fresh metadata.
 */
class PlaybackStateRepositoryImpl(private val database: RiffDatabase) : PlaybackStateRepository {

    private val dao = database.playback()

    override fun observe(): Flow<PlaybackSnapshot> = dao.observe().map { entity ->
        entity?.let { row ->
            PlaybackSnapshot(
                currentTrackId = row.currentTrackId,
                positionMs = row.positionMs,
                queueIndex = row.queueIndex,
                queueIds = dao.queue().map { it.trackId },
                isPlaying = row.isPlaying,
                repeatMode = runCatching { RepeatMode.valueOf(row.repeatMode) }.getOrDefault(RepeatMode.OFF),
                shuffle = row.shuffle,
                updatedAt = row.updatedAt,
            )
        } ?: PlaybackSnapshot()
    }

    override suspend fun save(snapshot: PlaybackSnapshot) = withContext(Dispatchers.IO) {
        database.withTransaction {
            dao.upsert(
                PlaybackStateEntity(
                    id = 1,
                    currentTrackId = snapshot.currentTrackId,
                    positionMs = snapshot.positionMs,
                    queueIndex = snapshot.queueIndex,
                    isPlaying = snapshot.isPlaying,
                    repeatMode = snapshot.repeatMode.name,
                    shuffle = snapshot.shuffle,
                    updatedAt = snapshot.updatedAt,
                ),
            )
            dao.saveQueue(
                snapshot.queueIds.mapIndexed { index, trackId ->
                    QueueItemEntity(
                        position = index,
                        trackId = trackId,
                        contextKey = "",
                        waveActive = false,
                    )
                },
            )
        }
    }

    override suspend fun clear() = withContext(Dispatchers.IO) {
        database.withTransaction {
            dao.clearState()
            dao.clearQueue()
        }
    }

    /** Used by tests and by the player's "restore" diagnostics. */
    suspend fun queueTracks(): List<Track> = withContext(Dispatchers.IO) {
        val ids = dao.queue().map { it.trackId }
        val byId = database.tracks().getByIds(ids).associateBy { it.id }
        ids.mapNotNull { id -> byId[id]?.toDomain() }
    }
}
