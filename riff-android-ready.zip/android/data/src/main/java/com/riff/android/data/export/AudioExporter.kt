package com.riff.android.data.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.riff.android.core.util.AudioMime
import com.riff.android.domain.model.ExportFormat
import com.riff.android.domain.model.ExportRequest
import com.riff.android.domain.model.ExportResult
import com.riff.android.domain.repo.ExportRepository
import com.riff.android.domain.repo.LibraryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Audio editor export (trim ± effects).
 *
 * Desktop equivalent: the offline render in `audio-engine.js`
 * (`OfflineAudioContext` with the whole effects graph) followed by
 * `audioBufferToWav()` and a save dialog — the renderer produced a WAV.
 *
 * Android has no Web Audio, so the export is implemented with platform media APIs:
 *  - **trim** uses `MediaExtractor` + `MediaMuxer` (stream copy, no re-encode when the
 *    source codec is AAC/MP3/Opus-in-MP4) — fast and lossless,
 *  - when the container cannot hold the codec (e.g. Opus/WebM), the audio is decoded
 *    to PCM and written as a **WAV** file, which any player can open.
 *
 * Effects are **not** re-rendered: Media3's `Transformer` is the intended path for
 * that (`Effects` + `AudioProcessor` chain), but the dependency is not part of this
 * build. This limitation is documented in android/PORTING.md, and the export request
 * carries the settings so a future implementation can honour them.
 */
class AudioExporter(
    private val context: Context,
    private val library: LibraryRepository,
) : ExportRepository {

    override suspend fun export(request: ExportRequest): ExportResult = withContext(Dispatchers.IO) {
        // `trackId` may be a library id or an already-resolved local uri.
        val sourceUri = when {
            request.trackId.startsWith("file://") || request.trackId.startsWith("content://") -> request.trackId
            else -> library.get(request.trackId)?.localUri
        } ?: return@withContext ExportResult.Failure("only downloaded or imported tracks can be exported")

        val extension = request.format.extension
        val trackName = runCatching { library.get(request.trackId) }.getOrNull()
            ?.let { com.riff.android.domain.text.TrackText.sanitizeFilename("${it.artist} - ${it.title}") }
            ?.takeIf { it.isNotBlank() }
            ?: "riff-export"
        val outputDir = File(context.filesDir, "exports").apply { mkdirs() }
        val output = File(outputDir, "$trackName (${request.startMs / 1000}s-${request.endMs / 1000}s).$extension")

        runCatching { Uri.parse(sourceUri) }.getOrNull() ?: return@withContext ExportResult.Failure("nothing to export")

        runCatching {
            when (request.format) {
                ExportFormat.WAV -> exportToWav(sourceUri, output, request.startMs, request.endMs)
                ExportFormat.M4A -> exportToM4a(sourceUri, output, request.startMs, request.endMs)
                ExportFormat.OPUS -> return@withContext ExportResult.Unsupported
            }
        }.fold(
            onSuccess = { bytes ->
                ExportResult.Success(
                    uri = output.toURI().toString(),
                    displayName = output.name,
                    bytes = bytes,
                )
            },
            onFailure = { error ->
                output.delete()
                ExportResult.Failure(error.message ?: "export failed")
            },
        )
    }

    /** Stream-copies the selected range into an MP4/M4A container. */
    private fun exportToM4a(sourceUri: String, output: File, startMs: Long, endMs: Long): Long {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, Uri.parse(sourceUri), null)

        val trackIndex = (0 until extractor.trackCount).firstOrNull { index ->
            extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")
        } ?: error("no audio track found")

        val format = extractor.getTrackFormat(trackIndex)
        val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
        if (!SUPPORTED_IN_MP4.any { mime.startsWith(it) }) {
            // Opus/Vorbis/FLAC cannot be muxed into MP4 by the platform muxer.
            extractor.release()
            return exportToWav(sourceUri, output, startMs, endMs)
        }

        extractor.selectTrack(trackIndex)
        extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val muxerTrack = muxer.addTrack(format)
        muxer.start()

        val maxInputSize = format.getIntegerOrDefault(MediaFormat.KEY_MAX_INPUT_SIZE, DEFAULT_BUFFER_SIZE)
        val buffer = ByteBuffer.allocate(maxInputSize)
        val info = MediaCodec.BufferInfo()
        val endUs = endMs * 1000

        try {
            while (true) {
                buffer.clear()
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val sampleTime = extractor.sampleTime
                if (sampleTime > endUs) break

                info.set(0, sampleSize, sampleTime - startMs * 1000, extractor.sampleFlags)
                muxer.writeSampleData(muxerTrack, buffer, info)
                extractor.advance()
            }
        } finally {
            runCatching { muxer.stop() }
            runCatching { muxer.release() }
            extractor.release()
        }
        return output.length()
    }

    /** Decodes to PCM with MediaCodec and writes a WAV file (any source codec). */
    private fun exportToWav(sourceUri: String, output: File, startMs: Long, endMs: Long): Long {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, Uri.parse(sourceUri), null)

        val trackIndex = (0 until extractor.trackCount).firstOrNull { index ->
            extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")
        } ?: error("no audio track found")

        val inputFormat = extractor.getTrackFormat(trackIndex)
        val mime = inputFormat.getString(MediaFormat.KEY_MIME).orEmpty()
        extractor.selectTrack(trackIndex)
        extractor.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

        val decoder = MediaCodec.createDecoderByType(mime)
        decoder.configure(inputFormat, null, null, 0)
        decoder.start()

        val sampleRate = inputFormat.getIntegerOrDefault(MediaFormat.KEY_SAMPLE_RATE, 44_100)
        val channelCount = inputFormat.getIntegerOrDefault(MediaFormat.KEY_CHANNEL_COUNT, 2)

        val pcm = output.outputStream().buffered()
        // Reserve the WAV header: it is rewritten once the data size is known.
        val header = ByteArray(44)
        pcm.write(header)

        var dataBytes = 0L
        val endUs = endMs * 1000
        var inputDone = false
        var outputDone = false
        val info = MediaCodec.BufferInfo()

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(TIMEOUT_US)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex) ?: continue
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        val sampleTime = extractor.sampleTime
                        when {
                            sampleSize < 0 || sampleTime > endUs -> {
                                decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            }
                            else -> {
                                decoder.queueInputBuffer(inputIndex, 0, sampleSize, sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                when (val outputIndex = decoder.dequeueOutputBuffer(info, TIMEOUT_US)) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> Unit
                    else -> if (outputIndex >= 0) {
                        val outputBuffer = decoder.getOutputBuffer(outputIndex) ?: continue
                        if (info.size > 0 && info.presentationTimeUs <= endUs) {
                            val chunk = ByteArray(info.size)
                            outputBuffer.position(info.offset)
                            outputBuffer.limit(info.offset + info.size)
                            outputBuffer.get(chunk)
                            pcm.write(chunk)
                            dataBytes += chunk.size
                        }
                        decoder.releaseOutputBuffer(outputIndex, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
        } finally {
            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            extractor.release()
            pcm.flush()
            pcm.close()
        }

        writeWavHeader(output, dataBytes, sampleRate, channelCount)
        return output.length()
    }

    private fun writeWavHeader(file: File, dataBytes: Long, sampleRate: Int, channels: Int) {
        val byteRate = sampleRate * channels * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt((36 + dataBytes).toInt())
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1) // PCM
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort((channels * 2).toShort())
        header.putShort(16) // bits per sample
        header.put("data".toByteArray())
        header.putInt(dataBytes.toInt())

        java.io.RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            raf.write(header.array())
        }
    }

    private fun MediaFormat.getIntegerOrDefault(key: String, fallback: Int): Int =
        if (containsKey(key)) getInteger(key) else fallback

    private companion object {
        const val TIMEOUT_US = 10_000L
        val SUPPORTED_IN_MP4 = listOf("audio/mp4a", "audio/mpeg", "audio/3gpp", "audio/amr-wb")
    }
}

/** Marker used by the UI to show the export limitation of the current build. */
object ExportSupport {
    /** Effects cannot be re-rendered without Media3 Transformer (documented limitation). */
    const val CAN_RENDER_EFFECTS = false
    val SUPPORTED_FORMATS = setOf(ExportFormat.WAV, ExportFormat.M4A)

    fun isSupported(request: ExportRequest): Boolean = request.format in SUPPORTED_FORMATS
}
