package com.riff.android.data

import com.google.common.truth.Truth.assertThat
import com.riff.android.data.local.DownloadEntity
import com.riff.android.data.local.LyricsEntity
import com.riff.android.data.local.PlaylistEntity
import com.riff.android.data.local.TrackEntity
import com.riff.android.data.local.toDomain
import com.riff.android.data.local.toEntity
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.DownloadState
import com.riff.android.domain.model.DownloadTask
import com.riff.android.domain.model.LyricsSource
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import org.junit.Test

/**
 * Entity <-> domain mapping.
 *
 * These tests matter because `TrackEntity` is the only place Android keeps local state
 * (favourite flag, download uri, play counters). A mapping bug would either drop a
 * download when the app restarts or resurrect deleted state, so the merge rules are
 * pinned here.
 */
class MappersTest {

    private fun track(
        id: String = "youtube:abc",
        title: String = "Song",
        artist: String = "Artist",
        favorite: Boolean = false,
    ) = Track(
        id = id,
        title = title,
        artist = artist,
        album = "Album",
        durationMs = 210_000,
        artworkUri = "https://img/riff.jpg",
        source = TrackSource.YOUTUBE,
        sourceId = "abc",
        sourceUrl = "https://youtube.com/watch?v=abc",
        favorite = favorite,
        playCount = 0,
    )

    @Test
    fun `track round trip keeps every field`() {
        val original = track()
        val restored = original.toEntity().toDomain()

        assertThat(restored.id).isEqualTo(original.id)
        assertThat(restored.title).isEqualTo(original.title)
        assertThat(restored.artist).isEqualTo(original.artist)
        assertThat(restored.album).isEqualTo(original.album)
        assertThat(restored.durationMs).isEqualTo(original.durationMs)
        assertThat(restored.artworkUri).isEqualTo(original.artworkUri)
        assertThat(restored.source).isEqualTo(TrackSource.YOUTUBE)
        assertThat(restored.sourceId).isEqualTo("abc")
        assertThat(restored.sourceUrl).isEqualTo(original.sourceUrl)
        assertThat(restored.normalizedKey).isEqualTo(original.normalizedKey)
    }

    @Test
    fun `normalized key is filled in when the domain track has none`() {
        // TrackEntity always stores a key so the unique index cannot be bypassed; the
        // mapper derives it from artist+title when the domain key is blank.
        val withoutKey = Track(
            id = "youtube:abc",
            title = "Song (Official Video)",
            artist = "Artist",
            source = TrackSource.YOUTUBE,
            sourceId = "abc",
        )
        assertThat(withoutKey.normalizedKey).isNotEmpty()
        assertThat(withoutKey.toEntity().normalizedKey).isEqualTo(withoutKey.normalizedKey)
    }

    @Test
    fun `local playback state survives a metadata refresh`() {
        val downloaded = track().toEntity(inLibrary = true).copy(
            localUri = "file:///data/music/Artist - Song.opus",
            downloadedAt = 1_700_000_000_000,
            fileSizeBytes = 3_500_000,
            favorite = true,
            lastPlayedAt = 1_700_000_100_000,
            playCount = 4,
        )

        // A fresh search result for the same track carries no local state.
        val refreshed = track(title = "Song").copy(album = null).toEntity(existing = downloaded)

        assertThat(refreshed.localUri).isEqualTo(downloaded.localUri)
        assertThat(refreshed.downloadedAt).isEqualTo(downloaded.downloadedAt)
        assertThat(refreshed.fileSizeBytes).isEqualTo(downloaded.fileSizeBytes)
        assertThat(refreshed.favorite).isTrue()
        assertThat(refreshed.lastPlayedAt).isEqualTo(downloaded.lastPlayedAt)
        assertThat(refreshed.playCount).isEqualTo(4)
        assertThat(refreshed.album).isEqualTo("Album")
        assertThat(refreshed.inLibrary).isTrue()
    }

    @Test
    fun `a downloaded track is always part of the offline library`() {
        val entity = track().copy(localUri = "file:///music/x.opus", downloadedAt = 5L).toEntity()
        assertThat(entity.inLibrary).isTrue()
    }

    @Test
    fun `blank titles and artists get storage defaults`() {
        val entity = track(title = "", artist = "").toEntity()
        assertThat(entity.title).isEqualTo("untitled")
        assertThat(entity.artist).isEqualTo("unknown artist")
    }

    @Test
    fun `download task survives the entity round trip`() {
        val task = DownloadTask(
            trackId = "youtube:abc",
            state = DownloadState.RUNNING,
            progress = 0.42f,
            bytesDownloaded = 1_500_000,
            totalBytes = 3_500_000,
            format = DownloadFormat.FLAC,
            quality = DownloadQuality.HIGH,
            error = null,
            attempts = 1,
            requestedAt = 100L,
            completedAt = null,
            providerId = "on-device",
        )

        val restored = task.toEntity().toDomain()

        assertThat(restored.trackId).isEqualTo(task.trackId)
        assertThat(restored.state).isEqualTo(DownloadState.RUNNING)
        assertThat(restored.progress).isWithin(0.001f).of(0.42f)
        assertThat(restored.format).isEqualTo(DownloadFormat.FLAC)
        assertThat(restored.quality).isEqualTo(DownloadQuality.HIGH)
        assertThat(restored.providerId).isEqualTo("on-device")
    }

    @Test
    fun `an unknown persisted download state falls back to queued`() {
        val entity = DownloadEntity(
            trackId = "x",
            state = "SOMETHING_NEW",
            progress = 0f,
            bytesDownloaded = 0,
            totalBytes = 0,
            format = "mp3",
            quality = "0",
            error = null,
            attempts = 0,
            requestedAt = 0,
            completedAt = null,
            providerId = "",
        )
        assertThat(entity.toDomain().state).isEqualTo(DownloadState.QUEUED)
    }

    @Test
    fun `playlist entity maps covers and track count`() {
        val playlist = PlaylistEntity(id = "pl_1", name = "Chill", createdAt = 1L, updatedAt = 2L)
            .toDomain(coverUris = listOf("a", "b"), trackCount = 7)

        assertThat(playlist.id).isEqualTo("pl_1")
        assertThat(playlist.name).isEqualTo("Chill")
        assertThat(playlist.trackCount).isEqualTo(7)
        assertThat(playlist.coverUris).containsExactly("a", "b").inOrder()
    }

    @Test
    fun `lyrics entity keeps the raw text and the custom flag`() {
        val entity = LyricsEntity(
            trackKey = "artist___song",
            content = "[00:10.00]hello",
            synced = true,
            custom = true,
            source = LyricsSource.CUSTOM.name,
            updatedAt = 9L,
        )
        val lyrics = entity.toDomain()

        assertThat(lyrics.trackKey).isEqualTo("artist___song")
        assertThat(lyrics.raw).isEqualTo("[00:10.00]hello")
        assertThat(lyrics.synced).isTrue()
        assertThat(lyrics.isCustom).isTrue()
    }
}
