package com.riff.android.data

import com.google.common.truth.Truth.assertThat
import com.riff.android.data.provider.RiffSearchJson
import com.riff.android.data.provider.extractYouTubeId
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.TrackSource
import org.junit.Test

/**
 * Search result mapping.
 *
 * The payload below is the shape `handleSearch` in server.js returns (it was copied
 * from the desktop endpoint, including `isCached` and the flat yt-dlp fields), so this
 * test is also a check that the Android client stays compatible with the desktop
 * backend it can optionally talk to.
 */
class SearchMappingTest {

    private val youtubeBody = """
        {
          "success": true,
          "tracks": [
            {
              "id": "dQw4w9WgXcQ",
              "title": "Rick Astley - Never Gonna Give You Up (Official Video)",
              "artist": "Rick Astley",
              "duration": 213,
              "thumbnail": "https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg",
              "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
              "platform": "youtube",
              "isCached": true
            },
            {
              "id": "aaa",
              "title": "Some SoundCloud import",
              "artist": "",
              "duration": 0,
              "platform": "soundcloud",
              "url": "https://soundcloud.com/who/some-song"
            },
            {
              "id": "empty",
              "title": "",
              "artist": "ghost"
            }
          ]
        }
    """.trimIndent()

    @Test
    fun `youtube hits map to tracks`() {
        val tracks = RiffSearchJson.parse(youtubeBody, SearchPlatform.YOUTUBE)

        // The blank-title hit is dropped; the other two survive.
        assertThat(tracks).hasSize(2)

        val first = tracks[0]
        assertThat(first.title).isEqualTo("Rick Astley - Never Gonna Give You Up (Official Video)")
        assertThat(first.artist).isEqualTo("Rick Astley")
        assertThat(first.durationMs).isEqualTo(213_000)
        assertThat(first.artworkUri).isEqualTo("https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg")
        assertThat(first.source).isEqualTo(TrackSource.YOUTUBE)
        assertThat(first.sourceUrl).isEqualTo("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        assertThat(first.id).isEqualTo("dQw4w9WgXcQ")
    }

    @Test
    fun `missing artists and durations are normalised`() {
        val tracks = RiffSearchJson.parse(youtubeBody, SearchPlatform.YOUTUBE)
        val second = tracks[1]

        assertThat(second.artist).isEqualTo("unknown artist")
        assertThat(second.durationMs).isEqualTo(0)
        // The hit carries its own platform, which wins over the request platform.
        assertThat(second.source).isEqualTo(TrackSource.SOUNDCLOUD)
    }

    @Test
    fun `malformed payloads return an empty list instead of throwing`() {
        assertThat(RiffSearchJson.parse("not json at all", SearchPlatform.YOUTUBE)).isEmpty()
        assertThat(RiffSearchJson.parse("{}", SearchPlatform.YOUTUBE)).isEmpty()
        assertThat(RiffSearchJson.parse("""{"success":false}""", SearchPlatform.YOUTUBE)).isEmpty()
    }

    @Test
    fun `unknown fields from a newer desktop server are ignored`() {
        val body = """
            {"success":true,"tracks":[{"id":"x1","title":"Song","artist":"Artist","duration":100,
            "platform":"youtube","newDesktopField":"ignored","isCached":false}],"serverVersion":9}
        """.trimIndent()

        val tracks = RiffSearchJson.parse(body, SearchPlatform.YOUTUBE)
        assertThat(tracks).hasSize(1)
        assertThat(tracks.first().title).isEqualTo("Song")
    }

    @Test
    fun `soundcloud requests default to the soundcloud source`() {
        val body = """{"success":true,"tracks":[{"title":"Track","artist":"Artist","duration":180}]}"""
        val tracks = RiffSearchJson.parse(body, SearchPlatform.SOUNDCLOUD)

        assertThat(tracks).hasSize(1)
        assertThat(tracks.first().source).isEqualTo(TrackSource.SOUNDCLOUD)
    }

    @Test
    fun `youtube ids are extracted from every url shape the desktop produces`() {
        assertThat(extractYouTubeId("https://www.youtube.com/watch?v=dQw4w9WgXcQ")).isEqualTo("dQw4w9WgXcQ")
        assertThat(extractYouTubeId("https://youtube.com/watch?v=dQw4w9WgXcQ&t=42s")).isEqualTo("dQw4w9WgXcQ")
        assertThat(extractYouTubeId("https://youtu.be/dQw4w9WgXcQ")).isEqualTo("dQw4w9WgXcQ")
        assertThat(extractYouTubeId("https://www.youtube.com/shorts/dQw4w9WgXcQ")).isEqualTo("dQw4w9WgXcQ")
        assertThat(extractYouTubeId("https://soundcloud.com/artist/song")).isNull()
        assertThat(extractYouTubeId(null)).isNull()
    }

    @Test
    fun `search result ids are stable for the same video`() {
        val body = """{"success":true,"tracks":[
            {"id":"dQw4w9WgXcQ","title":"Song","artist":"Artist","duration":213,"platform":"youtube"},
            {"id":"dQw4w9WgXcQ","title":"Song (Official Video)","artist":"Artist","duration":213,"platform":"youtube"}
        ]}"""
        val tracks = RiffSearchJson.parse(body, SearchPlatform.YOUTUBE)

        assertThat(tracks.map { it.id }).containsExactly("dQw4w9WgXcQ", "dQw4w9WgXcQ")
        assertThat(tracks[0].normalizedKey).isEqualTo(tracks[1].normalizedKey)
    }
}
