package com.riff.android.data

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.google.common.truth.Truth.assertThat
import com.riff.android.data.local.HistoryEntity
import com.riff.android.data.local.PlaybackStateEntity
import com.riff.android.data.local.PlaylistEntity
import com.riff.android.data.local.RiffDatabase
import com.riff.android.data.local.TrackEntity
import com.riff.android.data.local.toDomain
import com.riff.android.data.local.toEntity
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.text.TrackText
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Database behaviour on a device/emulator.
 *
 * The unit tests cover the mappers; these exercise the real Room queries, because the
 * library/history/playlist screens are all "observe a query" — a wrong DAO query is
 * invisible in a unit test. Runs on an in-memory database so nothing leaks between tests.
 */
@RunWith(AndroidJUnit4::class)
class RiffDatabaseTest {

    private lateinit var db: RiffDatabase

    @Before
    fun setUp() {
        db = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            RiffDatabase::class.java,
        ).allowMainThreadQueries().build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun track(
        id: String,
        title: String = "Song",
        artist: String = "Artist",
        favorite: Boolean = false,
    ) = Track(
        id = id,
        title = title,
        artist = artist,
        durationMs = 180_000,
        source = TrackSource.YOUTUBE,
        sourceId = id,
        sourceUrl = "https://youtube.com/watch?v=$id",
        favorite = favorite,
    )

    @Test
    fun upsertAndObserveLibrary() = runTest {
        val dao = db.tracks()
        dao.upsert(track("a").toEntity(inLibrary = true))
        dao.upsert(track("b", title = "Other").toEntity(inLibrary = true))

        val library = dao.observeLibrary().first()
        assertThat(library.map { it.id }).containsExactly("a", "b")

        // Re-upserting the same id must update, not duplicate.
        dao.upsert(track("a", title = "Renamed").toEntity(inLibrary = true))
        assertThat(dao.observeLibrary().first()).hasSize(2)
        assertThat(dao.get("a")?.title).isEqualTo("Renamed")
        Unit
    }

    @Test
    fun findByNormalizedKeyMatchesDecoratedTitles() = runTest {
        val dao = db.tracks()
        val stored = track("a", title = "Song (Official Video)")
        dao.upsert(stored.toEntity(inLibrary = true))

        val key = TrackText.normalizeKey(stored.artist, stored.title)
        assertThat(dao.findByKey(key)?.id).isEqualTo("a")
        Unit
    }

    @Test
    fun favoritesQueryOnlyReturnsFavorites() = runTest {
        val dao = db.tracks()
        dao.upsert(track("a", favorite = true).toEntity(inLibrary = true))
        dao.upsert(track("b").toEntity(inLibrary = true))

        assertThat(dao.observeFavorites().first().map { it.id }).containsExactly("a")
        Unit
    }

    @Test
    fun historyIsOrderedNewestFirstAndLimited() = runTest {
        val tracks = db.tracks()
        val history = db.history()

        repeat(120) { index ->
            tracks.upsert(track("t$index").toEntity(inLibrary = true))
            history.upsert(HistoryEntity(trackId = "t$index", playedAt = index.toLong(), playCount = 1))
        }
        history.trim(100)

        val ordered = tracks.observeHistoryOrdered(100).first()
        assertThat(ordered).hasSize(100)
        assertThat(ordered.first().id).isEqualTo("t119")
        Unit
    }

    @Test
    fun downloadBytesAreSummedForTheStorageLine() = runTest {
        val tracks = db.tracks()
        tracks.upsert(track("a").toEntity(inLibrary = true).copy(localUri = "file:///a.opus", fileSizeBytes = 1_000))
        tracks.upsert(track("b").toEntity(inLibrary = true).copy(localUri = "file:///b.opus", fileSizeBytes = 2_500))

        assertThat(tracks.totalDownloadBytes()).isEqualTo(3_500)
        Unit
    }

    @Test
    fun playlistTracksKeepTheirOrderAndReorderingWorks() = runTest {
        val playlists = db.playlists()
        val tracks = db.tracks()
        listOf("a", "b", "c").forEachIndexed { index, id ->
            tracks.upsert(track(id, title = "Song $id").toEntity(inLibrary = true))
        }
        playlists.upsertPlaylist(PlaylistEntity("pl_1", "Chill", 1L, 1L))
        playlists.addTracks("pl_1", listOf("a", "b", "c"), addedAt = 1L)

        val rows = playlists.observeTracks("pl_1").first()
        assertThat(rows.map { it.id }).containsExactly("a", "b", "c").inOrder()

        // moveTrack mirrors the desktop drag & drop: b (index 1) to index 2.
        playlists.moveTrack("pl_1", 1, 2)
        assertThat(playlists.observeTracks("pl_1").first().map { it.id })
            .containsExactly("a", "c", "b").inOrder()

        playlists.removeTrack("pl_1", "a")
        assertThat(playlists.count("pl_1")).isEqualTo(2)
        Unit
    }

    @Test
    fun playlistCoverUrisUseTheFirstFourTracks() = runTest {
        val playlists = db.playlists()
        val tracks = db.tracks()
        (1..6).forEach { index ->
            tracks.upsert(
                track("t$index").toEntity(inLibrary = true).copy(artworkUri = "https://cover/$index.jpg"),
            )
        }
        playlists.upsertPlaylist(PlaylistEntity("pl_1", "Mix", 1L, 1L))
        playlists.addTracks("pl_1", (1..6).map { "t$it" }, addedAt = 1L)

        val covers = playlists.coverUris("pl_1", limit = 4)
        assertThat(covers).hasSize(4)
        assertThat(covers.first()).isEqualTo("https://cover/1.jpg")
        Unit
    }

    @Test
    fun playbackStateAndQueueRoundTrip() = runTest {
        val playback = db.playback()
        val tracks = db.tracks()
        listOf("a", "b").forEach { tracks.upsert(track(it).toEntity(inLibrary = true)) }

        playback.upsert(
            PlaybackStateEntity(
                id = 1,
                currentTrackId = "b",
                positionMs = 42_000,
                queueIndex = 1,
                isPlaying = true,
                repeatMode = "ALL",
                shuffle = true,
                updatedAt = 5L,
            ),
        )
        playback.saveQueue(
            listOf(
                com.riff.android.data.local.QueueItemEntity(0, "a", "", false),
                com.riff.android.data.local.QueueItemEntity(1, "b", "", true),
            ),
        )

        val state = playback.observe().first()
        assertThat(state?.currentTrackId).isEqualTo("b")
        assertThat(state?.positionMs).isEqualTo(42_000)
        assertThat(playback.queue().map { it.trackId }).containsExactly("a", "b").inOrder()

        playback.clearQueue()
        assertThat(playback.queue()).isEmpty()
        Unit
    }

    @Test
    fun seenRecommendationsAreTrimmedToTheWindow() = runTest {
        val seen = db.recommendations()
        repeat(130) { index ->
            seen.upsert(
                com.riff.android.data.local.SeenRecommendationEntity(
                    value = "id$index",
                    kind = "id",
                    seenAt = index.toLong(),
                ),
            )
        }
        seen.trim("id", 100)

        val values = seen.values("id", 100)
        assertThat(values).hasSize(100)
        assertThat(values.first()).isEqualTo("id129")
        assertThat(seen.observeCount().first()).isEqualTo(100)
        Unit
    }

    @Test
    fun lyricsPreferCustomRowsAndCanBeDeleted() = runTest {
        val lyrics = db.lyrics()
        lyrics.upsert(
            com.riff.android.data.local.LyricsEntity(
                trackKey = "artist___song",
                content = "[00:01.00]fetched",
                synced = true,
                custom = false,
                source = "LRCLIB",
                updatedAt = 1L,
            ),
        )
        lyrics.upsert(
            com.riff.android.data.local.LyricsEntity(
                trackKey = "artist___song",
                content = "[00:02.00]mine",
                synced = true,
                custom = true,
                source = "CUSTOM",
                updatedAt = 2L,
            ),
        )

        val stored = lyrics.get("artist___song")
        assertThat(stored?.custom).isTrue()
        assertThat(stored?.content).isEqualTo("[00:02.00]mine")

        lyrics.deleteCustom("artist___song")
        assertThat(lyrics.get("artist___song")).isNull()
        Unit
    }

    @Test
    fun downloadsObserveActiveAndFinished() = runTest {
        val downloads = db.downloads()
        downloads.upsert(
            com.riff.android.data.local.DownloadEntity(
                trackId = "a",
                state = "RUNNING",
                progress = 0.5f,
                bytesDownloaded = 10,
                totalBytes = 20,
                format = "mp3",
                quality = "0",
                error = null,
                attempts = 0,
                requestedAt = 1L,
                completedAt = null,
                providerId = "on-device",
            ),
        )
        downloads.upsert(
            com.riff.android.data.local.DownloadEntity(
                trackId = "b",
                state = "COMPLETED",
                progress = 1f,
                bytesDownloaded = 20,
                totalBytes = 20,
                format = "mp3",
                quality = "0",
                error = null,
                attempts = 0,
                requestedAt = 1L,
                completedAt = 2L,
                providerId = "on-device",
            ),
        )

        assertThat(downloads.observeActive().first().map { it.trackId }).containsExactly("a")
        downloads.clearFinished()
        assertThat(downloads.observeAll().first().map { it.trackId }).containsExactly("a")
        Unit
    }

    @Test
    fun trackEntitySurvivesAReloadWithItsLocalFile() = runTest {
        val tracks = db.tracks()
        val stored = track("a").toEntity(inLibrary = true).copy(
            localUri = "file:///music/Artist - Song.opus",
            downloadedAt = 1_700_000_000_000,
            fileSizeBytes = 4_200,
        )
        tracks.upsert(stored)

        val reloaded = tracks.get("a")!!.toDomain()
        assertThat(reloaded.localUri).isEqualTo("file:///music/Artist - Song.opus")
        assertThat(reloaded.isDownloaded).isTrue()
        assertThat(reloaded.isLocal).isTrue()
        Unit
    }

    @Test
    fun searchQueryFiltersAcrossTitleArtistAndAlbum() = runTest {
        val tracks = db.tracks()
        tracks.upsert(
            TrackEntity(
                id = "a",
                title = "Midnight City",
                artist = "M83",
                album = "Hurry Up, We're Dreaming",
                durationMs = 240_000,
                artworkUri = null,
                source = "youtube",
                sourceId = "a",
                sourceUrl = "https://youtube.com/watch?v=a",
                searchQuery = null,
                localUri = null,
                downloadedAt = null,
                fileSizeBytes = 0,
                favorite = false,
                favoritedAt = null,
                lastPlayedAt = null,
                playCount = 0,
                addedAt = 0,
                normalizedKey = TrackText.normalizeKey("M83", "Midnight City"),
                inLibrary = true,
            ),
        )

        val found = tracks.search("m83", onlyLibrary = true)
        assertThat(found.map { it.id }).containsExactly("a")

        val foundByAlbum = tracks.search("dreaming", onlyLibrary = true)
        assertThat(foundByAlbum.map { it.id }).containsExactly("a")

        assertThat(tracks.search("nothing here", onlyLibrary = true)).isEmpty()
        Unit
    }
}
