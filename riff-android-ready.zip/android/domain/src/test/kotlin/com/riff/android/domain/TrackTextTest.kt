package com.riff.android.domain

import com.google.common.truth.Truth.assertThat
import com.riff.android.domain.model.HqEngine
import com.riff.android.domain.model.HqPresets
import com.riff.android.domain.model.HqSettings
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.text.SpamFilter
import com.riff.android.domain.text.TrackText
import org.junit.Test

private object BareKeys {
    fun normalized(track: Track) = TrackText.normalizeKey(track.artist, track.title)
}

/**
 * Track identity & text handling — the port of `getTrackNormalizedKey()`,
 * `normalizeArtistName()`, `sanitizeForLyrics()` and `sanitizeFileName()` from
 * app.js/server.js. Track identity drives favourites, history and recommendations,
 * so these rules are load bearing.
 */
class TrackTextTest {

    @Test
    fun `normalizeKey strips the usual youtube decorations`() {
        val variants = listOf(
            "Song (Official Video)",
            "Song [Official Audio]",
            "Song (Official Music Video)",
            "Song (Remastered)",
            "Song (Lyric Video)",
            "Song (feat. Someone)",
            "Song",
        )
        val keys = variants.map { TrackText.normalizeKey("Artist", it) }.toSet()

        assertThat(keys).containsExactly("artist::song")
    }

    @Test
    fun `normalizeKey lowercases and collapses punctuation`() {
        assertThat(TrackText.normalizeKey("The Artist!", "Some—Song?"))
            .isEqualTo(TrackText.normalizeKey("the artist", "some song"))
    }

    @Test
    fun `normalizeArtistName strips channel suffixes`() {
        // server.js: strip (official|vevo|records|topic), drop punctuation, collapse
        // whitespace, lowercase. "Artist - Topic" therefore becomes "artist -" — the
        // dash stays, which is exactly what the desktop produced.
        assertThat(TrackText.normalizeArtistName("Artist - Topic")).isEqualTo("artist -")
        assertThat(TrackText.normalizeArtistName("Artist VEVO")).isEqualTo("artist")
        assertThat(TrackText.normalizeArtistName("Artist Official")).isEqualTo("artist")
        assertThat(TrackText.normalizeArtistName("Artist Records!")).isEqualTo("artist")
    }

    @Test
    fun `canonicalId prefers the platform id`() {
        val fromId = TrackText.canonicalId(
            source = TrackSource.YOUTUBE,
            id = "dQw4w9WgXcQ",
            url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            title = "Song",
            artist = "Artist",
            durationSeconds = 200,
        )
        assertThat(fromId).isEqualTo("youtube:dQw4w9WgXcQ")
    }

    @Test
    fun `canonicalId falls back to the url and then to the normalized key`() {
        val fromUrl = TrackText.canonicalId(
            source = TrackSource.SOUNDCLOUD,
            id = null,
            url = "https://soundcloud.com/artist/song",
            title = "Song",
            artist = "Artist",
            durationSeconds = 200,
        )
        assertThat(fromUrl).startsWith("soundcloud:")

        val fromTitle = TrackText.canonicalId(
            source = TrackSource.SOUNDCLOUD,
            id = null,
            url = null,
            title = "Song",
            artist = "Artist",
            durationSeconds = 200,
        )
        assertThat(fromTitle).startsWith("soundcloud:")
        assertThat(fromTitle).contains("song")
    }

    @Test
    fun `isSame follows the desktop canonical id rule`() {
        // app.js isSameTrack(): canonical ids compare equal even when the metadata
        // differs (title decorations, different spelled artist).
        val a = Track(
            id = "youtube:abc",
            title = "Song",
            artist = "Artist",
            source = TrackSource.YOUTUBE,
            sourceId = "abc",
            sourceUrl = "https://youtube.com/watch?v=abc",
        )
        val decorated = a.copy(id = "youtube:abc", title = "Song (Official Video)")
        val otherPlatform = a.copy(id = "youtube:def", sourceId = "def", sourceUrl = "https://youtube.com/watch?v=def")

        assertThat(TrackText.isSame(a, decorated)).isTrue()
        assertThat(TrackText.isSame(a, otherPlatform)).isFalse()
        assertThat(TrackText.isSame(a, null)).isFalse()

        // Same title/artist, no platform id at all: the fallback key is used.
        val bare = Track(id = "local:1", title = "Song", artist = "Artist", source = TrackSource.LOCAL)
        val bareAgain = Track(id = "local:2", title = "song", artist = "artist", source = TrackSource.LOCAL)
        assertThat(TrackText.isSame(bare, bareAgain)).isTrue()
        assertThat(BareKeys.normalized(bare)).isEqualTo(BareKeys.normalized(bareAgain))
    }

    @Test
    fun `sanitizeFilename keeps the desktop artist-title shape and drops illegal characters`() {
        val name = TrackText.sanitizeFilename("Artist: the\"best\" / Song?")
        assertThat(name).doesNotContain(":")
        assertThat(name).doesNotContain("\"")
        assertThat(name).doesNotContain("/")
        assertThat(name).doesNotContain("?")
        assertThat(name).contains("Artist")
    }

    @Test
    fun `sanitizeForLyrics strips video suffixes but keeps Cyrillic`() {
        val (title, artist) = TrackText.sanitizeForLyrics(
            "Песня (Official Audio)",
            "Исполнитель - Topic",
        )
        assertThat(title).isEqualTo("Песня")
        assertThat(artist).isEqualTo("Исполнитель")
    }

    @Test
    fun `lyrics key matches the desktop cache filename convention`() {
        // getFetchedLyricsPath(): non [a-zA-Z0-9_-] -> '_', lowercased, "___" separator.
        assertThat(TrackText.lyricsKey("Artist", "Song")).isEqualTo("artist___song")
        assertThat(TrackText.lyricsKey("Artist Name", "Song Title"))
            .isEqualTo("artist_name___song_title")
        assertThat(TrackText.lyricsKey("AC/DC", "Back in Black")).isEqualTo("ac_dc___back_in_black")
        // Cyrillic is outside [a-zA-Z0-9_-] in the desktop regex, so it degrades to
        // underscores: the key is still stable/unique, just not readable.
        val cyrillic = TrackText.lyricsKey("Исполнитель", "Песня")
        assertThat(cyrillic).contains("___")
        assertThat(cyrillic.all { it == '_' }).isTrue()
    }

    @Test
    fun `spam filter follows the desktop rules`() {
        assertThat(SpamFilter.isSpamOrUnofficial("Real song", 210, "Artist")).isFalse()
        assertThat(SpamFilter.isSpamOrUnofficial("Real song", 45, "Artist")).isTrue()
        assertThat(SpamFilter.isSpamOrUnofficial("Real song", 500, "Artist")).isTrue()
        assertThat(SpamFilter.isSpamOrUnofficial("Song (10 hours)", 600, "Artist")).isTrue()
        assertThat(SpamFilter.isSpamOrUnofficial("Song", 210, "Artist - Topic")).isFalse()
        assertThat(SpamFilter.isSpamOrUnofficial("THE MAKING OF SONG", 210, "Artist")).isTrue()
        assertThat(SpamFilter.isSpamOrUnofficial("Song type beat", 210, "Artist")).isTrue()
    }

    @Test
    fun `formatDuration prints the desktop mm ss layout`() {
        assertThat(TrackText.formatDuration(0)).isEqualTo("0:00")
        assertThat(TrackText.formatDuration(65)).isEqualTo("1:05")
        assertThat(TrackText.formatDuration(3_725)).isEqualTo("1:02:05")
    }

    @Test
    fun `urlEncode leaves already safe ids alone`() {
        assertThat(TrackText.urlEncode("dQw4w9WgXcQ")).isEqualTo("dQw4w9WgXcQ")
        assertThat(TrackText.urlEncode("a/b c")).doesNotContain("/")
    }
}

/**
 * HQ preset chips (`#hq-preset-*` in index.html, handled in app.js).
 */
class HqPresetTest {

    @Test
    fun `preset chips set the desktop knob values`() {
        val studio = HqPresets.apply(HqSettings(), "studio")
        assertThat(studio.vocal).isEqualTo(0)
        assertThat(studio.air).isEqualTo(0)
        assertThat(studio.bass).isEqualTo(0)

        val vinyl = HqPresets.apply(HqSettings(), "vinyl")
        assertThat(vinyl.vocal).isEqualTo(15)
        assertThat(vinyl.air).isEqualTo(-15)
        assertThat(vinyl.bass).isEqualTo(25)

        val concert = HqPresets.apply(HqSettings(), "concert")
        assertThat(concert.vocal).isEqualTo(-10)
        assertThat(concert.air).isEqualTo(30)
        assertThat(concert.bass).isEqualTo(15)
    }

    @Test
    fun `applying a preset keeps the selected engine`() {
        val selected = HqSettings(engine = HqEngine.FYRO_1_1)
        val applied = HqPresets.apply(selected, "vinyl")

        assertThat(applied.engine).isEqualTo(HqEngine.FYRO_1_1)
        assertThat(applied.preset).isEqualTo("vinyl")
    }

    @Test
    fun `an unknown preset id falls back to studio`() {
        assertThat(HqPresets.find("something-else")).isEqualTo(HqPresets.STUDIO)
    }
}
