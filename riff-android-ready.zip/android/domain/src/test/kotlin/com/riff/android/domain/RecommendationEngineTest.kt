package com.riff.android.domain

import com.google.common.truth.Truth.assertThat
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.recommend.RecommendationEngine
import com.riff.android.domain.recommend.TasteProfile
import com.riff.android.domain.text.SpamFilter
import kotlinx.coroutines.test.runTest
import org.junit.Test
import kotlin.random.Random

/**
 * Recommendation scoring.
 *
 * These tests cover the algorithm ported from `computeTasteProfile()` (app.js) and
 * `scoreDiscoveryCandidate()` / `recommendVibeTracks()` (server.js): the warm-up rule,
 * the recent-recommendation window, the spam filter, the "max 2 tracks per artist"
 * post filter and the duration/script preferences.
 */
class RecommendationEngineTest {

    private val engine = RecommendationEngine(Random(42))

    private fun track(
        id: String,
        title: String,
        artist: String,
        duration: Int = 210,
        source: TrackSource = TrackSource.SOUNDCLOUD,
    ) = Track(
        id = id,
        title = title,
        artist = artist,
        durationMs = duration * 1000L,
        source = source,
        sourceUrl = "https://soundcloud.com/$artist/$id",
    )

    private fun profile(topArtists: List<String>, script: String = "Latin", duration: Int = 210, count: Int = 10) =
        TasteProfile(topArtists = topArtists, dominantScript = script, typicalDuration = duration, trackCount = count)

    @Test
    fun `profile uses the five most listened artists`() {
        val history = listOf(
            track("1", "a", "Artist A"),
            track("2", "b", "Artist A"),
            track("3", "c", "Artist B"),
            track("4", "d", "Artist C"),
            track("5", "e", "Artist D"),
            track("6", "f", "Artist E"),
            track("7", "g", "Artist F"),
        )
        val profile = engine.buildProfile(history = history, favorites = emptyList())

        assertThat(profile.topArtists).hasSize(RecommendationEngine.MAX_TOP_ARTISTS)
        assertThat(profile.topArtists.first()).isEqualTo("artist a")
        assertThat(profile.typicalDuration).isEqualTo(210)
        assertThat(profile.trackCount).isEqualTo(7)
    }

    @Test
    fun `profile switches to Cyrillic when more than a third of the tracks are Cyrillic`() {
        val history = listOf(
            track("1", "Песня один", "Исполнитель"),
            track("2", "Песня два", "Исполнитель"),
            track("3", "Песня три", "Исполнитель"),
            track("4", "Latin song", "Artist"),
        )
        val profile = engine.buildProfile(history = history, favorites = emptyList())

        assertThat(profile.dominantScript).isEqualTo("Cyrillic")
    }

    @Test
    fun `discovery queries use the top artists and add a Cyrillic hint`() {
        val latin = engine.buildDiscoveryQueries(profile(listOf("artist a", "artist b")))
        assertThat(latin).containsExactly("artist a", "artist b")

        val cyrillic = engine.buildDiscoveryQueries(profile(listOf("исполнитель"), script = "Cyrillic"))
        assertThat(cyrillic).contains("исполнитель похожие песни")
    }

    @Test
    fun `discovery queries fall back to the desktop defaults with no taste seed`() {
        val queries = engine.buildDiscoveryQueries(profile(emptyList(), count = 0))
        assertThat(queries).containsExactly("synthwave chill", "indie electronic")
    }

    @Test
    fun `scoreCandidate rejects spam and lectures`() {
        val p = profile(listOf("artist a"))
        assertThat(engine.scoreCandidate(track("1", "Some song", "Artist", duration = 30), p, emptySet(), emptySet())).isNull()
        assertThat(
            engine.scoreCandidate(track("2", "Full album", "Artist", duration = 4000), p, emptySet(), emptySet()),
        ).isNull()
        assertThat(
            engine.scoreCandidate(track("3", "Artist interview 2024", "Artist"), p, emptySet(), emptySet()),
        ).isNull()
        assertThat(SpamFilter.isSpamOrUnofficial("1 hour loop", 3600, "Artist")).isTrue()
    }

    @Test
    fun `scoreCandidate rejects already heard tracks by id and by normalized key`() {
        val p = profile(listOf("artist a"))
        val heard = track("1", "Song", "Artist A")

        assertThat(engine.scoreCandidate(heard, p, heardKeys = emptySet(), heardIds = setOf("1"))).isNull()
        assertThat(
            engine.scoreCandidate(
                track("2", "Song (Official Video)", "Artist A"),
                p,
                heardKeys = setOf(heard.normalizedKey),
                heardIds = emptySet(),
            ),
        ).isNull()
    }

    @Test
    fun `scoreCandidate rejects recently recommended tracks`() {
        val p = profile(listOf("artist a"))
        val candidate = track("9", "Song", "Artist A")

        assertThat(
            engine.scoreCandidate(
                candidate,
                p,
                heardKeys = emptySet(),
                heardIds = emptySet(),
                recentlyRecommendedIds = setOf("9"),
            ),
        ).isNull()
        assertThat(
            engine.scoreCandidate(
                track("10", "Other song", "Artist A"),
                p,
                heardKeys = emptySet(),
                heardIds = emptySet(),
                recentlyRecommendedKeys = setOf(track("10", "Other song", "Artist A").normalizedKey),
            ),
        ).isNull()
    }

    @Test
    fun `known artist and matching script score higher than an unrelated track`() {
        val p = profile(listOf("artist a"), script = "Latin", duration = 210)
        val known = engine.scoreCandidate(
            track("1", "artist a - Song", "Artist A"),
            p,
            emptySet(),
            emptySet(),
        )
        val unrelated = engine.scoreCandidate(
            track("2", "Random title", "Nobody", duration = 400),
            p,
            emptySet(),
            emptySet(),
        )

        assertThat(known).isNotNull()
        assertThat(unrelated).isNotNull()
        assertThat(known!!.score).isGreaterThan(unrelated!!.score)
    }

    @Test
    fun `recommend returns nothing before the warm-up rule is met`() = runTest {
        val library = listOf(track("1", "a", "Artist"), track("2", "b", "Artist"))
        val result = engine.recommend(
            history = library,
            favorites = emptyList(),
            limit = 10,
            recentlyRecommendedIds = emptySet(),
            recentlyRecommendedKeys = emptySet(),
            search = { _, _ -> error("search must not be called") },
        )

        assertThat(result.tracks).isEmpty()
        assertThat(result.profile.trackCount).isLessThan(RecommendationEngine.MIN_SEED_TRACKS)
    }

    @Test
    fun `recommend filters spam, caps two tracks per artist and respects the limit`() = runTest {
        val seedHistory = (1..6).map { track("seed$it", "seed song $it", "Artist $it") }
        val candidates = buildList {
            add(track("c1", "Artist A - Great song", "Artist A - Topic"))
            add(track("c2", "Artist A - Another song", "Artist A - Topic"))
            add(track("c3", "Artist A - Third song", "Artist A - Topic"))
            add(track("c4", "Artist B - song", "Artist B"))
            add(track("c5", "Artist C - song", "Artist C"))
            add(track("c6", "Artist D - song", "Artist D"))
            add(track("c7", "Artist E - song", "Artist E"))
            add(track("c8", "Artist F - lecture", "Artist F", duration = 40))
        }

        val result = engine.recommend(
            history = seedHistory,
            favorites = emptyList(),
            limit = 4,
            recentlyRecommendedIds = emptySet(),
            recentlyRecommendedKeys = emptySet(),
            search = { _, _ -> candidates },
        )

        assertThat(result.tracks).hasSize(4)
        assertThat(result.tracks.count { it.artist.startsWith("Artist A") }).isAtMost(2)
        assertThat(result.tracks.map { it.id }).doesNotContain("c8")
        assertThat(result.profile.trackCount).isAtLeast(RecommendationEngine.MIN_SEED_TRACKS)
    }

    @Test
    fun `recommend never returns a track that is already in the library`() = runTest {
        val seed = (1..6).map { track("seed$it", "seed song $it", "Artist $it") }
        val alreadyOwned = track("owned", "Artist A - Song I have", "Artist A")

        val result = engine.recommend(
            history = seed,
            favorites = listOf(alreadyOwned),
            limit = 10,
            recentlyRecommendedIds = emptySet(),
            recentlyRecommendedKeys = emptySet(),
            search = { _, _ -> listOf(alreadyOwned, track("fresh", "Artist A - New song", "Artist A")) },
        )

        assertThat(result.tracks.map { it.id }).doesNotContain("owned")
        assertThat(result.tracks.map { it.id }).contains("fresh")
    }

    @Test
    fun `recommend tolerates a failing search`() = runTest {
        val seed = (1..6).map { track("seed$it", "seed song $it", "Artist $it") }
        val result = engine.recommend(
            history = seed,
            favorites = emptyList(),
            limit = 5,
            recentlyRecommendedIds = emptySet(),
            recentlyRecommendedKeys = emptySet(),
            search = { _, _ -> throw IllegalStateException("network down") },
        )

        assertThat(result.tracks).isEmpty()
        assertThat(result.profile.trackCount).isAtLeast(RecommendationEngine.MIN_SEED_TRACKS)
    }
}
