package com.riff.android.domain

import com.google.common.truth.Truth.assertThat
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.domain.queue.PrevDecision
import com.riff.android.domain.queue.QueuePlanner
import com.riff.android.domain.text.TrackText
import org.junit.Test
import kotlin.random.Random

/**
 * Queue behaviour — the rules taken from `playTrack()` / `playNext()` / `playPrev()` /
 * `pushHistory()` in app.js. These tests pin the *behaviour*, not the implementation:
 * if someone changes the seeding rules the test explains what the desktop did.
 */
class QueuePlannerTest {

    private fun track(id: String, title: String = "title $id", artist: String = "artist", duration: Int = 200) =
        Track(
            id = id,
            title = title,
            artist = artist,
            durationMs = duration * 1000L,
            source = TrackSource.YOUTUBE,
            sourceUrl = "https://youtube.com/watch?v=$id",
        )

    @Test
    fun `seedQueue uses the provided list and finds the start index`() {
        val a = track("a")
        val b = track("b")
        val seed = QueuePlanner.seedQueue(track = b, queueList = listOf(a, b), startIndex = 1)

        assertThat(seed.queue).containsExactly(a, b).inOrder()
        assertThat(seed.index).isEqualTo(1)
    }

    @Test
    fun `seedQueue falls back to indexOf when the start index does not match`() {
        val a = track("a")
        val b = track("b")
        val c = track("c")
        val seed = QueuePlanner.seedQueue(track = c, queueList = listOf(a, b, c), startIndex = 0)

        assertThat(seed.index).isEqualTo(2)
    }

    @Test
    fun `seedQueue prepends a track that is not in the list`() {
        val a = track("a")
        val missing = track("z")
        val seed = QueuePlanner.seedQueue(track = missing, queueList = listOf(a), startIndex = 0)

        assertThat(seed.queue.first().id).isEqualTo("z")
        assertThat(seed.index).isEqualTo(0)
    }

    @Test
    fun `seedQueue without a list appends to the existing queue`() {
        val a = track("a")
        val b = track("b")
        val seed = QueuePlanner.seedQueue(track = b, existingQueue = listOf(a), existingIndex = 0)

        assertThat(seed.queue.map { it.id }).containsExactly("a", "b").inOrder()
        assertThat(seed.index).isEqualTo(1)
    }

    @Test
    fun `nextIndex wraps around like the desktop player`() {
        assertThat(QueuePlanner.nextIndex(currentIndex = 2, size = 3)).isEqualTo(0)
        assertThat(QueuePlanner.nextIndex(currentIndex = 0, size = 3)).isEqualTo(1)
    }

    @Test
    fun `nextIndex with repeat one restarts the same track`() {
        assertThat(QueuePlanner.nextIndex(currentIndex = 1, size = 4, repeatOne = true)).isEqualTo(1)
    }

    @Test
    fun `nextIndex with shuffle stays inside the queue`() {
        val random = Random(7)
        repeat(50) {
            val index = QueuePlanner.nextIndex(currentIndex = 1, size = 5, shuffle = true, random = random)
            assertThat(index).isAtLeast(0)
            assertThat(index).isLessThan(5)
        }
    }

    @Test
    fun `prevDecision restarts the track after three seconds`() {
        val decision = QueuePlanner.prevDecision(currentIndex = 1, size = 4, positionMs = 3_500)
        assertThat(decision).isEqualTo(PrevDecision.RestartCurrent)
    }

    @Test
    fun `prevDecision goes back before three seconds`() {
        val decision = QueuePlanner.prevDecision(currentIndex = 1, size = 4, positionMs = 1_000)
        assertThat(decision).isEqualTo(PrevDecision.Play(0))
    }

    @Test
    fun `prevDecision wraps to the end of the queue`() {
        val decision = QueuePlanner.prevDecision(currentIndex = 0, size = 4, positionMs = 500)
        assertThat(decision).isEqualTo(PrevDecision.Play(3))
    }

    @Test
    fun `wave is extended when the queue index reaches the last three items`() {
        assertThat(QueuePlanner.shouldExtendWave(queueIndex = 7, size = 10, waveActive = true)).isTrue()
        assertThat(QueuePlanner.shouldExtendWave(queueIndex = 6, size = 10, waveActive = true)).isFalse()
        assertThat(QueuePlanner.shouldExtendWave(queueIndex = 9, size = 10, waveActive = false)).isFalse()
    }

    @Test
    fun `wave exhaustion is reported at the end of the queue`() {
        assertThat(QueuePlanner.isWaveExhausted(queueIndex = 9, size = 10, waveActive = true)).isTrue()
        assertThat(QueuePlanner.isWaveExhausted(queueIndex = 8, size = 10, waveActive = true)).isFalse()
    }

    @Test
    fun `pushHistory dedupes, moves to the front and caps at the desktop limit`() {
        val existing = (1..100).map { track("t$it") }
        val played = existing[42]
        val history = QueuePlanner.pushHistory(existing, played)

        assertThat(history).hasSize(100)
        assertThat(history.first().id).isEqualTo(played.id)
        assertThat(history.count { it.id == played.id }).isEqualTo(1)
    }

    @Test
    fun `mergeQueue drops duplicates by id and by normalized key`() {
        val existing = listOf(track("a", title = "Song", artist = "Artist"))
        val sameSongDifferentId = track("b", title = "Song (Official Video)", artist = "Artist")
        val fresh = track("c", title = "Another", artist = "Artist")

        val merged = QueuePlanner.mergeQueue(existing, listOf(sameSongDifferentId, fresh))

        assertThat(merged.map { it.title }).containsExactly("Song", "Another").inOrder()
    }

    @Test
    fun `repeat mode mapping matches the desktop flags`() {
        assertThat(QueuePlanner.repeatModeFor(repeatOne = true, loopQueue = false).name).isEqualTo("ONE")
        assertThat(QueuePlanner.repeatModeFor(repeatOne = false, loopQueue = true).name).isEqualTo("ALL")
        assertThat(QueuePlanner.repeatModeFor(repeatOne = false, loopQueue = false).name).isEqualTo("OFF")
    }

    @Test
    fun `canonical ids are stable for the same platform id`() {
        val first = track("dQw4w9WgXcQ")
        val second = track("dQw4w9WgXcQ", title = "different title")
        assertThat(TrackText.canonicalId(first)).isEqualTo(TrackText.canonicalId(second))
    }
}
