package com.riff.android.domain

import com.google.common.truth.Truth.assertThat
import com.riff.android.domain.lyrics.LrcParser
import com.riff.android.domain.model.LyricsSource
import org.junit.Test

/**
 * Lyrics parsing — the port of `parseSyncedLyrics()` / `loadSyncedLyrics()` in app.js,
 * including the plain-text fallback (untimed lines are shown but never highlighted)
 * and the custom-lyrics precedence.
 */
class LyricsTest {

    private val lrc = """
        [ar:Artist]
        [ti:Song]
        [00:00.00]first line
        [00:12.34]second line
        [00:24.00]
        [01:02.50]third line
    """.trimIndent()

    @Test
    fun `synced lyrics are parsed into timed lines`() {
        val lyrics = LrcParser.parse(lrc, "artist___song", LyricsSource.LRCLIB)

        assertThat(lyrics.synced).isTrue()
        assertThat(lyrics.lines).hasSize(4)
        assertThat(lyrics.lines[0].timeMs).isEqualTo(0)
        assertThat(lyrics.lines[0].text).isEqualTo("first line")
        assertThat(lyrics.lines[1].timeMs).isEqualTo(12_340)
        assertThat(lyrics.lines[2].timeMs).isEqualTo(24_000)
        assertThat(lyrics.lines[2].text).isEmpty()
        assertThat(lyrics.lines[3].timeMs).isEqualTo(62_500)
    }

    @Test
    fun `plain text lyrics are kept but not synced`() {
        val plain = "just a line\nand another"
        val lyrics = LrcParser.parse(plain, "artist___song", LyricsSource.LRCLIB)

        assertThat(lyrics.synced).isFalse()
        assertThat(lyrics.lines).hasSize(2)
        assertThat(lyrics.lines.first().isTimed).isFalse()
    }

    @Test
    fun `timestamps are sorted and never negative`() {
        val shuffled = "[00:30.00]later\n[00:10.00]earlier"
        val lyrics = LrcParser.parse(shuffled, "k", LyricsSource.LRCLIB)

        assertThat(lyrics.lines.map { it.timeMs }).containsExactly(10_000L, 30_000L).inOrder()
    }

    @Test
    fun `empty input produces empty lyrics`() {
        val lyrics = LrcParser.parse("", "k", LyricsSource.NONE)
        assertThat(lyrics.isEmpty).isTrue()
        assertThat(lyrics.hasSyncTimes()).isFalse()
    }

    @Test
    fun `custom lyrics keep their source so a provider result can never overwrite them`() {
        val lyrics = LrcParser.parse("[00:01.00]mine", "k", LyricsSource.CUSTOM)
        assertThat(lyrics.isCustom).isTrue()
        assertThat(lyrics.source).isEqualTo(LyricsSource.CUSTOM)
    }

    private fun com.riff.android.domain.model.Lyrics.hasSyncTimes() = LrcParser.hasSyncTimes(this)
}
