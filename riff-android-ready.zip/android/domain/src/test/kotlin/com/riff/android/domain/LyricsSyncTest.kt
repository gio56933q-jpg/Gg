package com.riff.android.domain

import com.google.common.truth.Truth.assertThat
import com.riff.android.domain.lyrics.LrcParser
import com.riff.android.domain.lyrics.LyricsSync
import com.riff.android.domain.model.LyricLine
import com.riff.android.domain.model.LyricsSource
import org.junit.Test

/**
 * Lyrics highlighting + timestamp shifting (`updateSyncedLyrics()` and the sync editor
 * in app.js). These are the rules that decide which line lights up while a track plays,
 * so they are pinned independently of Compose.
 */
class LyricsSyncTest {

    private val lines = listOf(
        LyricLine(timeMs = 0, text = "first"),
        LyricLine(timeMs = 12_340, text = "second"),
        LyricLine(timeMs = 24_000, text = "third"),
        LyricLine(timeMs = 62_500, text = "fourth"),
    )

    @Test
    fun `the active line is the last timestamp at or before the position`() {
        assertThat(LyricsSync.activeLineIndex(lines, 0)).isEqualTo(0)
        assertThat(LyricsSync.activeLineIndex(lines, 12_340)).isEqualTo(1)
        assertThat(LyricsSync.activeLineIndex(lines, 20_000)).isEqualTo(1)
        assertThat(LyricsSync.activeLineIndex(lines, 62_500)).isEqualTo(3)
        assertThat(LyricsSync.activeLineIndex(lines, 600_000)).isEqualTo(3)
    }

    @Test
    fun `the highlight leads the timestamp slightly`() {
        // 100 ms before the stamp still highlights the upcoming line (LEAD_MS = 120).
        assertThat(LyricsSync.activeLineIndex(lines, 12_300)).isEqualTo(1)
        // Well before it, the previous line stays highlighted.
        assertThat(LyricsSync.activeLineIndex(lines, 12_000)).isEqualTo(0)
    }

    @Test
    fun `plain lyrics have no active line`() {
        val plain = listOf(LyricLine(timeMs = -1, text = "a"), LyricLine(timeMs = -1, text = "b"))
        assertThat(LyricsSync.activeLineIndex(plain, 10_000)).isEqualTo(-1)
        assertThat(LyricsSync.activeLineIndex(emptyList(), 0)).isEqualTo(-1)
    }

    @Test
    fun `shift moves every timestamp by the desktop lead`() {
        val shifted = LyricsSync.shiftTimestamps("[00:00.00]first\n[00:12.34]second", 4.0)

        assertThat(shifted).contains("[00:04.00]first")
        assertThat(shifted).contains("[00:16.34]second")
    }

    @Test
    fun `negative shifts clamp at zero and support negative offsets`() {
        val shifted = LyricsSync.shiftTimestamps("[00:02.00]early", seconds = -5.0)
        assertThat(shifted).contains("[00:00.00]early")

        val back = LyricsSync.shiftTimestamps("[00:20.00]later", seconds = -3.5)
        assertThat(back).contains("[00:16.50]later")
    }

    @Test
    fun `metadata tags are not treated as timestamps`() {
        val shifted = LyricsSync.shiftTimestamps("[ar:Artist]\n[00:10.00]line", 4.0)
        assertThat(shifted).contains("[ar:Artist]")
        assertThat(shifted).contains("[00:14.00]line")
    }

    @Test
    fun `two and three digit fractions are handled`() {
        assertThat(LyricsSync.shiftTimestamps("[00:01.5]x", 0.0)).contains("[00:01.50]x")
        assertThat(LyricsSync.shiftTimestamps("[00:01.250]x", 0.0)).contains("[00:01.25]x")
    }

    @Test
    fun `shifted lyrics still parse as synced`() {
        val lyrics = LrcParser.parse("[00:00.00]one\n[00:30.00]two", "k", LyricsSource.CUSTOM)
        val shifted = LrcParser.parse(LyricsSync.shiftTimestamps(lyrics.raw, 4.0), "k", LyricsSource.CUSTOM)

        assertThat(shifted.synced).isTrue()
        assertThat(shifted.lines.map { it.timeMs }).containsExactly(4_000L, 34_000L).inOrder()
    }

    @Test
    fun `scrolling target stays inside the list`() {
        // The UI scrolls to activeIndex - 2 (centering); the helper below is what keeps
        // the first lines from producing a negative index.
        fun scrollTarget(active: Int) = (active - 2).coerceAtLeast(0)
        assertThat(scrollTarget(0)).isEqualTo(0)
        assertThat(scrollTarget(1)).isEqualTo(0)
        assertThat(scrollTarget(7)).isEqualTo(5)
    }
}
