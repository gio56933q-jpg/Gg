package com.riff.android.domain.recommend

import com.riff.android.domain.model.Track

/**
 * Desktop `computeTasteProfile()` result (`{trackCount, topArtists, dominantScript, avgDuration}`).
 */
data class TasteProfile(
    val trackCount: Int = 0,
    val topArtists: List<String> = emptyList(),
    /** "Cyrillic" or "Latin" (desktop compares the ratio against 35%). */
    val dominantScript: String = "Latin",
    val typicalDuration: Int = 210,
)

data class ScoredTrack(
    val track: Track,
    val score: Double,
)

data class RecommendationResult(
    val profile: TasteProfile,
    val tracks: List<Track>,
    /** Ids/keys the caller should remember as "recently recommended" (window of 100). */
    val addedSeenIds: Set<String> = emptySet(),
    val addedSeenKeys: Set<String> = emptySet(),
)
