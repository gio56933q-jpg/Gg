package com.riff.android.domain.recommend

import com.riff.android.domain.model.Track
import com.riff.android.domain.text.SpamFilter
import com.riff.android.domain.text.TrackText
import kotlin.random.Random

/**
 * Port of the desktop "My Wave" recommendation pipeline.
 *
 * Desktop sources:
 *  - `computeTasteProfile()`       (app.js)  -> [TasteProfile]
 *  - `buildDiscoveryQueries()`     (server.js) -> [buildDiscoveryQueries]
 *  - `scoreDiscoveryCandidate()`   (server.js) -> [scoreCandidate]
 *  - `recommendVibeTracks()`       (server.js) -> [recommend]
 *
 * The algorithm is intentionally *not* rewritten: the same weights, the same
 * random jitter (1.5), the same 5-track/5-track warm-up rule, the same
 * "max 2 tracks per artist" post filter and the same recently-recommended
 * exclusion window (100 ids / 100 keys) are preserved.
 *
 * The only change is dependency injection: [random] and the caller-supplied
 * previously-seen keys make the engine deterministic and unit-testable.
 */
class RecommendationEngine(private val random: Random = Random.Default) {

    companion object {
        const val MIN_SEED_TRACKS = 5
        const val MAX_TOP_ARTISTS = 5
        const val CYRILLIC_RATIO = 0.35
        const val FALLBACK_DURATION = 210
        const val SEEN_WINDOW = 100
        const val MAX_PER_ARTIST = 2
    }

    /** Desktop `computeTasteProfile()` (client side). */
    fun buildProfile(
        history: List<Track>,
        favorites: List<Track>,
        clientProfile: TasteProfile? = null,
    ): TasteProfile {
        val artistCounts = mutableMapOf<String, Int>()
        var cyrillicCount = 0
        val durations = mutableListOf<Int>()
        val total = (favorites + history).size

        (favorites + history).forEach { t ->
            if (t.artist.isNotBlank()) {
                val a = TrackText.normalizeArtistName(t.artist)
                artistCounts[a] = (artistCounts[a] ?: 0) + 1
            }
            if (TrackText.isCyrillic(t.title)) cyrillicCount++
            if (t.durationSeconds > 0) durations.add(t.durationSeconds)
        }

        val sortedArtists = artistCounts.entries.sortedByDescending { it.value }.map { it.key }

        return TasteProfile(
            topArtists = clientProfile?.topArtists ?: sortedArtists.take(MAX_TOP_ARTISTS),
            dominantScript = clientProfile?.dominantScript
                ?: if (cyrillicCount > total * CYRILLIC_RATIO) "Cyrillic" else "Latin",
            typicalDuration = clientProfile?.typicalDuration
                ?: durations.takeIf { it.isNotEmpty() }?.average()?.toInt() ?: FALLBACK_DURATION,
            trackCount = total,
        )
    }

    /** Desktop `buildDiscoveryQueries(profile)`. */
    fun buildDiscoveryQueries(profile: TasteProfile, random: Random = this.random): List<String> {
        val artists = profile.topArtists.filter { it.isNotBlank() }
        val shuffled = artists.shuffled(random)
        val queries = mutableListOf<String>()

        if (shuffled.isNotEmpty()) {
            queries.add(shuffled[0])
            if (shuffled.size > 1) queries.add(shuffled[1])
        }

        if (profile.dominantScript == "Cyrillic" && shuffled.isNotEmpty()) {
            queries.add("${shuffled[0]} похожие песни")
        }

        if (queries.isEmpty()) {
            queries.add("synthwave chill")
            queries.add("indie electronic")
        }

        return queries
    }

    /**
     * Desktop `scoreDiscoveryCandidate(track, profile, heardKeys, heardIds)`.
     * Returns null when the candidate must be dropped.
     */
    fun scoreCandidate(
        track: Track,
        profile: TasteProfile,
        heardKeys: Set<String>,
        heardIds: Set<String>,
        recentlyRecommendedIds: Set<String> = emptySet(),
        recentlyRecommendedKeys: Set<String> = emptySet(),
        random: Random = this.random,
    ): ScoredTrack? {
        if (track.id.isBlank() || track.sourceUrl.isNullOrBlank()) return null

        val key = track.normalizedKey
        if (heardIds.contains(track.id) || (key.isNotBlank() && heardKeys.contains(key))) return null
        if (recentlyRecommendedIds.contains(track.id) ||
            (key.isNotBlank() && recentlyRecommendedKeys.contains(key))
        ) {
            return null
        }
        if (SpamFilter.isSpamOrUnofficial(track.title, track.durationSeconds, track.artist)) return null

        var score = 1.0

        if (Regex("""-\s*topic$""", RegexOption.IGNORE_CASE).containsMatchIn(track.artist)) score += 1.5
        if (Regex("""^.+?\s+-\s+.+$""").containsMatchIn(track.title)) score += 1.0

        val candidateArtist = TrackText.normalizeArtistName(track.artist)
        val artistNames = profile.topArtists.map { it }
        if (artistNames.any { cand ->
                val a = TrackText.normalizeArtistName(cand)
                a.isNotBlank() && (candidateArtist.contains(a) || a.contains(candidateArtist))
            }
        ) {
            score += 3.0
        }

        val isCyrillic = TrackText.isCyrillic(track.title)
        if (profile.dominantScript == "Cyrillic" && isCyrillic) {
            score += 2.0
        } else if (profile.dominantScript != "Cyrillic" && !isCyrillic) {
            score += 1.0
        }

        if (track.durationSeconds > 0 && profile.typicalDuration > 0) {
            val delta = kotlin.math.abs(track.durationSeconds - profile.typicalDuration)
            score += maxOf(0.0, 2.0 - (delta / 60.0))
        }

        score += random.nextDouble() * 1.5

        return ScoredTrack(track = track, score = score)
    }

    /**
     * Desktop `recommendVibeTracks(...)`: scores the candidate pool produced by
     * [buildDiscoveryQueries] and returns the final, artist-diversified list.
     *
     * The caller performs the actual searching (via `MusicSearchProvider`) so the
     * engine stays pure; [search] is a suspended lambda returning candidates.
     */
    suspend fun recommend(
        history: List<Track>,
        favorites: List<Track>,
        limit: Int,
        recentlyRecommendedIds: Set<String>,
        recentlyRecommendedKeys: Set<String>,
        clientProfile: TasteProfile? = null,
        search: suspend (query: String, limit: Int) -> List<Track>,
    ): RecommendationResult {
        val profile = buildProfile(history, favorites, clientProfile)

        val heardIds = mutableSetOf<String>()
        val heardKeys = mutableSetOf<String>()
        (history + favorites).forEach { t ->
            heardIds.add(t.id)
            val key = t.normalizedKey
            if (key.isNotBlank()) heardKeys.add(key)
        }

        if (profile.trackCount < MIN_SEED_TRACKS &&
            (clientProfile == null || clientProfile.trackCount < MIN_SEED_TRACKS)
        ) {
            return RecommendationResult(profile = profile, tracks = emptyList())
        }

        val queries = buildDiscoveryQueries(profile)
        val candidateMap = LinkedHashMap<String, ScoredTrack>()

        for (query in queries) {
            val results = runCatching { search(query, 14) }.getOrDefault(emptyList())
            for (track in results) {
                val scored = scoreCandidate(
                    track = track,
                    profile = profile,
                    heardKeys = heardKeys,
                    heardIds = heardIds,
                    recentlyRecommendedIds = recentlyRecommendedIds,
                    recentlyRecommendedKeys = recentlyRecommendedKeys,
                ) ?: continue
                val existing = candidateMap[scored.track.id]
                if (existing == null || existing.score < scored.score) {
                    candidateMap[scored.track.id] = scored
                }
            }
            if (candidateMap.size >= limit * 2) break
        }

        var ranked = candidateMap.values.sortedByDescending { it.score }

        val unshown = ranked.filter { !recentlyRecommendedIds.contains(it.track.id) }
        if (unshown.size >= limit) ranked = unshown

        val artistTrackCount = mutableMapOf<String, Int>()
        val finalTracks = mutableListOf<ScoredTrack>()
        val newIds = mutableSetOf<String>()
        val newKeys = mutableSetOf<String>()

        for (scored in ranked) {
            val a = TrackText.normalizeArtistName(scored.track.artist)
            if ((artistTrackCount[a] ?: 0) < MAX_PER_ARTIST) {
                artistTrackCount[a] = (artistTrackCount[a] ?: 0) + 1
                finalTracks.add(scored)
                newIds.add(scored.track.id)
                val key = scored.track.normalizedKey
                if (key.isNotBlank()) newKeys.add(key)
                if (finalTracks.size >= limit) break
            }
        }

        return RecommendationResult(
            profile = profile,
            tracks = finalTracks.map { it.track },
            addedSeenIds = newIds,
            addedSeenKeys = newKeys,
        )
    }
}
