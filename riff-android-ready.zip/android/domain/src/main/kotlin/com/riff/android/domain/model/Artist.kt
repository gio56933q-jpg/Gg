package com.riff.android.domain.model

/** A local/aggregated artist entry (desktop derives these from library + history). */
data class Artist(
    val name: String,
    val trackCount: Int = 0,
    val albumCount: Int = 0,
    val artworkUri: String? = null,
)

/** A local/aggregated album entry. */
data class Album(
    val name: String,
    val artist: String,
    val trackCount: Int = 0,
    val artworkUri: String? = null,
    val year: Int? = null,
)

/**
 * Remote artist profile. Port of `fetchArtistInfo()` in `server.js`
 * (Deezer artist search + tracklist, Wikipedia summary fallback).
 */
data class ArtistProfile(
    val name: String,
    val bio: String,
    val avatarUri: String? = null,
    val verified: Boolean = false,
    val tracks: List<Track> = emptyList(),
    val followers: Long = 0L,
)
