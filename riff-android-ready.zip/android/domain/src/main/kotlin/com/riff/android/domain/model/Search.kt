package com.riff.android.domain.model

/** Port of the platform pill switch in the top bar (`#platform-yt` / `#platform-sc`). */
enum class SearchPlatform(val id: String, val label: String) {
    YOUTUBE("youtube", "YouTube"),
    SOUNDCLOUD("soundcloud", "SoundCloud");

    companion object {
        fun fromId(id: String?): SearchPlatform =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: YOUTUBE
    }
}

data class SearchResult(
    val tracks: List<Track>,
    val platform: SearchPlatform,
    val query: String,
    val fromCache: Boolean = false,
    val error: String? = null,
)
