package com.riff.android.domain.text

import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import java.net.URLEncoder
import java.util.Locale

/**
 * Faithful Kotlin port of the string helpers that drive de-duplication,
 * recommendations and lyrics lookup in the desktop app.
 *
 * Sources:
 *  - `getTrackNormalizedKey()`  (server.js + app.js)
 *  - `normalizeArtistName()`    (server.js)
 *  - `getTrackCanonicalId()`    (app.js)
 *  - `sanitizeForLyrics()`      (server.js)
 *  - `sanitizeFilename()`       (server.js)
 *  - `parseDurationSeconds()`   (server.js)
 */
object TrackText {

    private val OFFICIAL_PAREN = Regex("""\s*\([^)]*official[^)]*\)""", RegexOption.IGNORE_CASE)
    private val BRACKETS = Regex("""\s*\[[^\]]*]""")
    private val VIDEO_PAREN =
        Regex("""\s*\([^)]*(video|audio|remaster(ed)?|lyrics?|visualizer)[^)]*\)""", RegexOption.IGNORE_CASE)
    private val FEAT_INLINE = Regex("""\s*(feat\.?|ft\.?)\s+[^(\[-]+""", RegexOption.IGNORE_CASE)
    private val FEAT_PAREN = Regex("""\s*\((feat\.?|ft\.?)[^)]*\)""", RegexOption.IGNORE_CASE)
    private val FEAT_TAIL = Regex("""\s*(feat\.?|ft\.?)\s+.*$""", RegexOption.IGNORE_CASE)
    private val NON_ALNUM = Regex("""[^\p{L}\p{N}\s]""")
    private val WHITESPACE = Regex("""\s+""")
    private val CYRILLIC = Regex("""[\u0400-\u04FF]""")

    /** Desktop `getTrackNormalizedKey(artist, title)`. */
    fun normalizeKey(artist: String?, title: String?): String {
        var a = artist.orEmpty().lowercase(Locale.ROOT)
        var t = title.orEmpty().lowercase(Locale.ROOT)
        t = OFFICIAL_PAREN.replace(t, "")
        t = BRACKETS.replace(t, "")
        t = VIDEO_PAREN.replace(t, "")
        t = FEAT_INLINE.replace(t, "")
        t = FEAT_PAREN.replace(t, "")
        a = FEAT_TAIL.replace(a, "")
        a = NON_ALNUM.replace(a, " ")
        a = WHITESPACE.replace(a, " ").trim()
        t = NON_ALNUM.replace(t, " ")
        t = WHITESPACE.replace(t, " ").trim()
        return "$a::$t"
    }

    /** Desktop `normalizeArtistName(name)` — used for artist clustering. */
    fun normalizeArtistName(name: String?): String =
        WHITESPACE.replace(
            Regex("""\b(official|vevo|records|topic)\b""", RegexOption.IGNORE_CASE)
                .replace(name.orEmpty(), "")
                .replace(Regex("""[^\w\s&-]"""), " "),
            " ",
        ).trim().lowercase(Locale.ROOT)

    /** Desktop `getTrackCanonicalId(track)`. */
    fun canonicalId(
        source: TrackSource,
        id: String?,
        url: String?,
        title: String?,
        artist: String?,
        durationSeconds: Int,
    ): String {
        val platform = source.id
        if (!id.isNullOrBlank()) return "$platform:$id"
        if (!url.isNullOrBlank()) return "$platform:$url"
        val t = title.orEmpty().trim().lowercase(Locale.ROOT)
        val a = artist.orEmpty().trim().lowercase(Locale.ROOT)
        return "$platform:$t|$a|$durationSeconds"
    }

    fun canonicalId(track: Track): String =
        canonicalId(track.source, track.sourceId, track.sourceUrl, track.title, track.artist, track.durationSeconds)

    fun isSame(a: Track?, b: Track?): Boolean {
        if (a == null || b == null) return false
        return canonicalId(a) == canonicalId(b)
    }

    /** Desktop `parseDurationSeconds("3:24")`. */
    fun parseDurationSeconds(str: String?): Int {
        if (str.isNullOrBlank()) return 0
        val parts = str.split(":").mapNotNull { it.trim().toIntOrNull() }
        return when (parts.size) {
            2 -> parts[0] * 60 + parts[1]
            3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]
            else -> 0
        }
    }

    /** Desktop `sanitizeFilename(str)`. */
    fun sanitizeFilename(str: String?): String =
        WHITESPACE.replace(Regex("""[<>:"/\\|?*]""").replace(str.orEmpty(), ""), " ").trim()

    /** Desktop `sanitizeForLyrics(title, artist)`. */
    fun sanitizeForLyrics(title: String?, artist: String?): Pair<String, String> {
        var cleanTitle = Regex("""\[.*?]|\(.*?\)""").replace(title.orEmpty(), "")
        cleanTitle = Regex(
            """official\s*(music)?\s*video|official\s*audio|lyrics|hd|4k|remastered|visualizer|clip\s*officiel|video\s*clip""",
            RegexOption.IGNORE_CASE,
        ).replace(cleanTitle, "")
        cleanTitle = Regex("""ft\.?|feat\.?""", RegexOption.IGNORE_CASE).replace(cleanTitle, "")
        cleanTitle = Regex("""[^\w\s\u0400-\u04FF]""").replace(cleanTitle, " ")
        cleanTitle = WHITESPACE.replace(cleanTitle, " ").trim()

        var cleanArtist = Regex("""\[.*?]|\(.*?\)""").replace(artist.orEmpty(), "")
        cleanArtist = Regex("""- topic|vevo|records|official""", RegexOption.IGNORE_CASE).replace(cleanArtist, "")
        cleanArtist = Regex("""[^\w\s\u0400-\u04FF]""").replace(cleanArtist, " ")
        cleanArtist = WHITESPACE.replace(cleanArtist, " ").trim()

        return cleanTitle to cleanArtist
    }

    /** Desktop `fetchArtistInfo()`: strips "- Topic"/"VEVO"/"Official"/"Records". */
    fun cleanArtistForLookup(name: String?): String =
        Regex(""" - Topic|VEVO|Official|Records""", RegexOption.IGNORE_CASE)
            .replace(name.orEmpty(), "")
            .trim()

    fun isCyrillic(text: String?): Boolean = text != null && CYRILLIC.containsMatchIn(text)

    /** Desktop disk cache name for fetched lyrics: `artist___title.lrc` (see `getFetchedLyricsPath`). */
    fun lyricsCacheFile(artist: String?, title: String?): String {
        val cleanTitle = Regex("""[^a-zA-Z0-9_-]""").replace(title.orEmpty(), "_").lowercase(Locale.ROOT)
        val cleanArtist = Regex("""[^a-zA-Z0-9_-]""").replace(artist.orEmpty(), "_").lowercase(Locale.ROOT)
        return "${cleanArtist}___${cleanTitle}.lrc"
    }

    /** Primary key used for lyrics rows (desktop uses `${artist}:${title}` in `lyricsCache`). */
    /**
     * Cache key for lyrics — the Android equivalent of `getFetchedLyricsPath()` in
     * server.js: `lyrics/<artist>___<title>.lrc` with every character outside
     * `[a-zA-Z0-9_-]` replaced by `_` and lowercased. Keeping the shape identical means
     * a lyrics cache copied from the desktop keeps working.
     */
    fun lyricsKey(artist: String?, title: String?): String {
        val clean = Regex("""[^a-zA-Z0-9_-]""")
        val safeArtist = clean.replace(artist.orEmpty(), "_").lowercase(Locale.ROOT)
        val safeTitle = clean.replace(title.orEmpty(), "_").lowercase(Locale.ROOT)
        return "${safeArtist}___${safeTitle}"
    }

    fun urlEncode(value: String): String =
        URLEncoder.encode(value, Charsets.UTF_8.name()).replace("+", "%20")

    /** `%02d:%02d` — desktop `formatDuration(sec)` in app.js. */
    fun formatDuration(totalSeconds: Long): String {
        val seconds = if (totalSeconds < 0) 0 else totalSeconds
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) {
            String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.US, "%d:%02d", m, s)
        }
    }
}
