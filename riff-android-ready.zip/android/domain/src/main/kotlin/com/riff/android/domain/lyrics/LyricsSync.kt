package com.riff.android.domain.lyrics

import com.riff.android.domain.model.LyricLine

/**
 * Sync maths for the lyrics view. Pure functions, no Android, so both the UI and the
 * tests use the same rules.
 *
 * Desktop equivalents:
 *  - `updateSyncedLyrics()` in app.js: the active line is the last timestamp that is
 *    `<= currentTime` (the desktop also highlighted one line early — that lead is kept),
 *  - the "shift lyrics" buttons of the custom-lyrics editor: every `[mm:ss.xx]` stamp is
 *    moved by a fixed offset (the desktop used a +4 s lead as its default),
 *  - `scrollLyricsToLine()`: re-centre the active line (implemented in the UI with a
 *    `LazyListState`).
 */
object LyricsSync {

    /** Desktop highlighted slightly early so a line appears as it is sung. */
    const val LEAD_MS = 120L

    /** Default offset of the desktop "shift" buttons. */
    const val CUSTOM_SHIFT_LEAD_SECONDS = 4.0

    /**
     * Index of the line that should be highlighted at [positionMs], or -1 when the
     * lyrics are plain text (nothing to sync).
     */
    fun activeLineIndex(lines: List<LyricLine>, positionMs: Long): Int {
        if (lines.isEmpty()) return -1
        if (lines.none { it.isTimed }) return -1

        var active = -1
        for ((index, line) in lines.withIndex()) {
            if (!line.isTimed) continue
            if (line.timeMs <= positionMs + LEAD_MS) active = index else break
        }
        // Before the first timestamp the first line is highlighted (desktop behaviour).
        return if (active == -1 && lines.first().isTimed) 0 else active
    }

    /**
     * Moves every LRC timestamp by [seconds] (negative shifts earlier, clamped at 0).
     * Non-timestamp text and metadata tags (`[ar:...]`) are left untouched.
     */
    fun shiftTimestamps(lrc: String, seconds: Double): String {
        val offsetMs = (seconds * 1000).toLong()
        return TIMESTAMP.replace(lrc) { match ->
            val first = match.groupValues[1].toIntOrNull() ?: 0
            val second = match.groupValues[2].toIntOrNull() ?: 0
            val third = match.groupValues[3]
            val fraction = match.groupValues[4]
            // `[mm:ss.xx]` has no third component, `[hh:mm:ss]` does.
            val totalMs = if (third.isEmpty()) {
                first * 60_000 + second * 1_000 + fractionToMillis(fraction)
            } else {
                val secs = third.toIntOrNull() ?: 0
                first * 3_600_000 + second * 60_000 + secs * 1_000 + fractionToMillis(fraction)
            }
            val shifted = (totalMs + offsetMs).coerceAtLeast(0)
            "[%02d:%02d.%02d]".format(shifted / 60_000, (shifted % 60_000) / 1_000, (shifted % 1_000) / 10)
        }
    }

    private fun fractionToMillis(fraction: String): Int = when (fraction.length) {
        0 -> 0
        1 -> fraction.toInt() * 100
        2 -> fraction.toInt() * 10
        else -> fraction.take(3).toInt()
    }

    /**
     * `[mm:ss]`, `[mm:ss.xx]`, `[mm:ss:xx]` and `[hh:mm:ss]`. The desktop only emitted
     * the minute form; hours are accepted so long mixes do not lose their sync.
     */
    private val TIMESTAMP = Regex("""\[(\d{1,4}):(\d{1,3})(?::(\d{1,3}))?(?:[.](\d{1,3}))?]""")
}
