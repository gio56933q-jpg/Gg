package com.riff.android.domain.model

enum class LyricsSource { LRCLIB, CUSTOM, IMPORTED, NONE }

/** One lyric line. [timeMs] < 0 means "plain line, no timestamp" (desktop uses -1). */
data class LyricLine(
    val timeMs: Long,
    val text: String,
    /** Enhanced LRC word timings (`<mm:ss.xx>` tags), when the provider supplied them. */
    val words: List<LyricWord> = emptyList(),
) {
    val isTimed: Boolean get() = timeMs >= 0
}

data class LyricWord(val text: String, val timeMs: Long)

/**
 * Desktop equivalent: `state.syncedLyrics` (array of `{time, text}` built by
 * `loadSyncedLyrics()` in `app.js`) with the `isCustomLyrics` flag.
 */
data class Lyrics(
    val trackKey: String,
    val lines: List<LyricLine> = emptyList(),
    val source: LyricsSource = LyricsSource.NONE,
    val synced: Boolean = false,
    /** Raw text as stored (LRC or plain), needed by the custom lyrics editor. */
    val raw: String = "",
    val updatedAt: Long = 0L,
) {
    val isCustom: Boolean get() = source == LyricsSource.CUSTOM
    val isEmpty: Boolean get() = lines.isEmpty()
}
