package com.riff.android.domain.repo

import com.riff.android.domain.model.ArtistProfile
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.DownloadResult
import com.riff.android.domain.model.Lyrics
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.Track

/**
 * The desktop app has a single search path (`handleSearch` in server.js: yt-dlp
 * `ytsearch`/`scsearch` + a direct YouTube HTML scrape). On Android the UI must
 * not care which platform is used, so every backend is a [MusicSearchProvider].
 */
interface MusicSearchProvider {
    val id: String
    val platform: SearchPlatform
    /** Human readable name, used by the settings screen. */
    val label: String

    suspend fun search(query: String, limit: Int = 20): List<Track>
}

/**
 * Resolves a [Track] to something ExoPlayer can play.
 *
 * Desktop equivalent: `/api/stream-info` (yt-dlp `-g`) plus `/api/check-cache`
 * for the local file. Android resolves lazily through the media session, so
 * http(s) URLs, `file://` and `content://` are all valid results.
 */
interface StreamResolver {
    val id: String

    /**
     * @return direct media URL (progressive or HLS) that ExoPlayer can open.
     * @throws StreamResolutionException when the stream cannot be resolved.
     */
    suspend fun resolve(track: Track): String

    /** Desktop prefetches the first search results and caches stream urls for 2h. */
    suspend fun prefetch(track: Track) {
        runCatching { resolve(track) }
    }
}

class StreamResolutionException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * Download backends. Desktop runs yt-dlp + ffmpeg as child processes; Android
 * cannot, so the concrete implementation is pluggable:
 *
 *  - [OnDeviceDownloadProvider]  (NewPipeExtractor + OkHttp)
 *  - [RiffServerDownloadProvider] (HTTP backend speaking the desktop's API)
 */
interface DownloadProvider {
    val id: String
    val label: String

    /** True when this provider is usable with the current configuration. */
    suspend fun isAvailable(): Boolean

    /**
     * Downloads [track] to app storage.
     *
     * @param onProgress called with (bytesDownloaded, totalBytes) — total may be 0/unknown.
     * @param destinationFileName suggested file name *without* the extension.
     */
    suspend fun download(
        track: Track,
        format: DownloadFormat,
        quality: DownloadQuality,
        destinationFileName: String,
        onProgress: suspend (Long, Long) -> Unit,
    ): DownloadResult
}

/**
 * Transcoding hook. FFmpeg is *not* bundled by default (see android/PORTING.md);
 * the default implementation keeps the source container, which ExoPlayer and
 * Android's media stack can play natively.
 */
interface AudioTranscoder {
    val id: String
    val available: Boolean

    /**
     * @return the final file name/extension after transcoding (may be unchanged).
     */
    suspend fun transcode(
        sourcePath: String,
        targetFormat: DownloadFormat,
        quality: DownloadQuality,
    ): TranscodeResult
}

sealed interface TranscodeResult {
    data class Success(val path: String, val extension: String) : TranscodeResult
    data class Failure(val message: String) : TranscodeResult
    /** Transcoding unavailable/skipped — original file is kept as-is. */
    data object Skipped : TranscodeResult
}

/** Lyrics lookup (desktop: lrclib.net via `/api/lyrics`). */
interface LyricsProvider {
    val id: String
    val label: String
    fun isEnabled(): Boolean
    suspend fun fetch(track: Track): String?
}

/** Remote artist profile (desktop: Deezer + Wikipedia in `fetchArtistInfo`). */
interface ArtistInfoProvider {
    val id: String
    suspend fun lookup(artistName: String): ArtistProfile?
}

/** Link between downloaded files and the track rows (desktop `metadata.json`). */
interface TrackStore {
    suspend fun upsert(track: Track): Track
    suspend fun get(trackId: String): Track?
}
