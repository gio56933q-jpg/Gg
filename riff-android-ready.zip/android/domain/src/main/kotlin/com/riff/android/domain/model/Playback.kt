package com.riff.android.domain.model

/** Port of `state.isRepeat` / `state.isShuffle` (desktop has a simple on/off repeat). */
enum class RepeatMode { OFF, ALL, ONE;

    fun next(): RepeatMode = when (this) {
        OFF -> ALL
        ALL -> ONE
        ONE -> OFF
    }
}

/** Port of `state.audioSettings.speed` / `speedPitch` / `pitch` (see `audio-engine.js`). */
data class PlaybackParameters(
    val speed: Float = 1f,
    val pitch: Float = 1f,
) {
    companion object {
        val DEFAULT = PlaybackParameters()
    }
}

/**
 * Everything needed to restore playback after process death
 * (desktop stores this implicitly in `state` + `devsize_history`).
 */
data class PlaybackSnapshot(
    val currentTrackId: String? = null,
    val positionMs: Long = 0L,
    val queueIndex: Int = -1,
    val queueIds: List<String> = emptyList(),
    val isPlaying: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val shuffle: Boolean = false,
    val updatedAt: Long = 0L,
)

/** What the queue was started from — used to label the queue and to extend "My Wave". */
sealed interface PlaybackContext {
    data object None : PlaybackContext
    data object Search : PlaybackContext
    data object Favorites : PlaybackContext
    data object History : PlaybackContext
    data object Library : PlaybackContext
    data object Downloads : PlaybackContext
    data object Queue : PlaybackContext
    data class PlaylistContext(val playlistId: String, val name: String) : PlaybackContext
    data class ArtistContext(val name: String) : PlaybackContext
    data object MyWave : PlaybackContext
}
