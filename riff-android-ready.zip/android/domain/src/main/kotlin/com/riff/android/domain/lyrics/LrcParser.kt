package com.riff.android.domain.lyrics

import com.riff.android.domain.model.LyricLine
import com.riff.android.domain.model.LyricWord
import com.riff.android.domain.model.Lyrics
import com.riff.android.domain.model.LyricsSource

/**
 * Port of the inline LRC parsing in `loadSyncedLyrics()` (app.js) extended with:
 *  - multiple timestamps per line (`[00:12.00][00:58.00]chorus`),
 *  - the `[offset:+/-ms]` tag,
 *  - enhanced LRC word timings (`<00:12.34>word`), which the desktop app receives
 *    as raw markup and strips for karaoke mode.
 *
 * Timestamps are converted to milliseconds; untimed lines keep `timeMs = -1`
 * exactly like the desktop code (`parsed.push({ time: -1, text })`).
 */
object LrcParser {

    private val LRC_LINE = Regex("""^((?:\[\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?])+)(.*)$""")
    private val TIME_TAG = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val WORD_TAG = Regex("""<(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?>""")
    private val OFFSET_TAG = Regex("""\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)
    private val META_TAG = Regex("""^\[[a-zA-Z#]+:[^\]]*]$""")

    fun parse(raw: String, trackKey: String, source: LyricsSource): Lyrics {
        val text = raw.trim()
        if (text.isEmpty()) return Lyrics(trackKey = trackKey, source = LyricsSource.NONE)

        val offsetMs = OFFSET_TAG.find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L

        val lines = mutableListOf<LyricLine>()
        for (rawLine in text.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            if (META_TAG.matches(line) && !TIME_TAG.containsMatchIn(line)) continue

            val match = LRC_LINE.find(line)
            if (match != null) {
                val timeTags = TIME_TAG.findAll(match.groupValues[1]).toList()
                val content = match.groupValues[2].trim()
                for (tag in timeTags) {
                    val ms = tagToMs(tag.value) + offsetMs
                    val words = parseWords(content, offsetMs)
                    lines.add(
                        LyricLine(
                            timeMs = ms,
                            text = stripWordTags(content),
                            words = words,
                        ),
                    )
                }
            } else if (line.isNotBlank()) {
                lines.add(LyricLine(timeMs = -1L, text = line))
            }
        }

        lines.sortWith(compareBy({ if (it.timeMs < 0) Long.MAX_VALUE else it.timeMs }))
        val synced = lines.any { it.isTimed }

        return Lyrics(
            trackKey = trackKey,
            lines = lines,
            source = source,
            synced = synced,
            raw = raw,
        )
    }

    private fun parseWords(content: String, offsetMs: Long): List<LyricWord> {
        if (!content.contains('<')) return emptyList()
        val words = mutableListOf<LyricWord>()
        var pendingTime = -1L
        var lastEnd = 0
        WORD_TAG.findAll(content).forEach { match ->
            val before = content.substring(lastEnd, match.range.first)
            val wordText = before.trim()
            if (wordText.isNotEmpty() && pendingTime >= 0) {
                words.add(LyricWord(wordText, pendingTime))
            }
            pendingTime = tagToMs(match.value) + offsetMs
            lastEnd = match.range.last + 1
        }
        val tail = content.substring(lastEnd).trim()
        if (tail.isNotEmpty() && pendingTime >= 0) words.add(LyricWord(tail, pendingTime))
        return words
    }

    private fun stripWordTags(content: String): String =
        WORD_TAG.replace(content, "").trim()

    private fun tagToMs(tag: String): Long {
        val inner = tag.trim('[', ']', '<', '>')
        val parts = inner.split(':', '.')
        if (parts.size < 2) return -1L
        val minutes = parts[0].toLongOrNull() ?: return -1L
        val seconds = parts[1].toLongOrNull() ?: return -1L
        val fractionRaw = parts.getOrNull(2)
        val fractionMs = when {
            fractionRaw == null -> 0L
            fractionRaw.length == 1 -> fractionRaw.toLongOrNull()?.times(100) ?: 0L
            fractionRaw.length == 2 -> fractionRaw.toLongOrNull()?.times(10) ?: 0L
            else -> fractionRaw.take(3).toLongOrNull() ?: 0L
        }
        return minutes * 60_000L + seconds * 1000L + fractionMs
    }

    /** True when at least one line carries a timestamp (desktop `hasSyncTimes`). */
    fun hasSyncTimes(lyrics: Lyrics): Boolean = lyrics.lines.any { it.isTimed }
}
