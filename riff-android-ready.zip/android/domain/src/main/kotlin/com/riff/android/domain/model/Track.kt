package com.riff.android.domain.model

import com.riff.android.domain.text.TrackText

/**
 * Where a track came from. Mirrors the `platform` field used by the desktop app
 * (`server.js`, `app.js`), plus the two Android-only sources.
 */
enum class TrackSource(val id: String) {
    YOUTUBE("youtube"),
    SOUNDCLOUD("soundcloud"),
    /** A file the user imported from device storage (MediaStore / SAF). */
    LOCAL("local"),
    /** A track served by a configured remote Riff backend. */
    RIFF_SERVER("riff");

    companion object {
        fun fromId(id: String?): TrackSource = when (id?.lowercase()) {
            "soundcloud", "sc" -> SOUNDCLOUD
            "local", "file" -> LOCAL
            "riff" -> RIFF_SERVER
            else -> YOUTUBE
        }
    }
}

/**
 * The single track representation used everywhere in the Android app.
 *
 * Desktop equivalent: the plain objects produced by `handleSearch` /
 * `normalizeTrack()` in `server.js` and persisted in `localStorage` by `app.js`
 * (`devsize_favorites`, `devsize_history`, `devsize_playlists`) plus the
 * `metadata.json` index on disk.
 *
 * Android adds [localUri] (offline playback), [favorite]/[lastPlayedAt] and
 * [downloadedAt] so that library views do not need to join separate lists.
 */
data class Track(
    /** Canonical id: see [TrackText.canonicalId]. */
    val id: String,
    val title: String,
    val artist: String,
    val album: String? = null,
    val durationMs: Long = 0L,
    val artworkUri: String? = null,
    val source: TrackSource = TrackSource.YOUTUBE,
    /** Platform id (YouTube video id / SoundCloud id). */
    val sourceId: String? = null,
    /** Page URL on the source platform. */
    val sourceUrl: String? = null,
    /** For search results that only have a query (port of Deezer-backed artist tracks). */
    val searchQuery: String? = null,
    /** Local file/content uri when the track is downloaded or imported. */
    val localUri: String? = null,
    val downloadedAt: Long? = null,
    val fileSizeBytes: Long = 0L,
    val favorite: Boolean = false,
    val lastPlayedAt: Long? = null,
    val playCount: Int = 0,
    val addedAt: Long = 0L,
) {
    val durationSeconds: Int get() = (durationMs / 1000L).toInt()

    /** Offline-first: a downloaded/imported track always plays from [localUri]. */
    val isLocal: Boolean get() = !localUri.isNullOrBlank()

    val isDownloaded: Boolean get() = downloadedAt != null && isLocal

    /** Normalized `artist::title` dedupe key (ported from `getTrackNormalizedKey`). */
    val normalizedKey: String get() = TrackText.normalizeKey(artist, title)

    val displayAlbum: String get() = album?.takeIf { it.isNotBlank() } ?: UNKNOWN_ALBUM

    /** Stable uri understood by the playback service (`riff://track/<encoded id>`). */
    val playableUri: String get() = "$PLAYABLE_SCHEME://track/${TrackText.urlEncode(id)}"

    fun withLocal(uri: String, sizeBytes: Long, at: Long): Track =
        copy(localUri = uri, fileSizeBytes = sizeBytes, downloadedAt = at, addedAt = if (addedAt == 0L) at else addedAt)

    fun withFavorite(value: Boolean): Track = copy(favorite = value)

    fun withPlayed(at: Long): Track = copy(lastPlayedAt = at, playCount = playCount + 1)

    companion object {
        const val UNKNOWN_ALBUM = "Unknown album"
        const val PLAYABLE_SCHEME = "riff"
    }
}

fun Track.isSameAs(other: Track?): Boolean {
    if (other == null) return false
    if (id.isNotBlank() && id == other.id) return true
    return normalizedKey == other.normalizedKey && normalizedKey.isNotBlank()
}
