package com.riff.android.domain.text

/**
 * Exact port of `isSpamOrUnofficial()` from `server.js`.
 *
 * It keeps non-music YouTube noise (podcasts, long mixes, gameplay, ...) out of
 * search results and, more importantly, out of the recommendation candidate pool.
 */
object SpamFilter {

    // NOTE: these patterns are inconsistent in the original (some match anywhere,
    // some use \b) — they are reproduced verbatim so behaviour stays identical.
    private val NON_MUSIC_WORDS = listOf(
        Regex("""\blecture\b""", RegexOption.IGNORE_CASE),
        Regex("""\btalk\b""", RegexOption.IGNORE_CASE),
        Regex("""\bconversation\b""", RegexOption.IGNORE_CASE),
        Regex("""\bin conversation\b""", RegexOption.IGNORE_CASE),
        Regex("""\bacademy\b""", RegexOption.IGNORE_CASE),
        Regex("""\bmasterclass\b""", RegexOption.IGNORE_CASE),
        Regex("""\bdocumentary\b""", RegexOption.IGNORE_CASE),
        Regex("""\bbehind the scenes\b""", RegexOption.IGNORE_CASE),
        Regex("""\bmaking of\b""", RegexOption.IGNORE_CASE),
        Regex("""\bexplained\b""", RegexOption.IGNORE_CASE),
        Regex("""\bhistory of\b""", RegexOption.IGNORE_CASE),
        Regex("""\bhow to\b""", RegexOption.IGNORE_CASE),
        Regex("""\bnews\b""", RegexOption.IGNORE_CASE),
        Regex("""\blive stream\b""", RegexOption.IGNORE_CASE),
        Regex("""\blivestream\b""", RegexOption.IGNORE_CASE),
        Regex("""\bfull concert\b""", RegexOption.IGNORE_CASE),
        Regex("""\bfull set\b""", RegexOption.IGNORE_CASE),
        Regex("""\blive at\b""", RegexOption.IGNORE_CASE),
        Regex("""\bofficial video essay\b""", RegexOption.IGNORE_CASE),
    )

    private val NON_MUSIC_PATTERNS = listOf(
        Regex("""\bepisode\s*\d+""", RegexOption.IGNORE_CASE),
        Regex("""\bseason\s*\d+""", RegexOption.IGNORE_CASE),
        Regex("""\bs\d+e\d+\b""", RegexOption.IGNORE_CASE),
        Regex("""\bep\s*\.?\s*\d+\b""", RegexOption.IGNORE_CASE),
        Regex("""\bseries\b""", RegexOption.IGNORE_CASE),
        Regex("""\btrailer\b""", RegexOption.IGNORE_CASE),
        Regex("""\bteaser\b""", RegexOption.IGNORE_CASE),
        Regex("""\bfull movie\b""", RegexOption.IGNORE_CASE),
        Regex("""\bshort film\b""", RegexOption.IGNORE_CASE),
        Regex("""\bpodcast\b""", RegexOption.IGNORE_CASE),
        Regex("""\bgameplay\b""", RegexOption.IGNORE_CASE),
        Regex("""\bwalkthrough\b""", RegexOption.IGNORE_CASE),
        Regex("""\bplaythrough\b""", RegexOption.IGNORE_CASE),
        Regex("""\breview\b""", RegexOption.IGNORE_CASE),
        Regex("""\breaction\b""", RegexOption.IGNORE_CASE),
        Regex("""\binterview\b""", RegexOption.IGNORE_CASE),
        Regex("""\baudiobook\b""", RegexOption.IGNORE_CASE),
        Regex("""\bvlog\b""", RegexOption.IGNORE_CASE),
        Regex("""\bunboxing\b""", RegexOption.IGNORE_CASE),
        Regex("""\btutorial\b""", RegexOption.IGNORE_CASE),
        Regex("""\bparody\b""", RegexOption.IGNORE_CASE),
    )

    private val BAD_KEYWORDS = listOf(
        "1 hour", "2 hours", "10 hours", "hour loop", "hours loop",
        "full album", "discography", "ost compilation", "soundtrack compilation",
        "playlist mix", "dj set", "type beat", "slowed + reverb", "slowed down",
        "sped up", "bass boosted", "nightcore", "reaction to", "reacting to",
    )

    /**
     * @param durationSeconds 0 means "unknown" (the desktop version treats 0 as unknown too).
     */
    fun isSpamOrUnofficial(title: String?, durationSeconds: Int, channelName: String? = null): Boolean {
        if (durationSeconds > 0 && (durationSeconds < 90 || durationSeconds > 420)) return true

        val combined = "${title.orEmpty().lowercase()} ${channelName.orEmpty().lowercase()}".trim()

        if (NON_MUSIC_WORDS.any { it.containsMatchIn(combined) }) return true
        if (NON_MUSIC_PATTERNS.any { it.containsMatchIn(combined) }) return true
        if (BAD_KEYWORDS.any { combined.contains(it) }) return true

        return false
    }
}
