package com.riff.android.domain.model

/**
 * Port of `state.audioSettings` in `app.js` / `RiffAudioEngine.audioSettings`
 * in `audio-engine.js`.
 *
 * speed      - playback rate that preserves pitch (`player.playbackRate = speed`).
 * speedPitch - tape-style rate change (pitch follows the rate).
 * pitch      - additional pitch shift in semitones (independent of speed).
 * reverb     - 0..100 wet amount (convolver send in the desktop web audio graph).
 * distortion - 0..100 waveshaper drive.
 * volume     - preset gain ("gain" in the desktop preset objects), 1.0 = unity.
 * echo       - 0..100 feedback delay send.
 */
data class AudioSettings(
    val speed: Float = 1f,
    val speedPitch: Float = 1f,
    val pitch: Int = 0,
    val reverb: Int = 0,
    val distortion: Int = 0,
    val volume: Float = 1f,
    val echo: Int = 0,
) {
    /** Desktop: `isModified()` in `audio-engine.js`. */
    val isModified: Boolean
        get() = speed != 1f || speedPitch != 1f || pitch != 0 || reverb != 0 ||
            distortion != 0 || volume != 1f || echo != 0

    companion object {
        val DEFAULT = AudioSettings()
    }
}

enum class HqEngine(val id: String, val label: String) {
    HQ_MUSIC_3("hqmusic-3", "HQ Music 3"),
    GLYPHS_7B("glyphs-7B", "Glyphs 7B"),
    FYRO_1_1("fyro1.1", "Fyro 1.1");

    companion object {
        fun fromId(id: String?): HqEngine = entries.firstOrNull { it.id == id } ?: HQ_MUSIC_3
    }
}

/** Port of `state.hqSettings` (see `_applyHqParams()` in `audio-engine.js`). */
data class HqSettings(
    val engine: HqEngine = HqEngine.HQ_MUSIC_3,
    val preset: String = "studio",
    val vocal: Int = 0,
    val air: Int = 0,
    val bass: Int = 0,
)

/**
 * Port of the three HQ preset chips (`#hq-preset-*` handlers in app.js):
 *
 * ```js
 * if (preset === 'studio')  { v = 0;   a = 0;   b = 0;  }
 * else if (preset === 'vinyl')   { v = 15;  a = -15; b = 25; }
 * else if (preset === 'concert') { v = -10; a = 30;  b = 15; }
 * ```
 *
 * The chips only set the three knobs; the engine selection is independent, exactly
 * like the desktop.
 */
object HqPresets {
    val STUDIO = HqPreset(id = "studio", label = "Studio Clear", vocal = 0, air = 0, bass = 0)
    val VINYL = HqPreset(id = "vinyl", label = "Warm Vinyl", vocal = 15, air = -15, bass = 25)
    val CONCERT = HqPreset(id = "concert", label = "Concert Hall", vocal = -10, air = 30, bass = 15)

    val ALL: List<HqPreset> = listOf(STUDIO, VINYL, CONCERT)

    fun find(id: String?): HqPreset = ALL.firstOrNull { it.id == id } ?: STUDIO

    /** Applies a preset to the knobs, keeping the selected engine. */
    fun apply(hq: HqSettings, presetId: String): HqSettings =
        find(presetId).let { preset -> hq.copy(preset = preset.id, vocal = preset.vocal, air = preset.air, bass = preset.bass) }
}

data class HqPreset(
    val id: String,
    val label: String,
    val vocal: Int,
    val air: Int,
    val bass: Int,
)

/**
 * Port of the preset objects (`defaultPresets` + `devsize_custom_presets`).
 * `id` starts with `p_` for built-ins, custom presets use a generated id.
 */
data class RiffPreset(
    val id: String,
    val name: String,
    val settings: AudioSettings,
) {
    /** Desktop distinguishes built-in (`defaultPresets`) from user presets. */
    val isCustom: Boolean get() = !id.startsWith(DEFAULT_PREFIX)

    companion object {
        const val DEFAULT_PREFIX = "p_"
    }
}

/** Exact port of `defaultPresets` in `app.js`. */
object RiffPresets {
    val DEFAULT = RiffPreset("p_default", "default", AudioSettings())

    val BUILT_IN: List<RiffPreset> = listOf(
        DEFAULT,
        RiffPreset("p_speedup", "speed up (orig pitch)", AudioSettings(speed = 1.35f)),
        RiffPreset("p_speedup_pitch", "speed up (tape pitch)", AudioSettings(speedPitch = 1.30f)),
        RiffPreset("p_slowed", "slowed + reverb", AudioSettings(speedPitch = 0.82f, reverb = 65, echo = 15)),
        RiffPreset("p_nightcore", "nightcore", AudioSettings(speedPitch = 1.25f, reverb = 20)),
        RiffPreset("p_distortion", "distortion hard", AudioSettings(distortion = 75, volume = 1.25f)),
    )

    fun find(id: String?, custom: List<RiffPreset> = emptyList()): RiffPreset? =
        (BUILT_IN + custom).firstOrNull { it.id == id }
}
