package com.riff.android.domain.model

/** Port of the audio-editor export (`renderOffline` + `audioBufferToWav` in `audio-engine.js`). */
enum class ExportFormat(val extension: String, val mimeType: String) {
    WAV("wav", "audio/wav"),
    M4A("m4a", "audio/mp4"),
    OPUS("opus", "audio/ogg"),
}

/**
 * Trim/export request. The desktop editor renders the effects chain offline and
 * encodes a WAV in the browser; on Android this goes through [ExportRepository].
 */
data class ExportRequest(
    val trackId: String,
    val startMs: Long,
    val endMs: Long,
    val format: ExportFormat = ExportFormat.WAV,
    val applyEffects: Boolean = true,
    val settings: AudioSettings = AudioSettings(),
    val hqSettings: HqSettings = HqSettings(),
    val hqEnabled: Boolean = false,
)

sealed interface ExportResult {
    data class Success(val uri: String, val displayName: String, val bytes: Long) : ExportResult
    data class Failure(val message: String) : ExportResult
    data object Unsupported : ExportResult
}
