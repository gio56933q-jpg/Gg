package com.riff.android.domain.repo

import com.riff.android.domain.model.AdvancedSettings
import com.riff.android.domain.model.Album
import com.riff.android.domain.model.Artist
import com.riff.android.domain.model.AudioSettings
import com.riff.android.domain.model.BackendSettings
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.DownloadTask
import com.riff.android.domain.model.HistoryEntry
import com.riff.android.domain.model.HqSettings
import com.riff.android.domain.model.Lyrics
import com.riff.android.domain.model.LyricsSettings
import com.riff.android.domain.model.PlaybackSettings
import com.riff.android.domain.model.PlaybackSnapshot
import com.riff.android.domain.model.Playlist
import com.riff.android.domain.model.RiffPreset
import com.riff.android.domain.model.RiffSettings
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.SearchResult
import com.riff.android.domain.model.ThemeSettings
import com.riff.android.domain.model.Track
import com.riff.android.domain.recommend.RecommendationResult
import com.riff.android.domain.recommend.TasteProfile
import kotlinx.coroutines.flow.Flow

/**
 * Library = everything the user can see locally: downloaded Riff tracks,
 * imported device files, favorites, history and playlists.
 * Desktop equivalent: `/api/offline-library` + the localStorage arrays in app.js.
 */
interface LibraryRepository {
    /** All library tracks (downloaded + imported), newest first. */
    fun observeLibrary(): Flow<List<Track>>
    fun observeFavorites(): Flow<List<Track>>
    fun observeHistory(): Flow<List<Track>>
    fun observeDownloads(): Flow<List<Track>>

    fun searchLocal(query: String): Flow<List<Track>>
    fun observeArtists(): Flow<List<Artist>>
    fun observeAlbums(): Flow<List<Album>>
    suspend fun get(trackId: String): Track?
    /** Bulk lookup that preserves the requested order (queue restore, exports). */
    suspend fun getMany(trackIds: List<String>): List<Track>
    suspend fun findLocalByKey(normalizedKey: String): Track?

    /** Persist a remote track into the library index (does not mark it downloaded). */
    suspend fun upsert(track: Track): Track
    suspend fun upsertAll(tracks: List<Track>)

    suspend fun setFavorite(track: Track, favorite: Boolean): Track
    suspend fun recordPlayed(track: Track, playedAt: Long): Track
    suspend fun clearHistory()
    suspend fun deleteDownloaded(trackId: String, deleteFile: Boolean)
    suspend fun clearDownloads()
    suspend fun totalDownloadBytes(): Long

    /** Import a picked/external audio file (SAF or MediaStore) into the library. */
    suspend fun importLocalFile(uri: String, displayName: String?, mimeType: String?, sizeBytes: Long): Track?
    /** MediaStore scan (READ_MEDIA_AUDIO) results, added to the library index. */
    suspend fun syncMediaStore(excludedFolders: Set<String>): Int
}

interface PlaylistRepository {
    fun observePlaylists(): Flow<List<Playlist>>
    fun observePlaylist(playlistId: String): Flow<Playlist?>
    fun observePlaylistTracks(playlistId: String): Flow<List<Track>>
    suspend fun createPlaylist(name: String): Playlist
    suspend fun renamePlaylist(playlistId: String, name: String)
    suspend fun deletePlaylist(playlistId: String)
    suspend fun addTrack(playlistId: String, track: Track)
    suspend fun addTracks(playlistId: String, tracks: List<Track>)
    suspend fun removeTrack(playlistId: String, trackId: String)
    /** Port of the desktop drag-reorder (`initListReordering`). */
    suspend fun moveTrack(playlistId: String, fromIndex: Int, toIndex: Int)
}

interface HistoryRepository {
    fun observeHistory(): Flow<List<HistoryEntry>>
    suspend fun record(track: Track, at: Long)
    suspend fun clear()
}

interface LyricsRepository {
    /** Cached lyrics (custom first, then fetched) — offline-first like the desktop disk cache. */
    suspend fun get(track: Track, allowOnline: Boolean = true): Lyrics
    suspend fun saveCustom(track: Track, rawLyrics: String): Lyrics
    suspend fun deleteCustom(track: Track)
    suspend fun cacheFetched(track: Track, rawLyrics: String): Lyrics
    suspend fun hasCached(track: Track): Boolean
}

interface SearchRepository {
    /** Desktop `/api/search`: results are mapped to [Track] the same way. */
    suspend fun search(query: String, platform: SearchPlatform, limit: Int = 20): SearchResult
    /** In-library search (desktop's per-view filter boxes). */
    suspend fun searchLibrary(query: String): List<Track>
    suspend fun clearCache()
}

interface RecommendationRepository {
    /** Desktop `loadHomePage()` + `extendMyWaveQueue()`: seeds from history + favorites. */
    suspend fun recommend(limit: Int = 10, extend: Boolean = false): RecommendationResult
    fun observeRecentlyRecommendedCount(): Flow<Int>
    suspend fun resetSeen()
}

interface ArtistRepository {
    fun observeLocalArtists(): Flow<List<Artist>>
    /** Desktop `openArtistProfile()` -> `/api/artist`. */
    suspend fun loadProfile(artistName: String): com.riff.android.domain.model.ArtistProfile?
}

interface DownloadRepository {
    fun observeAll(): Flow<List<DownloadTask>>
    fun observe(trackId: String): Flow<DownloadTask?>
    fun observeActive(): Flow<List<DownloadTask>>

    /**
     * Desktop keeps a `downloadingSet` to avoid duplicate work; on Android the
     * uniqueness is enforced by the WorkManager unique-work name + the Room row.
     */
    suspend fun enqueue(
        track: Track,
        format: DownloadFormat = DownloadFormat.MP3,
        quality: DownloadQuality = DownloadQuality.BEST,
        providerId: String? = null,
    ): Boolean

    suspend fun cancel(trackId: String)
    suspend fun retry(trackId: String)
    suspend fun remove(trackId: String, deleteFile: Boolean)
    suspend fun clearFinished()

    // --- worker facing API (the desktop equivalents are the `downloadingSet`
    //     bookkeeping and `saveTrackMetadata()` calls in server.js) ---

    suspend fun markRunning(trackId: String, providerId: String)
    suspend fun updateProgress(trackId: String, bytesDownloaded: Long, totalBytes: Long)
    suspend fun markCompleted(trackId: String, localUri: String, bytes: Long)
    suspend fun markFailed(trackId: String, error: String, attempts: Int)
    suspend fun markCanceled(trackId: String)
}

interface ExportRepository {
    /** Desktop audio editor: render (offline) + save as file. */
    suspend fun export(request: com.riff.android.domain.model.ExportRequest): com.riff.android.domain.model.ExportResult
}

/** Persisted app state that is not track data (desktop localStorage settings). */
interface SettingsRepository {
    fun observeSettings(): Flow<RiffSettings>
    suspend fun setTheme(theme: ThemeSettings)
    suspend fun setPlayback(playback: PlaybackSettings)
    suspend fun setLyrics(lyrics: LyricsSettings)
    suspend fun setAdvanced(advanced: AdvancedSettings)
    suspend fun setBackend(backend: BackendSettings)
    suspend fun setAudio(audio: AudioSettings)
    suspend fun setHq(hq: HqSettings, enabled: Boolean)
    suspend fun setActivePreset(presetId: String)
    suspend fun saveCustomPreset(preset: RiffPreset)
    suspend fun deleteCustomPreset(presetId: String)
    suspend fun current(): RiffSettings
}

/** Queue + resume state (desktop keeps this in memory + history). */
interface PlaybackStateRepository {
    fun observe(): Flow<PlaybackSnapshot>
    suspend fun save(snapshot: PlaybackSnapshot)
    suspend fun clear()
}
