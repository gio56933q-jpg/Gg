package com.riff.android.domain.queue

import com.riff.android.domain.model.RepeatMode
import com.riff.android.domain.model.Track
import com.riff.android.domain.text.TrackText
import kotlin.random.Random

/**
 * Pure port of the queue behaviour in app.js:
 *  - `playTrack(track, queueList, startIndex, context)` seeding rules,
 *  - `playNext()` (shuffle branch, wrap-around, My Wave auto-extend trigger),
 *  - `playPrev()` (the "restart if we are past 3 seconds" rule),
 *  - the `ended` handler (repeat -> restart, otherwise next).
 *
 * The Android player also maps this onto Media3's RepeatMode/SHUFFLE, but keeping
 * the decision logic here means it is testable and identical to the desktop app.
 */
object QueuePlanner {

    /** Desktop `playPrev()`: `currentTime > 3` restarts the track instead of going back. */
    const val PREV_RESTART_THRESHOLD_MS = 3_000L

    /** Desktop `playNext()`: extend My Wave when we land within the last 3 items. */
    const val WAVE_EXTEND_TAIL = 3

    /** Desktop caps `state.history` at 100 entries. */
    const val HISTORY_LIMIT = 100

    data class QueueSeed(val queue: List<Track>, val index: Int)

    /**
     * Desktop `playTrack()` queue seeding:
     * ```
     * if (queueList) { queue = [...queueList]; index = startIndex if it matches, else findIndex, else unshift }
     * else if (!queue.some(isSameTrack)) { queue.push(track); index = queue.length - 1 }
     * ```
     * [existingQueue] is only used for the "start a single track" path.
     */
    fun seedQueue(
        track: Track,
        queueList: List<Track>? = null,
        startIndex: Int = -1,
        existingQueue: List<Track> = emptyList(),
        existingIndex: Int = -1,
    ): QueueSeed {
        if (queueList != null) {
            val queue = queueList.toMutableList()
            var index = if (startIndex in queue.indices && TrackText.isSame(queue[startIndex], track)) {
                startIndex
            } else {
                queue.indexOfFirst { TrackText.isSame(it, track) }
            }
            if (index == -1) {
                queue.add(0, track)
                index = 0
            }
            return QueueSeed(queue, index)
        }

        if (existingQueue.none { TrackText.isSame(it, track) }) {
            val queue = existingQueue.toMutableList().apply { add(track) }
            return QueueSeed(queue, queue.lastIndex)
        }
        return QueueSeed(existingQueue, existingIndex.coerceAtLeast(0))
    }

    /**
     * Desktop `playNext()`. `shuffle` picks a random index (yes, the desktop really
     * can replay the current track — Media3 does the same, so behaviour is kept).
     * [repeatOne] mirrors `state.isRepeat` which restarts the same track.
     */
    fun nextIndex(
        currentIndex: Int,
        size: Int,
        shuffle: Boolean = false,
        repeatOne: Boolean = false,
        random: Random = Random.Default,
    ): Int {
        if (size <= 0) return -1
        if (repeatOne) return currentIndex.coerceIn(0, size - 1)
        if (shuffle) return random.nextInt(size)
        val next = currentIndex + 1
        return if (next >= size) 0 else next
    }

    /**
     * Desktop `playPrev()`. [positionMs] implements the 3 second restart rule:
     * the result [PrevDecision.RestartCurrent] means "seek to 0 instead of switching".
     */
    fun prevDecision(
        currentIndex: Int,
        size: Int,
        positionMs: Long,
        repeatOne: Boolean = false,
    ): PrevDecision {
        if (positionMs > PREV_RESTART_THRESHOLD_MS) return PrevDecision.RestartCurrent
        if (size <= 0) return PrevDecision.None
        if (repeatOne) return PrevDecision.RestartCurrent
        var prev = currentIndex - 1
        if (prev < 0) prev = size - 1
        return PrevDecision.Play(prev)
    }

    /** Desktop: `state.myWaveActive && state.queueIndex >= state.queue.length - 3`. */
    fun shouldExtendWave(queueIndex: Int, size: Int, waveActive: Boolean): Boolean =
        waveActive && size > 0 && queueIndex >= size - WAVE_EXTEND_TAIL

    /** Desktop: `state.queueIndex + 1 >= state.queue.length` -> the wave is exhausted. */
    fun isWaveExhausted(queueIndex: Int, size: Int, waveActive: Boolean): Boolean =
        waveActive && queueIndex + 1 >= size

    /** Media3 mapping of the desktop `isRepeat` flag. */
    fun repeatModeFor(repeatOne: Boolean, loopQueue: Boolean): RepeatMode = when {
        repeatOne -> RepeatMode.ONE
        loopQueue -> RepeatMode.ALL
        else -> RepeatMode.OFF
    }

    /** Desktop dedupes history by track and keeps the newest first (`unshift`, cap 100). */
    fun pushHistory(existing: List<Track>, track: Track, limit: Int = HISTORY_LIMIT): List<Track> {
        val filtered = existing.filterNot { TrackText.isSame(it, track) }
        return (listOf(track) + filtered).take(limit)
    }

    /** Used when the queue grows (My Wave extension / "add to queue"): drop duplicates like the desktop filter does. */
    fun mergeQueue(existing: List<Track>, incoming: List<Track>): List<Track> {
        val ids = existing.map { TrackText.canonicalId(it) }.toMutableSet()
        val keys = existing.map { it.normalizedKey }.toMutableSet()
        val result = existing.toMutableList()
        incoming.forEach { t ->
            val cid = TrackText.canonicalId(t)
            val nkey = t.normalizedKey
            if (!ids.contains(cid) && !keys.contains(nkey)) {
                result.add(t)
                ids.add(cid)
                keys.add(nkey)
            }
        }
        return result
    }
}

sealed interface PrevDecision {
    data class Play(val index: Int) : PrevDecision
    data object RestartCurrent : PrevDecision
    data object None : PrevDecision
}
