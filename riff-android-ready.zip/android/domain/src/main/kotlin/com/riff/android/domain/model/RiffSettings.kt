package com.riff.android.domain.model

enum class ThemeMode(val id: String) {
    DARK("dark"), LIGHT("light"), SYSTEM("system");

    companion object {
        fun fromId(id: String?): ThemeMode = entries.firstOrNull { it.id == id } ?: DARK
    }
}

/** Port of the `paletteStyle` setting in `app.js` (classic / vibrant / muted / ...). */
enum class PaletteStyle(val id: String, val label: String) {
    CLASSIC("classic", "Classic"),
    TONAL_SPOT("tonal-spot", "Tonal spot"),
    EXPRESSIVE("expressive", "Expressive"),
    VIBRANT("vibrant", "Vibrant"),
    NEUTRAL("neutral", "Neutral");

    companion object {
        fun fromId(id: String?): PaletteStyle = entries.firstOrNull { it.id == id } ?: CLASSIC
    }
}

/** Port of the theme section in Settings (`generateM3Palette` inputs). */
data class ThemeSettings(
    val mode: ThemeMode = ThemeMode.DARK,
    val accent: String = DEFAULT_ACCENT,
    val intensity: Int = 0,
    val brightness: Int = 50,
    val paletteStyle: PaletteStyle = PaletteStyle.CLASSIC,
    val meshBrightness: Int = 100,
    val dynamicColorFromArtwork: Boolean = true,
) {
    companion object {
        /** `--md-sys-color-primary: #D0BCFF` in styles.css. */
        const val DEFAULT_ACCENT = "#D0BCFF"
    }
}

/** Playback related user settings. */
data class PlaybackSettings(
    val volume: Float = 0.85f,
    val muted: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val shuffle: Boolean = false,
    val hqEnabled: Boolean = false,
    val skipSilence: Boolean = false,
    val crossfadeMs: Long = 0L,
)

/** Port of the lyrics advanced settings (`riff_adv_online_lyrics`, `_karaoke_words`, `_lyrics_autoscroll`). */
data class LyricsSettings(
    val onlineEnabled: Boolean = true,
    val karaokeWords: Boolean = true,
    val autoScroll: Boolean = true,
    val showWordModeByDefault: Boolean = false,
)

/**
 * Port of `getAdv()` flags in `app.js`.
 * Only flags that make sense on Android are kept (the rest were desktop VFX that
 * are documented in android/PORTING.md as not ported).
 */
data class AdvancedSettings(
    val reducedMotion: Boolean = false,
    val autoExtendWave: Boolean = true,
    val prefetchSearchResults: Boolean = true,
    val downloadOverWifiOnly: Boolean = false,
    val transcodeDownloads: Boolean = false,
    val embedMetadataAndArtwork: Boolean = true,
)

/**
 * How remote tracks are turned into playable streams / downloads.
 *
 * ON_DEVICE  - NewPipeExtractor + OkHttp inside the app (default, works standalone).
 * RIFF_SERVER- a reachable Riff backend (the desktop app's own HTTP API, or a
 *              deployment of it) which uses yt-dlp + ffmpeg.
 * AUTO       - try the Riff server when configured & reachable, else on-device.
 */
enum class BackendMode(val id: String) {
    ON_DEVICE("on_device"), RIFF_SERVER("riff_server"), AUTO("auto");

    companion object {
        fun fromId(id: String?): BackendMode = entries.firstOrNull { it.id == id } ?: ON_DEVICE
    }
}

data class BackendSettings(
    val mode: BackendMode = BackendMode.ON_DEVICE,
    val baseUrl: String = "",
    val preferRemoteDownloads: Boolean = false,
)

/** Aggregate of every persisted setting. */
data class RiffSettings(
    val theme: ThemeSettings = ThemeSettings(),
    val playback: PlaybackSettings = PlaybackSettings(),
    val lyrics: LyricsSettings = LyricsSettings(),
    val advanced: AdvancedSettings = AdvancedSettings(),
    val backend: BackendSettings = BackendSettings(),
    val audio: AudioSettings = AudioSettings(),
    val hq: HqSettings = HqSettings(),
    val activePresetId: String = RiffPresets.DEFAULT.id,
    val customPresets: List<RiffPreset> = emptyList(),
    val mediaStoreFolders: Set<String> = emptySet(),
    val excludedMediaStoreFolders: Set<String> = emptySet(),
) {
    val presets: List<RiffPreset> get() = RiffPresets.BUILT_IN + customPresets
}
