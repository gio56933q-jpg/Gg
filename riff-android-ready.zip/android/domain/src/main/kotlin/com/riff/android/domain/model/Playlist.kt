package com.riff.android.domain.model

/** Port of `state.playlists` in `app.js` (`{id, name, tracks[]}`). */
data class Playlist(
    val id: String,
    val name: String,
    val trackCount: Int = 0,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    /** Up to 4 artwork uris, used for the 2x2 mosaic cover (see `renderPlaylistCover`). */
    val coverUris: List<String> = emptyList(),
)

data class PlaylistTrack(
    val playlistId: String,
    val trackId: String,
    val position: Int,
    val addedAt: Long = 0L,
)
