package com.riff.android.domain.lyrics

import com.riff.android.domain.model.LyricLine
import com.riff.android.domain.model.Lyrics

/**
 * Port of the lyric/playback synchronisation maths from app.js:
 *  - `getLineStartTime()` / `getLineEndTime()`
 *  - `updateSyncedLyricsHighlight()` (active line lookup + karaoke word progress)
 *
 * Desktop constants kept: the custom-lyrics look-ahead of 0.25 s and the 0.5 s
 * minimum line duration.
 */
class LyricsTimeline(
    val lines: List<LyricLine>,
    private val isCustom: Boolean = false,
    /** Desktop `CUSTOM_SHIFT_LEAD_SECONDS = 4.0` (applied to custom lyrics). */
    private val customShiftLeadSeconds: Double = 4.0,
) {
    companion object {
        val EMPTY = LyricsTimeline(emptyList())
        const val CUSTOM_SHIFT_LEAD_SECONDS = 4.0
        const val MIN_LINE_DURATION = 0.5
    }

    constructor(lyrics: Lyrics, customShiftLeadSeconds: Double = CUSTOM_SHIFT_LEAD_SECONDS) : this(
        lines = lyrics.lines,
        isCustom = lyrics.isCustom,
        customShiftLeadSeconds = customShiftLeadSeconds,
    )

    val isEmpty: Boolean get() = lines.isEmpty()
    val synced: Boolean get() = lines.any { it.isTimed }

    private val timedIndices: List<Int> = lines.indices.filter { lines[it].isTimed }

    /** Desktop `getLineStartTime(idx)` — returns -1 when the line has no timestamp. */
    fun lineStartMs(index: Int): Long {
        if (index < 0 || index >= lines.size) return -1L
        val raw = lines[index].timeMs
        if (raw < 0) return -1L
        if (!isCustom) return raw
        // Desktop shifts custom-lyrics timestamps back by the lead value (seconds -> ms).
        return raw - (customShiftLeadSeconds * 1000).toLong()
    }

    /** Desktop `getLineEndTime(idx)` — start of the next timed line, or +6s for the last one. */
    fun lineEndMs(index: Int): Long {
        val start = lineStartMs(index)
        if (start < 0) return -1L
        for (i in index + 1 until lines.size) {
            val next = lineStartMs(i)
            if (next >= 0) return next
        }
        return start + 6000L
    }

    /**
     * Desktop `updateSyncedLyricsHighlight()`: index of the line that should be
     * highlighted for [positionMs], or -1.
     */
    fun activeLineIndex(positionMs: Long): Int {
        if (timedIndices.isEmpty()) return -1
        val lookAheadMs = if (isCustom) 250L else 0L
        val matchTime = positionMs + lookAheadMs

        for (i in timedIndices.indices) {
            val index = timedIndices[i]
            val current = lineStartMs(index)
            val next = if (i + 1 < timedIndices.size) lineStartMs(timedIndices[i + 1]) else Long.MAX_VALUE
            if (matchTime >= current && matchTime < next) return index
        }
        return -1
    }

    /**
     * Karaoke word progress inside [lineIndex]: returns the index of the active word
     * and a 0..1 fraction through the line (both derived exactly like the desktop
     * `progress`/`currentWordIndex` computation).
     */
    fun wordProgress(lineIndex: Int, positionMs: Long): WordProgress? {
        if (lineIndex < 0 || lineIndex >= lines.size) return null
        val line = lines[lineIndex]
        if (!line.isTimed) return null

        val start = lineStartMs(lineIndex)
        val end = lineEndMs(lineIndex)
        if (start < 0 || end < 0) return null
        val lineDurationMs = maxOf(MIN_LINE_DURATION * 1000, (end - start).toDouble())
        val lookAheadMs = if (isCustom) 250L else 0L
        val progress = ((positionMs + lookAheadMs - start) / lineDurationMs).coerceIn(0.0, 0.999)

        // Enhanced LRC: real word timings win over the evenly-spread approximation.
        if (line.words.isNotEmpty()) {
            var index = 0
            for (i in line.words.indices) {
                if (line.words[i].timeMs <= positionMs + lookAheadMs) index = i
            }
            return WordProgress(
                wordIndex = index,
                wordCount = line.words.size,
                progress = progress,
                words = line.words.map { it.text },
            )
        }

        val words = line.text.split(Regex("""\s+""")).filter { it.isNotBlank() }
        if (words.isEmpty()) return null
        val currentWordIndex = (progress * words.size).toInt().coerceIn(0, words.size - 1)
        return WordProgress(
            wordIndex = currentWordIndex,
            wordCount = words.size,
            progress = progress,
            words = words,
        )
    }

    fun lineIndexAt(positionMs: Long): Int = activeLineIndex(positionMs)
}

data class WordProgress(
    val wordIndex: Int,
    val wordCount: Int,
    val progress: Double,
    val words: List<String>,
)
