package com.riff.android.domain.model

/**
 * Desktop keeps history as a plain array in localStorage: newest first, deduped
 * by track, capped at 100 entries (`playTrack()` in `app.js`).
 */
data class HistoryEntry(
    val trackId: String,
    val playedAt: Long,
)

const val HISTORY_LIMIT = 100
