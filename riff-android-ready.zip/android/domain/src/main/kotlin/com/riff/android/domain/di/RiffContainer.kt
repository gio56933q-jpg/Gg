package com.riff.android.domain.di

import com.riff.android.domain.repo.ArtistInfoProvider
import com.riff.android.domain.repo.ArtistRepository
import com.riff.android.domain.repo.AudioTranscoder
import com.riff.android.domain.repo.DownloadProvider
import com.riff.android.domain.repo.DownloadRepository
import com.riff.android.domain.repo.ExportRepository
import com.riff.android.domain.repo.HistoryRepository
import com.riff.android.domain.repo.LibraryRepository
import com.riff.android.domain.repo.LyricsProvider
import com.riff.android.domain.repo.LyricsRepository
import com.riff.android.domain.repo.MusicSearchProvider
import com.riff.android.domain.repo.PlaybackStateRepository
import com.riff.android.domain.repo.PlaylistRepository
import com.riff.android.domain.repo.RecommendationRepository
import com.riff.android.domain.repo.SearchRepository
import com.riff.android.domain.repo.SettingsRepository
import com.riff.android.domain.repo.StreamResolver

/**
 * Lightweight service locator — the project is small enough that Hilt/Dagger
 * would be overhead (and the task explicitly asks for a lightweight approach).
 * Implemented by `com.riff.android.di.AppContainer`, which is created in
 * `RiffApplication`. ViewModels/features get it through `LocalAppContainer`.
 */
interface RiffContainer {
    val settings: SettingsRepository
    val library: LibraryRepository
    val playlists: PlaylistRepository
    val history: HistoryRepository
    val lyrics: LyricsRepository
    val search: SearchRepository
    val recommendations: RecommendationRepository
    val artists: ArtistRepository
    val downloads: DownloadRepository
    val exports: ExportRepository
    val playbackState: PlaybackStateRepository

    val lyricsProviders: List<LyricsProvider>
    val artistInfoProvider: ArtistInfoProvider
    val searchProviders: List<MusicSearchProvider>
    val streamResolver: StreamResolver
    /** Chooses on-device vs. remote downloads from settings (see `CompositeDownloadProvider`). */
    val downloadProvider: DownloadProvider
    /** The Riff-server backed downloader, used directly when "prefer remote" is on. */
    val remoteDownloadProvider: DownloadProvider
    val transcoder: AudioTranscoder
}
