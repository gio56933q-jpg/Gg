package com.riff.android.domain.model

enum class DownloadState { QUEUED, RUNNING, COMPLETED, FAILED, CANCELED, PAUSED }

/** Desktop equivalent: the `format` chips in the download modal (`mp3/m4a/flac/opus/wav`). */
enum class DownloadFormat(val extension: String) {
    MP3("mp3"), M4A("m4a"), OPUS("opus"), FLAC("flac"), WAV("wav");

    companion object {
        fun fromId(id: String?): DownloadFormat =
            entries.firstOrNull { it.extension.equals(id, ignoreCase = true) } ?: MP3
    }
}

/** Port of the `quality` chips (`--audio-quality`, 0 = best VBR ... 9 = worst). */
enum class DownloadQuality(val id: String, val label: String) {
    BEST("0", "Best"),
    HIGH("2", "High"),
    MEDIUM("5", "Medium"),
    LOW("9", "Low");

    companion object {
        fun fromId(id: String?): DownloadQuality = entries.firstOrNull { it.id == id } ?: BEST
    }
}

data class DownloadTask(
    val trackId: String,
    val state: DownloadState = DownloadState.QUEUED,
    val progress: Float = 0f,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 0L,
    val format: DownloadFormat = DownloadFormat.MP3,
    val quality: DownloadQuality = DownloadQuality.BEST,
    val error: String? = null,
    val attempts: Int = 0,
    val requestedAt: Long = 0L,
    val completedAt: Long? = null,
    val providerId: String = "",
) {
    val isActive: Boolean get() = state == DownloadState.QUEUED || state == DownloadState.RUNNING
}

sealed interface DownloadResult {
    data class Success(val localUri: String, val bytes: Long, val mimeType: String?) : DownloadResult
    data class Failure(val message: String, val retryable: Boolean) : DownloadResult
    data object Canceled : DownloadResult
}
