package com.riff.android.feature

import com.google.common.truth.Truth.assertThat
import com.riff.android.domain.model.Album
import com.riff.android.domain.model.Artist
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import com.riff.android.feature.common.formatDuration
import com.riff.android.feature.library.LibraryTab
import com.riff.android.feature.library.LibraryUiState
import com.riff.android.feature.search.SearchViewModel
import org.junit.Test

/**
 * Screen-level filtering/formatting rules that do not need Android.
 *
 * The library screen's search box filters the *already loaded* list (the repository
 * query is for the whole library), so the filter is UI logic and belongs in a test:
 * a regression here shows up as "typing in the box hides everything".
 */
class LibraryFiltersTest {

    private fun track(id: String, title: String, artist: String, album: String? = null, favorite: Boolean = false) =
        Track(
            id = id,
            title = title,
            artist = artist,
            album = album,
            durationMs = 200_000,
            source = TrackSource.YOUTUBE,
            sourceId = id,
            favorite = favorite,
        )

    private val state = LibraryUiState(
        songs = listOf(
            track("a", "Midnight City", "M83", "Hurry Up, We're Dreaming"),
            track("b", "Intro", "The xx", "xx"),
            track("c", "Shelter", "Porter Robinson", "Worlds"),
        ),
        favorites = listOf(track("a", "Midnight City", "M83", "Hurry Up, We're Dreaming", favorite = true)),
        downloads = listOf(track("c", "Shelter", "Porter Robinson")),
        history = listOf(track("b", "Intro", "The xx")),
        artists = listOf(
            Artist("M83", trackCount = 5, albumCount = 2),
            Artist("Porter Robinson", trackCount = 3, albumCount = 1),
        ),
        albums = listOf(
            Album("Worlds", "Porter Robinson", trackCount = 3),
            Album("xx", "The xx", trackCount = 1),
        ),
    )

    @Test
    fun `the songs tab shows the whole library when no filter is set`() {
        assertThat(state.copy(tab = LibraryTab.SONGS).visible).hasSize(3)
    }

    @Test
    fun `filtering is case insensitive and matches title artist and album`() {
        assertThat(state.copy(tab = LibraryTab.SONGS, query = "m83").visible.map { it.id }).containsExactly("a")
        assertThat(state.copy(tab = LibraryTab.SONGS, query = "SHELTER").visible.map { it.id }).containsExactly("c")
        assertThat(state.copy(tab = LibraryTab.SONGS, query = "worlds").visible.map { it.id }).containsExactly("c")
        assertThat(state.copy(tab = LibraryTab.SONGS, query = "nothing").visible).isEmpty()
    }

    @Test
    fun `each tab filters its own source list`() {
        assertThat(state.copy(tab = LibraryTab.FAVORITES).visible.map { it.id }).containsExactly("a")
        assertThat(state.copy(tab = LibraryTab.DOWNLOADS).visible.map { it.id }).containsExactly("c")
        assertThat(state.copy(tab = LibraryTab.HISTORY).visible.map { it.id }).containsExactly("b")
        // Artists/albums have their own views.
        assertThat(state.copy(tab = LibraryTab.ARTISTS).visible).isEmpty()
        assertThat(state.copy(tab = LibraryTab.ALBUMS).visible).isEmpty()
    }

    @Test
    fun `artist and album filters work on their own lists`() {
        assertThat(state.copy(tab = LibraryTab.ARTISTS, query = "porter").visibleArtists.map { it.name })
            .containsExactly("Porter Robinson")
        assertThat(state.copy(tab = LibraryTab.ALBUMS, query = "xx").visibleAlbums.map { it.name })
            .containsExactly("xx")
        // Album filtering also matches the artist name.
        assertThat(state.copy(tab = LibraryTab.ALBUMS, query = "porter").visibleAlbums.map { it.name })
            .containsExactly("Worlds")
    }

    @Test
    fun `duration formatting matches the player labels`() {
        assertThat(formatDuration(0)).isEqualTo("0:00")
        assertThat(formatDuration(95)).isEqualTo("1:35")
        assertThat(formatDuration(3_600)).isEqualTo("1:00:00")
    }

    @Test
    fun `download formats cover the desktop chips`() {
        assertThat(DownloadFormat.entries.map { it.extension })
            .containsExactly("mp3", "m4a", "opus", "flac", "wav")
        assertThat(DownloadFormat.fromId("FLAC")).isEqualTo(DownloadFormat.FLAC)
        assertThat(DownloadFormat.fromId("unknown")).isEqualTo(DownloadFormat.MP3)
    }

    @Test
    fun `search requires two characters before hitting the network`() {
        // Documents the debounce guard: the ViewModel refuses shorter queries.
        assertThat(SearchViewModel.SEARCH_DEBOUNCE_MS).isAtLeast(200L)
        assertThat(SearchViewModel.RECENT_LIMIT).isAtLeast(5)
    }
}
