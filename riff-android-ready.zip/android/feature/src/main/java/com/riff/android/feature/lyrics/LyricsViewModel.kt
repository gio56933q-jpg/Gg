package com.riff.android.feature.lyrics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.lyrics.LyricsSync
import com.riff.android.domain.model.LyricLine
import com.riff.android.domain.model.Lyrics
import com.riff.android.domain.model.LyricsSettings
import com.riff.android.domain.model.Track
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LyricsUiState(
    val trackId: String? = null,
    val lines: List<LyricLine> = emptyList(),
    val source: String = "none",
    val synced: Boolean = false,
    val isCustom: Boolean = false,
    val loading: Boolean = false,
    val editing: Boolean = false,
    val editorText: String = "",
    /** Raw LRC/plain text, used to seed the custom-lyrics editor. */
    val raw: String = "",
    val message: String? = null,
    val settings: LyricsSettings = LyricsSettings(),
)

/**
 * Lyrics state holder.
 *
 * Desktop equivalent: `loadLyrics()` / `renderSyncedLyrics()` / `openLyricsEditor()` /
 * the sync editor in app.js, backed by `/api/lyrics` (custom file → local cache →
 * lrclib.net) and `/api/save-custom-lyrics`.
 *
 * All fetching and caching happens in `LyricsRepository`; this class only decides
 * *when* to load, which line is active for the current playback position, and the
 * editor state.
 */
class LyricsViewModel(private val container: RiffContainer) : ViewModel() {

    private val _state = MutableStateFlow(LyricsUiState())
    val state: StateFlow<LyricsUiState> = _state.asStateFlow()

    private var loadJob: Job? = null
    private var loadedTrackId: String? = null
    private var loadTrackId: String? = null

    init {
        viewModelScope.launch {
            container.settings.observeSettings().collect { settings ->
                _state.value = _state.value.copy(settings = settings.lyrics)
                // Toggling "online lyrics" should refresh the currently shown track.
                if (loadedTrackId != null) loadedTrackId = null
            }
        }
    }

    /** Called with the currently playing track; reloads only when the track changes. */
    fun onTrackChanged(track: Track?) {
        if (track == null) {
            _state.value = LyricsUiState()
            loadedTrackId = null
            return
        }
        if (track.id == loadedTrackId || track.id == loadTrackId) return
        load(track)
    }

    fun reload() {
        val trackId = _state.value.trackId ?: return
        loadedTrackId = null
        loadTrackId = null
        viewModelScope.launch {
            val track = container.library.get(trackId) ?: return@launch
            load(track)
        }
    }

    private fun load(track: Track) {
        loadJob?.cancel()
        loadTrackId = track.id
        _state.value = _state.value.copy(
            trackId = track.id,
            loading = true,
            message = null,
        )
        loadJob = viewModelScope.launch {
            val allowOnline = _state.value.settings.onlineEnabled
            val lyrics = runCatching { container.lyrics.get(track, allowOnline) }.getOrNull()
            loadedTrackId = track.id
            loadTrackId = null
            _state.value = _state.value.copy(
                lines = lyrics?.lines.orEmpty(),
                raw = lyrics?.raw.orEmpty(),
                source = lyrics?.source?.name?.lowercase() ?: "none",
                synced = lyrics?.synced ?: false,
                isCustom = lyrics?.isCustom ?: false,
                loading = false,
                message = if (lyrics == null || lyrics.isEmpty) NOT_FOUND_MESSAGE else null,
            )
        }
    }

    /** Line index for the given playback position (desktop `updateSyncedLyrics()`). */
    fun activeLineIndex(positionMs: Long): Int = activeLineIn(_state.value.lines, positionMs)

    fun openEditor() {
        _state.value = _state.value.copy(editing = true, editorText = _state.value.raw)
    }

    fun updateEditorText(text: String) {
        _state.value = _state.value.copy(editorText = text)
    }

    fun cancelEditor() {
        _state.value = _state.value.copy(editing = false, editorText = "")
    }

    fun saveEditor() {
        val trackId = _state.value.trackId ?: return
        val text = _state.value.editorText
        viewModelScope.launch {
            val track = container.library.get(trackId) ?: return@launch
            val lyrics: Lyrics = container.lyrics.saveCustom(track, text)
            _state.value = _state.value.copy(
                editing = false,
                lines = lyrics.lines,
                raw = text,
                isCustom = true,
                source = "custom",
                synced = lyrics.synced,
                message = if (lyrics.isEmpty) "saved (no timestamped lines found)" else "custom lyrics saved",
            )
        }
    }

    fun deleteCustom() {
        val trackId = _state.value.trackId ?: return
        viewModelScope.launch {
            val track = container.library.get(trackId) ?: return@launch
            container.lyrics.deleteCustom(track)
            loadedTrackId = null
            _state.value = _state.value.copy(message = "custom lyrics deleted")
            load(track)
        }
    }

    /** `CUSTOM_SHIFT_LEAD_SECONDS` from the desktop sync editor: shift every timestamp. */
    fun shiftCustom(seconds: Double) {
        val shifted = shiftTimestamps(_state.value.editorText, seconds)
        _state.value = _state.value.copy(editorText = shifted)
        saveEditor()
    }

    fun dismissMessage() {
        _state.value = _state.value.copy(message = null)
    }

    companion object {
        const val NOT_FOUND_MESSAGE = "no lyrics found for this track"

        /** Delegates to the domain rule; kept here so the UI has a single import. */
        fun activeLineIn(lines: List<LyricLine>, positionMs: Long): Int =
            LyricsSync.activeLineIndex(lines, positionMs)

        /** Port of the desktop "shift lyrics" buttons (default +4 s lead). */
        fun shiftTimestamps(lrc: String, seconds: Double = LyricsSync.CUSTOM_SHIFT_LEAD_SECONDS): String =
            LyricsSync.shiftTimestamps(lrc, seconds)

        const val LEAD_MS = LyricsSync.LEAD_MS
    }
}
