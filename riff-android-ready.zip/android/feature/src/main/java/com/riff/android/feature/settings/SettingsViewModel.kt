package com.riff.android.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riff.android.core.audio.AudioEffectsController
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.model.RiffSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val settings: RiffSettings = RiffSettings(),
    val storageBytes: Long = 0L,
    val seenRecommendations: Int = 0,
    val message: String? = null,
    val busy: Boolean = false,
)

/**
 * Settings state holder.
 *
 * Desktop equivalent: the whole Settings view in app.js — the theme customiser
 * (`generateM3Palette` inputs: mode, accent, style, intensity, brightness), the audio
 * & HQ sections, the lyrics flags, the advanced `getAdv()` toggles, the Discord RPC /
 * updater entries (not portable, documented instead) and the cache tools
 * (`/api/clear-offline-library`).
 */
class SettingsViewModel(
    private val container: RiffContainer,
    private val effects: AudioEffectsController?,
) : ViewModel() {

    private val local = MutableStateFlow(LocalState())

    private data class LocalState(
        val storageBytes: Long = 0L,
        val message: String? = null,
        val busy: Boolean = false,
    )

    val state: StateFlow<SettingsUiState> = combine(
        container.settings.observeSettings(),
        container.recommendations.observeRecentlyRecommendedCount(),
        local,
    ) { settings, seen, localState ->
        SettingsUiState(
            settings = settings,
            storageBytes = localState.storageBytes,
            seenRecommendations = seen,
            message = localState.message,
            busy = localState.busy,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    init {
        refreshStorage()
    }

    fun refreshStorage() {
        viewModelScope.launch {
            val bytes = runCatching { container.library.totalDownloadBytes() }.getOrDefault(0L)
            local.value = local.value.copy(storageBytes = bytes)
        }
    }

    fun dismissMessage() {
        local.value = local.value.copy(message = null)
    }

    // --- theme ---------------------------------------------------------------

    fun setAccent(hex: String) = updateSettings { container.settings.setTheme(it.theme.copy(accent = hex)) }

    fun setThemeMode(mode: com.riff.android.domain.model.ThemeMode) =
        updateSettings { container.settings.setTheme(it.theme.copy(mode = mode)) }

    fun setPaletteStyle(style: com.riff.android.domain.model.PaletteStyle) =
        updateSettings { container.settings.setTheme(it.theme.copy(paletteStyle = style)) }

    fun setIntensity(value: Int) = updateSettings {
        container.settings.setTheme(it.theme.copy(intensity = value.coerceIn(-50, 50)))
    }

    fun setBrightness(value: Int) = updateSettings {
        container.settings.setTheme(it.theme.copy(brightness = value.coerceIn(-100, 100)))
    }

    fun setMeshBrightness(value: Int) = updateSettings {
        container.settings.setTheme(it.theme.copy(meshBrightness = value.coerceIn(0, 200)))
    }

    fun setDynamicColor(enabled: Boolean) =
        updateSettings { container.settings.setTheme(it.theme.copy(dynamicColorFromArtwork = enabled)) }

    // --- playback / audio ----------------------------------------------------

    fun setVolume(volume: Float) = updateSettings {
        container.settings.setPlayback(it.playback.copy(volume = volume.coerceIn(0f, 1f)))
    }

    fun setHqEnabled(enabled: Boolean) {
        viewModelScope.launch {
            effects?.setHqEnabled(enabled) ?: container.settings.setHq(container.settings.current().hq, enabled)
            local.value = local.value.copy(message = if (enabled) "HQ engine on" else "HQ engine off")
        }
    }

    fun setSkipSilence(enabled: Boolean) = updateSettings {
        container.settings.setPlayback(it.playback.copy(skipSilence = enabled))
    }

    fun setCrossfade(ms: Long) = updateSettings {
        container.settings.setPlayback(it.playback.copy(crossfadeMs = ms.coerceIn(0L, 12_000L)))
    }

    // --- lyrics --------------------------------------------------------------

    fun setLyricsOnline(enabled: Boolean) = updateSettings {
        container.settings.setLyrics(it.lyrics.copy(onlineEnabled = enabled))
    }

    fun setLyricsAutoScroll(enabled: Boolean) = updateSettings {
        container.settings.setLyrics(it.lyrics.copy(autoScroll = enabled))
    }

    fun setLyricsKaraokeWords(enabled: Boolean) = updateSettings {
        container.settings.setLyrics(it.lyrics.copy(karaokeWords = enabled))
    }

    fun setLyricsWordMode(enabled: Boolean) = updateSettings {
        container.settings.setLyrics(it.lyrics.copy(showWordModeByDefault = enabled))
    }

    // --- advanced ------------------------------------------------------------

    fun setReducedMotion(enabled: Boolean) = updateSettings {
        container.settings.setAdvanced(it.advanced.copy(reducedMotion = enabled))
    }

    fun setAutoExtendWave(enabled: Boolean) = updateSettings {
        container.settings.setAdvanced(it.advanced.copy(autoExtendWave = enabled))
    }

    fun setDownloadOverWifiOnly(enabled: Boolean) = updateSettings {
        container.settings.setAdvanced(it.advanced.copy(downloadOverWifiOnly = enabled))
    }

    fun setEmbedMetadata(enabled: Boolean) = updateSettings {
        container.settings.setAdvanced(it.advanced.copy(embedMetadataAndArtwork = enabled))
    }

    /** Documents the limitation instead of pretending the flag works. */
    fun setTranscodeDownloads(enabled: Boolean) = updateSettings {
        container.settings.setAdvanced(it.advanced.copy(transcodeDownloads = enabled))
    }

    // --- backend -------------------------------------------------------------

    fun setBackendMode(mode: com.riff.android.domain.model.BackendMode) = updateSettings {
        container.settings.setBackend(it.backend.copy(mode = mode))
    }

    fun setBackendUrl(url: String) = updateSettings {
        container.settings.setBackend(it.backend.copy(baseUrl = url.trim()))
    }

    fun setPreferRemoteDownloads(enabled: Boolean) = updateSettings {
        container.settings.setBackend(it.backend.copy(preferRemoteDownloads = enabled))
    }

    // --- library tools -------------------------------------------------------

    fun clearDownloads() {
        viewModelScope.launch {
            local.value = local.value.copy(busy = true)
            container.library.clearDownloads()
            container.downloads.clearFinished()
            val bytes = container.library.totalDownloadBytes()
            local.value = local.value.copy(busy = false, storageBytes = bytes, message = "offline library cleared")
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            container.library.clearHistory()
            local.value = local.value.copy(message = "listening history cleared")
        }
    }

    /** Desktop "reset recommendations" (`/api/vibe-reset` equivalent). */
    fun resetRecommendations() {
        viewModelScope.launch {
            container.recommendations.resetSeen()
            local.value = local.value.copy(message = "My Wave will start fresh")
        }
    }

    fun clearSearchCache() {
        viewModelScope.launch {
            container.search.clearCache()
            local.value = local.value.copy(message = "search cache cleared")
        }
    }

    private fun updateSettings(block: suspend (RiffSettings) -> Unit) {
        viewModelScope.launch {
            runCatching {
                val current = container.settings.current()
                block(current)
            }
        }
    }
}
