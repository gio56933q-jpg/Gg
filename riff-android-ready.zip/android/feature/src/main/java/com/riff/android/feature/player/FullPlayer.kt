package com.riff.android.feature.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.audio.AudioEffectsController
import com.riff.android.core.ui.RiffArtwork
import com.riff.android.core.ui.RiffChip
import com.riff.android.core.ui.RiffEqualizerBars
import com.riff.android.core.ui.RiffFavoriteButton
import com.riff.android.core.ui.RiffSpinner
import com.riff.android.domain.model.AudioSettings
import com.riff.android.domain.model.HqEngine
import com.riff.android.domain.model.HqPresets
import com.riff.android.domain.model.RepeatMode
import com.riff.android.domain.model.RiffPresets
import com.riff.android.domain.model.Track
import com.riff.android.feature.common.LocalAppContainer
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.common.LocalRiffEffects
import com.riff.android.feature.common.PlaylistPickerSheet
import com.riff.android.feature.common.formatDuration
import com.riff.android.feature.lyrics.LyricsPane
import com.riff.android.feature.lyrics.LyricsViewModel
import com.riff.android.feature.common.riffViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Full player.
 *
 * Desktop equivalent: the fixed playbar expanded — the desktop always shows
 * artwork + transport + scrubber + visualiser + volume in the footer and the lyrics
 * in the right panel. On a phone those are three surfaces (player, queue, lyrics),
 * so this screen hosts all of them:
 *
 *  - artwork (tap = lyrics) with the vinyl/glow treatment when the audio is processed,
 *  - title/artist/favourite + download + "add to playlist",
 *  - scrubber with elapsed/total (drag to seek, like the desktop `#scrubber`),
 *  - shuffle / previous / play-pause / next / repeat (repeat cycles off → all → one,
 *    the same cycle the desktop used),
 *  - a sheet for speed/pitch/effects (`state.audioSettings`) and the HQ switch
 *    (`state.hqSettings`) driven by [AudioEffectsController],
 *  - volume slider (desktop `#volume-slider`).
 */
@Composable
fun FullPlayer(onClose: () -> Unit) {
    val connection = LocalPlaybackConnection.current
    val player by connection.state.collectAsStateWithLifecycle()
    val track = player.track
    val container = LocalAppContainer.current
    val effects = LocalRiffEffects.current

    val lyricsViewModel = riffViewModel { vmContainer -> LyricsViewModel(vmContainer) }
    val lyricsState by lyricsViewModel.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var showLyrics by remember { mutableStateOf(false) }
    var showEffects by remember { mutableStateOf(false) }
    var showPlaylists by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var dragPosition by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(player.track?.id) { lyricsViewModel.onTrackChanged(player.track) }

    // Repaint the position every 500 ms only while this screen is visible; the service
    // keeps playing regardless (no long-running work in the composable).
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(player.isPlaying, player.track?.id) {
        while (player.isPlaying) {
            delay(500)
            tick++
        }
    }
    val positionMs = if (dragging) dragPosition.toLong() else player.positionMs + tick * 0

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize()) {
            // Accent mesh derived from the current accent colour (desktop #bg-mesh-*).
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                                MaterialTheme.colorScheme.background,
                            ),
                        ),
                    ),
            )

            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close player")
                    }
                    Text(
                        text = contextLabel(player.context),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    IconButton(onClick = { showEffects = true }) {
                        Icon(Icons.Filled.Tune, contentDescription = "Audio effects")
                    }
                }

                if (track == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("nothing playing", style = MaterialTheme.typography.bodyMedium)
                    }
                    return@Column
                }

                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    if (showLyrics) {
                        Box(Modifier.fillMaxWidth().height(420.dp)) {
                            LyricsPane(
                                track = track,
                                positionMs = positionMs,
                                state = lyricsState,
                                onOpenEditor = lyricsViewModel::openEditor,
                                onDeleteCustom = lyricsViewModel::deleteCustom,
                                onSaveEditor = lyricsViewModel::saveEditor,
                                onCancelEditor = lyricsViewModel::cancelEditor,
                                onEditorChange = lyricsViewModel::updateEditorText,
                                onReload = lyricsViewModel::reload,
                            )
                        }
                    } else {
                        ArtworkStage(
                            track = track,
                            isPlaying = player.isPlaying,
                            onClick = { showLyrics = true },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp).padding(top = 12.dp),
                        )
                    }

                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                track.title,
                                style = MaterialTheme.typography.headlineSmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    track.artist,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                if (player.waveActive) {
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "wave",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                    )
                                }
                            }
                        }
                        RiffFavoriteButton(
                            favorite = track.favorite,
                            onClick = {
                                scope.launch {
                                    val updated = container.library.setFavorite(track, !track.favorite)
                                    connection.updateCurrentTrack(updated)
                                }
                                Unit
                            },
                        )
                        IconButton(onClick = { showLyrics = !showLyrics }) {
                            Icon(Icons.Filled.LibraryMusic, contentDescription = "Lyrics")
                        }
                        IconButton(onClick = { showPlaylists = true }) {
                            Icon(Icons.Filled.Add, contentDescription = "Add to playlist")
                        }
                        if (!track.isDownloaded) {
                            IconButton(onClick = { scope.launch { container.downloads.enqueue(track) } }) {
                                Icon(Icons.Filled.Download, contentDescription = "Download")
                            }
                        }
                    }

                    Scrubber(
                        positionMs = positionMs,
                        durationMs = if (player.durationMs > 0) player.durationMs else track.durationMs,
                        onDrag = { value ->
                            dragging = true
                            dragPosition = value
                        },
                        onCommit = { value ->
                            dragging = false
                            connection.seekTo(value.toLong())
                        },
                    )

                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { connection.setShuffle(!player.shuffle) }) {
                            Icon(
                                Icons.Filled.Shuffle,
                                contentDescription = "Shuffle",
                                tint = if (player.shuffle) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { connection.previous() }) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
                        }
                        Box(contentAlignment = Alignment.Center) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(72.dp).clickable { connection.togglePlayPause() },
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (player.isBuffering) {
                                        RiffSpinner(size = 30.dp, color = MaterialTheme.colorScheme.onPrimary)
                                    } else {
                                        Icon(
                                            if (player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                            contentDescription = if (player.isPlaying) "Pause" else "Play",
                                            tint = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.size(36.dp),
                                        )
                                    }
                                }
                            }
                        }
                        IconButton(onClick = { connection.next() }) {
                            Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
                        }
                        IconButton(onClick = { connection.cycleRepeat() }) {
                            Icon(
                                if (player.repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                                contentDescription = "Repeat ${player.repeatMode.name.lowercase()}",
                                tint = if (player.repeatMode != RepeatMode.OFF) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RiffEqualizerBars(isPlaying = player.isPlaying)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            "vol",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Slider(
                            value = player.volume,
                            onValueChange = { connection.setVolume(it) },
                            valueRange = 0f..1f,
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                        )
                    }

                    player.error?.let { error ->
                        Text(
                            error,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                        )
                    }

                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    if (showEffects) {
        EffectsSheet(current = player, effects = effects, onDismiss = { showEffects = false })
    }
    if (showPlaylists && track != null) {
        PlaylistPickerSheet(track = track, onDismiss = { showPlaylists = false })
    }
}

/**
 * Desktop `#right-panel-cover` on the player stage: artwork with a spinning vinyl
 * disc behind it and a pulsing glow while playing (`.vinyl-spin`, `.ambient-glow`).
 */
@Composable
private fun ArtworkStage(
    track: Track,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val glow by animateFloatAsState(
        targetValue = if (isPlaying) 1f else 0.4f,
        animationSpec = tween(600),
        label = "glow",
    )

    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(300.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.22f * glow),
                            MaterialTheme.colorScheme.background,
                        ),
                    ),
                ),
        )
        RiffArtwork(
            track.artworkUri,
            Modifier.size(280.dp).clickable(onClick = onClick),
            cornerRadius = 24.dp,
            contentDescription = track.title,
        )
        // Vinyl disc peeking from behind the artwork, like the desktop overlay.
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .align(Alignment.BottomEnd)
                .padding(6.dp),
            contentAlignment = Alignment.Center,
        ) {
            RiffEqualizerBars(isPlaying = isPlaying, bars = 3, height = 16.dp)
        }
    }
}

/** Scrubber — the desktop `#scrubber` with its `time-current` / `time-total` labels. */
@Composable
private fun Scrubber(
    positionMs: Long,
    durationMs: Long,
    onDrag: (Float) -> Unit,
    onCommit: (Float) -> Unit,
) {
    val total = durationMs.coerceAtLeast(1L).toFloat()
    var local by remember { mutableFloatStateOf(positionMs.toFloat()) }
    LaunchedEffect(positionMs, durationMs) {
        if (local != positionMs.toFloat()) local = positionMs.toFloat()
    }

    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Slider(
            value = local.coerceIn(0f, total),
            onValueChange = {
                local = it
                onDrag(it)
            },
            onValueChangeFinished = { onCommit(local) },
            valueRange = 0f..total,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatDuration((local / 1000).toLong()), style = MaterialTheme.typography.labelMedium)
            Text(formatDuration(durationMs / 1000), style = MaterialTheme.typography.labelMedium)
        }
    }
}

/**
 * Effects sheet: preset chips (exactly the desktop `defaultPresets`), the HQ switch and
 * the four effect sliders from `state.audioSettings`. Every change goes through
 * [AudioEffectsController], which persists it and pushes it into the DSP chain — the
 * playback service never has to be touched.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun EffectsSheet(
    current: com.riff.android.core.player.PlayerUiState,
    effects: AudioEffectsController?,
    onDismiss: () -> Unit,
) {
    val connection = LocalPlaybackConnection.current
    val scope = rememberCoroutineScope()

    androidx.compose.material3.ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp),
        ) {
            Text("Audio", style = MaterialTheme.typography.titleLarge)

            if (effects == null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "the audio effects engine is not attached (playback was started outside the app)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                return@Column
            }

            val audio by effects.audioSettings.collectAsStateWithLifecycle()
            val hqEnabled by effects.hqEnabled.collectAsStateWithLifecycle()
            val activePreset by effects.activePresetId.collectAsStateWithLifecycle()

            Spacer(Modifier.height(12.dp))
            Text("Presets", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            // The desktop preset rail scrolled horizontally; wrapped chip rows here.
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RiffPresets.BUILT_IN.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { preset ->
                            RiffChip(
                                label = preset.name,
                                selected = preset.id == activePreset,
                                onClick = { scope.launch { effects.applyPreset(preset) } },
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            EffectSlider("speed (keeps pitch)", audio.speed, 0.5f..2f) { value ->
                scope.launch { effects.updateAudio(audio.copy(speed = value)) }
            }
            EffectSlider("speed (tape pitch)", audio.speedPitch, 0.5f..2f) { value ->
                scope.launch { effects.updateAudio(audio.copy(speedPitch = value)) }
            }
            EffectSlider("pitch (semitones)", audio.pitch.toFloat(), -12f..12f) { value ->
                scope.launch { effects.updateAudio(audio.copy(pitch = value.toInt())) }
            }
            EffectSlider("reverb", audio.reverb.toFloat(), 0f..100f) { value ->
                scope.launch { effects.updateAudio(audio.copy(reverb = value.toInt())) }
            }
            EffectSlider("echo", audio.echo.toFloat(), 0f..100f) { value ->
                scope.launch { effects.updateAudio(audio.copy(echo = value.toInt())) }
            }
            EffectSlider("distortion", audio.distortion.toFloat(), 0f..100f) { value ->
                scope.launch { effects.updateAudio(audio.copy(distortion = value.toInt())) }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HQ engine", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "compressor + bass/vocal/air shelves (desktop Web Audio HQ chain)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = hqEnabled,
                    onCheckedChange = { enabled -> scope.launch { effects.setHqEnabled(enabled) } },
                )
            }

            val hq by effects.hqSettings.collectAsStateWithLifecycle()
            if (hqEnabled) {
                Spacer(Modifier.height(8.dp))
                Text("HQ preset", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HqPresets.ALL.forEach { preset ->
                        RiffChip(
                            label = preset.label,
                            selected = hq.preset == preset.id,
                            onClick = {
                                scope.launch { effects.updateHq(HqPresets.apply(hq, preset.id), enabled = true) }
                            },
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("Engine", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HqEngine.entries.forEach { engine ->
                        RiffChip(
                            label = engine.label,
                            selected = hq.engine == engine,
                            onClick = { scope.launch { effects.updateHq(hq.copy(engine = engine), enabled = true) } },
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                EffectSlider("vocal focus", hq.vocal.toFloat(), -100f..100f) { value ->
                    scope.launch { effects.updateHq(hq.copy(vocal = value.toInt(), preset = "custom"), enabled = true) }
                }
                EffectSlider("air", hq.air.toFloat(), -100f..100f) { value ->
                    scope.launch { effects.updateHq(hq.copy(air = value.toInt(), preset = "custom"), enabled = true) }
                }
                EffectSlider("bass", hq.bass.toFloat(), -100f..100f) { value ->
                    scope.launch { effects.updateHq(hq.copy(bass = value.toInt(), preset = "custom"), enabled = true) }
                }
            }

            Spacer(Modifier.height(12.dp))
            TextButton(
                onClick = {
                    scope.launch { effects.updateAudio(AudioSettings.DEFAULT) }
                    connection.setPlaybackParameters(androidx.media3.common.PlaybackParameters.DEFAULT)
                },
            ) { Text("Reset effects") }

            Text(
                "Timbre differences vs. the desktop convolver are documented in PORTING.md.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (current.speed != 1f || current.pitch != 1f) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "engine: ${"%.2f".format(current.speed)}x @ pitch ${"%.2f".format(current.pitch)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

@Composable
private fun EffectSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            Text(
                if (range.endInclusive > 20f) "%.0f".format(value) else "%.2f".format(value),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
        )
    }
}

/** Label for the queue origin, mirroring the desktop queue header. */
private fun contextLabel(context: com.riff.android.domain.model.PlaybackContext): String = when (context) {
    is com.riff.android.domain.model.PlaybackContext.PlaylistContext -> "Playlist • ${context.name}"
    is com.riff.android.domain.model.PlaybackContext.ArtistContext -> "Artist • ${context.name}"
    com.riff.android.domain.model.PlaybackContext.MyWave -> "My Wave"
    com.riff.android.domain.model.PlaybackContext.Favorites -> "Favorites"
    com.riff.android.domain.model.PlaybackContext.Downloads -> "Downloaded"
    com.riff.android.domain.model.PlaybackContext.History -> "History"
    com.riff.android.domain.model.PlaybackContext.Library -> "Library"
    com.riff.android.domain.model.PlaybackContext.Search -> "Search results"
    com.riff.android.domain.model.PlaybackContext.Queue -> "Queue"
    com.riff.android.domain.model.PlaybackContext.None -> "Riff"
}
