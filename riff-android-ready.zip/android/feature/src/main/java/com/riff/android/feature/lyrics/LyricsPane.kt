package com.riff.android.feature.lyrics

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.riff.android.core.ui.RiffEmptyHint
import com.riff.android.core.ui.RiffSpinner
import com.riff.android.domain.model.Track

/**
 * Lyrics pane.
 *
 * Desktop equivalent: the right-hand panel's lyrics box (`#lyrics-container`) with its
 * "Edit" / "Sync" header, the karaoke-style current-line highlight and the automatic
 * scrolling (`updateSyncedLyrics()` + `scrollLyricsToLine()`).
 *
 * Scroll-sync uses `LazyListState.animateScrollToItem` whenever the active line
 * changes; the user can still scroll freely, in which case the next highlight change
 * re-centres the view (the desktop did the same with `scrollIntoView`).
 */
@Composable
fun LyricsPane(
    track: Track?,
    positionMs: Long,
    state: LyricsUiState,
    onOpenEditor: () -> Unit,
    onDeleteCustom: () -> Unit,
    onSaveEditor: () -> Unit,
    onCancelEditor: () -> Unit,
    onEditorChange: (String) -> Unit,
    onReload: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val activeIndex = LyricsViewModel.activeLineIn(state.lines, positionMs)
    val listState = rememberLazyListState()

    LaunchedEffect(activeIndex, state.settings.autoScroll) {
        if (activeIndex >= 0 && state.settings.autoScroll) {
            listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
        }
    }

    Column(modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Lyrics",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            if (state.synced) {
                Text(
                    "synced",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.width(8.dp))
            }
            TextButton(onClick = onOpenEditor) { Text("Edit") }
            if (state.isCustom) {
                TextButton(onClick = onDeleteCustom) { Text("Delete") }
            }
        }

        when {
            track == null -> RiffEmptyHint("nothing playing")
            state.loading -> Box(Modifier.fillMaxWidth().padding(top = 24.dp), contentAlignment = Alignment.Center) {
                RiffSpinner(size = 28.dp)
            }

            state.lines.isEmpty() -> Column(
                Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                RiffEmptyHint(state.message ?: LyricsViewModel.NOT_FOUND_MESSAGE)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onReload) { Text("Search again") }
                    TextButton(onClick = onOpenEditor) { Text("Paste lyrics") }
                }
                if (!state.settings.onlineEnabled) {
                    Text(
                        "online lyrics are disabled in Settings",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            else -> LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 80.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                itemsIndexed(state.lines) { index, line ->
                    val isActive = index == activeIndex
                    val color by animateColorAsState(
                        targetValue = if (isActive) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        label = "lyric-color",
                    )
                    Text(
                        text = line.text.ifBlank { "…" },
                        style = if (isActive) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge,
                        color = color,
                        fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                        textAlign = TextAlign.Start,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                }
            }
        }
    }

    if (state.editing) {
        LyricsEditorDialog(
            text = state.editorText,
            onChange = onEditorChange,
            onSave = onSaveEditor,
            onCancel = onCancelEditor,
        )
    }
}

/**
 * Custom lyrics editor — the desktop `lyrics-editor-modal` (a big textarea plus the
 * "Sync" tools). Saving stores the text under the track key and never gets overwritten
 * by a provider result.
 */
@Composable
private fun LyricsEditorDialog(
    text: String,
    onChange: (String) -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Custom lyrics") },
        text = {
            Column {
                Text(
                    "Paste LRC lines like [00:12.34] to get synced highlighting. " +
                        "Custom lyrics always win over fetched ones.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = onChange,
                    modifier = Modifier.fillMaxWidth().height(280.dp),
                    placeholder = { Text("[00:12.34] first line\nthe rest as plain text") },
                )
            }
        },
        confirmButton = { TextButton(onClick = onSave) { Text("Save") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

/** Compact one-line preview used by the mini player / queue rows. */
@Composable
fun LyricsPreviewLine(state: LyricsUiState, positionMs: Long, modifier: Modifier = Modifier) {
    val index = LyricsViewModel.activeLineIn(state.lines, positionMs)
    val line = state.lines.getOrNull(index)?.text.orEmpty()
    if (line.isNotBlank()) {
        Text(
            line,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            modifier = modifier.clickable(enabled = false) {},
        )
    }
}
