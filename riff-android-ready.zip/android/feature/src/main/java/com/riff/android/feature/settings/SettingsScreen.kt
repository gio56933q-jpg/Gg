package com.riff.android.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.theme.RiffPalette
import com.riff.android.core.ui.RiffChip
import com.riff.android.core.ui.RiffSectionHeader
import com.riff.android.domain.model.BackendMode
import com.riff.android.domain.model.PaletteStyle
import com.riff.android.domain.model.ThemeMode
import com.riff.android.feature.common.LocalRiffEffects
import com.riff.android.feature.common.RiffConfirmDialog
import com.riff.android.feature.common.riffViewModel

/**
 * Settings.
 *
 * Desktop equivalent: the Settings page in app.js, section by section:
 *  - **Appearance** — theme mode, accent swatches, palette style, intensity/brightness
 *    (the `generateM3Palette` inputs), mesh brightness and cover-colour theming,
 *  - **Playback / Audio** — volume, HQ engine, skip silence (the desktop effects are
 *    configured from the player's effects sheet),
 *  - **Lyrics** — online lookup, auto-scroll, karaoke word mode,
 *  - **Downloads** — Wi-Fi only, metadata/artwork embedding, transcoding (documented
 *    limitation),
 *  - **Backend** — on-device extraction vs. a Riff server (the desktop's own HTTP API),
 *  - **Library** — storage used, clear offline library / history, reset My Wave,
 *  - **About** — what this port is and where the desktop-only features are documented.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen() {
    val effects = LocalRiffEffects.current
    val viewModel = riffViewModel { container -> SettingsViewModel(container, effects) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val settings = state.settings

    var confirmClearDownloads by remember { mutableStateOf(false) }
    var confirmClearHistory by remember { mutableStateOf(false) }
    var backendUrl by remember(settings.backend.baseUrl) { mutableStateOf(settings.backend.baseUrl) }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            RiffSectionHeader(title = "Settings", hint = "riff for android")
        }
        state.message?.let { message ->
            item {
                Text(
                    message,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.dismissMessage() }
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                )
            }
        }

        // --- appearance ------------------------------------------------------
        item { SectionTitle("Appearance") }
        item {
            SettingRow("Theme") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        RiffChip(
                            label = mode.id.replaceFirstChar { it.uppercase() },
                            selected = settings.theme.mode == mode,
                            onClick = { viewModel.setThemeMode(mode) },
                        )
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
                Text("Accent", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    RiffPalette.ACCENT_SWATCHES.forEach { hex ->
                        Swatch(
                            hex = hex,
                            selected = settings.theme.accent.equals(hex, ignoreCase = true),
                            onClick = { viewModel.setAccent(hex) },
                        )
                    }
                }
            }
        }
        item {
            SettingRow("Palette style") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaletteStyle.entries.forEach { style ->
                        RiffChip(
                            label = style.label,
                            selected = settings.theme.paletteStyle == style,
                            onClick = { viewModel.setPaletteStyle(style) },
                        )
                    }
                }
            }
        }
        item {
            SliderSetting(
                label = "Intensity",
                value = settings.theme.intensity.toFloat(),
                range = -50f..50f,
                valueLabel = "${settings.theme.intensity}",
                onChange = { viewModel.setIntensity(it.toInt()) },
            )
        }
        item {
            SliderSetting(
                label = "Brightness",
                value = settings.theme.brightness.toFloat(),
                range = -100f..100f,
                valueLabel = "${settings.theme.brightness}",
                onChange = { viewModel.setBrightness(it.toInt()) },
            )
        }
        item {
            SliderSetting(
                label = "Mesh brightness",
                value = settings.theme.meshBrightness.toFloat(),
                range = 0f..200f,
                valueLabel = "${settings.theme.meshBrightness}%",
                onChange = { viewModel.setMeshBrightness(it.toInt()) },
            )
        }
        item {
            SettingRow(
                title = "Accent from artwork",
                subtitle = "recolour the theme from the current cover (desktop extractDominantColor)",
            ) {
                Switch(
                    checked = settings.theme.dynamicColorFromArtwork,
                    onCheckedChange = viewModel::setDynamicColor,
                )
            }
        }

        // --- playback --------------------------------------------------------
        item { SectionTitle("Playback") }
        item {
            SliderSetting(
                label = "Volume",
                value = settings.playback.volume,
                range = 0f..1f,
                valueLabel = "${(settings.playback.volume * 100).toInt()}%",
                onChange = viewModel::setVolume,
            )
        }
        item {
            SettingRow(
                title = "HQ engine",
                subtitle = "compressor + bass/vocal/air shelves (desktop HQ Web Audio chain)",
            ) {
                Switch(checked = settings.playback.hqEnabled, onCheckedChange = viewModel::setHqEnabled)
            }
        }
        item {
            SettingRow(
                title = "Skip silence",
                subtitle = "ExoPlayer skip-silence (the desktop had no equivalent)",
            ) {
                Switch(checked = settings.playback.skipSilence, onCheckedChange = viewModel::setSkipSilence)
            }
        }
        item {
            SliderSetting(
                label = "Crossfade",
                value = settings.playback.crossfadeMs.toFloat(),
                range = 0f..12_000f,
                valueLabel = if (settings.playback.crossfadeMs == 0L) "off" else "${settings.playback.crossfadeMs / 1000}s",
                onChange = { viewModel.setCrossfade(it.toLong()) },
            )
        }

        // --- lyrics ----------------------------------------------------------
        item { SectionTitle("Lyrics") }
        item {
            SettingRow(
                title = "Look up lyrics online",
                subtitle = "lrclib.net; cached on device afterwards (desktop /api/lyrics)",
            ) {
                Switch(checked = settings.lyrics.onlineEnabled, onCheckedChange = viewModel::setLyricsOnline)
            }
        }
        item {
            SettingRow(title = "Auto-scroll synced lyrics") {
                Switch(checked = settings.lyrics.autoScroll, onCheckedChange = viewModel::setLyricsAutoScroll)
            }
        }
        item {
            SettingRow(title = "Karaoke word highlighting") {
                Switch(checked = settings.lyrics.karaokeWords, onCheckedChange = viewModel::setLyricsKaraokeWords)
            }
        }
        item {
            SettingRow(
                title = "Word mode by default",
                subtitle = "show the enhanced-LRC word view when opening lyrics",
            ) {
                Switch(checked = settings.lyrics.showWordModeByDefault, onCheckedChange = viewModel::setLyricsWordMode)
            }
        }

        // --- downloads -------------------------------------------------------
        item { SectionTitle("Downloads") }
        item {
            SettingRow(
                title = "Download over Wi-Fi only",
                subtitle = "WorkManager waits for an unmetered network",
            ) {
                Switch(
                    checked = settings.advanced.downloadOverWifiOnly,
                    onCheckedChange = viewModel::setDownloadOverWifiOnly,
                )
            }
        }
        item {
            SettingRow(
                title = "Embed metadata & artwork",
                subtitle = "writes tags with jaudiotagger after the download",
            ) {
                Switch(
                    checked = settings.advanced.embedMetadataAndArtwork,
                    onCheckedChange = viewModel::setEmbedMetadata,
                )
            }
        }
        item {
            SettingRow(
                title = "Transcode downloads (unavailable)",
                subtitle = "no ffmpeg is bundled; streams keep their source container. See PORTING.md.",
            ) {
                Switch(
                    checked = settings.advanced.transcodeDownloads,
                    onCheckedChange = viewModel::setTranscodeDownloads,
                )
            }
        }

        // --- backend ---------------------------------------------------------
        item { SectionTitle("Backend") }
        item {
            SettingRow(
                title = "Music backend",
                subtitle = when (settings.backend.mode) {
                    BackendMode.ON_DEVICE -> "extract streams on the device (NewPipeExtractor)"
                    BackendMode.RIFF_SERVER -> "use a Riff server's API (yt-dlp + ffmpeg)"
                    BackendMode.AUTO -> "prefer the Riff server, fall back to on-device"
                },
            ) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BackendMode.entries.forEach { mode ->
                        RiffChip(
                            label = when (mode) {
                                BackendMode.ON_DEVICE -> "On device"
                                BackendMode.RIFF_SERVER -> "Riff server"
                                BackendMode.AUTO -> "Auto"
                            },
                            selected = settings.backend.mode == mode,
                            onClick = { viewModel.setBackendMode(mode) },
                        )
                    }
                }
            }
        }
        if (settings.backend.mode != BackendMode.ON_DEVICE) {
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
                    OutlinedTextField(
                        value = backendUrl,
                        onValueChange = { backendUrl = it },
                        label = { Text("Server URL") },
                        placeholder = { Text("http://127.0.0.1:38472") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { viewModel.setBackendUrl(backendUrl) }) { Text("Save") }
                        Text(
                            "run `node server.js` on the desktop and use `adb reverse tcp:38472 tcp:38472`",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            item {
                SettingRow(
                    title = "Prefer server downloads",
                    subtitle = "route downloads through the server's yt-dlp (mp3/flac/... conversion)",
                ) {
                    Switch(
                        checked = settings.backend.preferRemoteDownloads,
                        onCheckedChange = viewModel::setPreferRemoteDownloads,
                    )
                }
            }
        }

        // --- advanced --------------------------------------------------------
        item { SectionTitle("Advanced") }
        item {
            SettingRow(
                title = "Auto-extend My Wave",
                subtitle = "queue more recommendations near the end of the wave",
            ) {
                Switch(checked = settings.advanced.autoExtendWave, onCheckedChange = viewModel::setAutoExtendWave)
            }
        }
        item {
            SettingRow(
                title = "Reduce motion",
                subtitle = "disable the animated backgrounds and transitions",
            ) {
                Switch(checked = settings.advanced.reducedMotion, onCheckedChange = viewModel::setReducedMotion)
            }
        }

        // --- library ---------------------------------------------------------
        item { SectionTitle("Library & storage") }
        item {
            SettingRow(
                title = "Offline library",
                subtitle = "${formatBytes(state.storageBytes)} stored • ${state.seenRecommendations} recommendations remembered",
            ) {
                TextButton(onClick = { confirmClearDownloads = true }) { Text("Clear") }
            }
        }
        item {
            SettingRow(
                title = "Listening history",
                subtitle = "clears the history list (favourites and playlists stay)",
            ) {
                TextButton(onClick = { confirmClearHistory = true }) { Text("Clear") }
            }
        }
        item {
            SettingRow(
                title = "Reset recommendations",
                subtitle = "forget which tracks My Wave already suggested",
            ) {
                TextButton(onClick = viewModel::resetRecommendations) { Text("Reset") }
            }
        }
        item {
            SettingRow(
                title = "Search cache",
                subtitle = "the desktop cached results for 5 minutes",
            ) {
                TextButton(onClick = viewModel::clearSearchCache) { Text("Clear") }
            }
        }
        item { HorizontalDivider(Modifier.padding(vertical = 8.dp)) }

        // --- about -----------------------------------------------------------
        item { SectionTitle("About") }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
                Text("Riff for Android", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Native Kotlin/Compose port of the Riff desktop player (Electron). Playback uses " +
                        "AndroidX Media3 with a MediaSessionService, so notifications, the lock screen, " +
                        "Bluetooth and headset controls are handled by the platform. Effects run in the " +
                        "audio graph (Sonic + DSP chain) instead of Web Audio; the differences are " +
                        "documented in android/PORTING.md.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Not ported: Discord Rich Presence, the desktop auto-updater, the system tray, " +
                        "window/zoom controls and the FFmpeg transcoder.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item { Spacer(Modifier.height(32.dp)) }
    }

    if (confirmClearDownloads) {
        RiffConfirmDialog(
            title = "Clear the offline library?",
            text = "Every downloaded file is deleted from the device. Playlists, favourites and history are kept.",
            confirmLabel = "Delete files",
            onConfirm = {
                viewModel.clearDownloads()
                viewModel.refreshStorage()
            },
            onDismiss = { confirmClearDownloads = false },
        )
    }
    if (confirmClearHistory) {
        RiffConfirmDialog(
            title = "Clear listening history?",
            text = "History entries are removed. My Wave may suggest tracks you already know.",
            confirmLabel = "Clear",
            onConfirm = viewModel::clearHistory,
            onDismiss = { confirmClearHistory = false },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Column(Modifier.fillMaxWidth()) {
        HorizontalDivider(Modifier.padding(top = 16.dp))
        RiffSectionHeader(title = text)
    }
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String? = null,
    content: @Composable () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            subtitle?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        content()
    }
}

@Composable
private fun SliderSetting(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueLabel: String,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            Text(valueLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun Swatch(hex: String, selected: Boolean, onClick: () -> Unit) {
    val color = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(Color.Gray)
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                width = if (selected) 3.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant,
                shape = CircleShape,
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(
                Icons.Filled.Check,
                contentDescription = "Selected",
                tint = if (color.toArgb() == Color.White.toArgb()) MaterialTheme.colorScheme.onSurface else Color.Black,
            )
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 MB"
    val mb = bytes / 1024.0 / 1024.0
    return if (mb >= 1024) "%.2f GB".format(mb / 1024) else "%.1f MB".format(mb)
}
