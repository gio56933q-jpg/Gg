package com.riff.android.feature.common

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.ui.RiffArtwork
import com.riff.android.core.ui.RiffChip
import com.riff.android.core.ui.RiffSpinner
import com.riff.android.domain.model.DownloadFormat
import com.riff.android.domain.model.DownloadQuality
import com.riff.android.domain.model.Track
import kotlinx.coroutines.launch

/**
 * Long-press menu for a track.
 *
 * Desktop equivalent: the context menu on a `.track-row` in app.js — play, play next,
 * add to queue, favourite, add to playlist, download, remove from playlist.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun TrackActionSheet(
    track: Track,
    onDismiss: () -> Unit,
    onPlay: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDownload: (() -> Unit)? = null,
    onRemoveFromPlaylist: (() -> Unit)? = null,
    onDeleteDownload: (() -> Unit)? = null,
    onSearchArtist: (() -> Unit)? = null,
) {
    var showPlaylistPicker by remember { mutableStateOf(false) }
    var showDownloadOptions by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RiffArtwork(track.artworkUri, Modifier.size(52.dp), cornerRadius = 12.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                    Text(
                        track.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            SheetAction(Icons.Filled.PlayArrow, "Play now", onPlay, onDismiss)
            SheetAction(Icons.Filled.QueueMusic, "Play next", onPlayNext, onDismiss)
            SheetAction(Icons.Filled.Add, "Add to queue", onAddToQueue, onDismiss)
            SheetAction(
                Icons.Filled.PlaylistAdd,
                "Add to playlist",
                { showPlaylistPicker = true },
                onDismiss = null,
            )
            SheetAction(
                Icons.Filled.MusicNote,
                if (track.favorite) "Remove from favorites" else "Add to favorites",
                onToggleFavorite,
                onDismiss,
            )
            if (onDownload != null && !track.isDownloaded) {
                SheetAction(Icons.Filled.Download, "Download", { showDownloadOptions = true }, onDismiss = null)
            }
            if (onSearchArtist != null) {
                SheetAction(Icons.Filled.Share, "More from ${track.artist}", onSearchArtist, onDismiss)
            }
            if (onDeleteDownload != null && track.isDownloaded) {
                SheetAction(
                    Icons.Filled.Delete,
                    "Delete download",
                    onDeleteDownload,
                    onDismiss,
                )
            }
        }
    }

    if (showPlaylistPicker) {
        PlaylistPickerSheet(
            track = track,
            onDismiss = { showPlaylistPicker = false },
        )
    }

    if (showDownloadOptions) {
        DownloadOptionsSheet(
            track = track,
            onDismiss = { showDownloadOptions = false },
            onEnqueued = {
                showDownloadOptions = false
                onDismiss()
            },
        )
    }
}

@Composable
private fun SheetAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    onDismiss: (() -> Unit)?,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable {
                onClick()
                onDismiss?.invoke()
            }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(16.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

/**
 * "Add to playlist" picker — port of the desktop `Add to playlist` submenu, including
 * the ability to create a new playlist inline.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun PlaylistPickerSheet(track: Track, onDismiss: () -> Unit) {
    val container = LocalAppContainer.current
    val playlists by container.playlists.observePlaylists().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var newName by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
            Text(
                "Add to playlist",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )

            if (creating) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Playlist name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(
                        onClick = {
                            scope.launch {
                                val playlist = container.playlists.createPlaylist(newName)
                                container.playlists.addTrack(playlist.id, track)
                                status = "added to ${playlist.name}"
                                newName = ""
                                creating = false
                            }
                        },
                        enabled = newName.isNotBlank(),
                    ) { Text("Create") }
                }
            } else {
                TextButton(
                    onClick = { creating = true },
                    modifier = Modifier.padding(horizontal = 12.dp),
                ) { Text("+ New playlist") }
            }

            LazyColumn(Modifier.fillMaxWidth().height(240.dp)) {
                items(playlists, key = { it.id }) { playlist ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    container.playlists.addTrack(playlist.id, track)
                                    status = "added to ${playlist.name}"
                                }
                            }
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RiffArtwork(
                            playlist.coverUris.firstOrNull() ?: track.artworkUri,
                            Modifier.size(40.dp),
                            cornerRadius = 8.dp,
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(playlist.name, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "${playlist.trackCount} tracks",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            status?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                )
            }
        }
    }
}

/**
 * Download options — the desktop download modal with the format chips
 * (`mp3 / m4a / flac / opus / wav`) and quality chips (`--audio-quality`).
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun DownloadOptionsSheet(
    track: Track,
    onDismiss: () -> Unit,
    onEnqueued: () -> Unit,
) {
    val container = LocalAppContainer.current
    val scope = rememberCoroutineScope()
    var format by remember { mutableStateOf(DownloadFormat.MP3) }
    var quality by remember { mutableStateOf(DownloadQuality.BEST) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Download", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(
                "${track.title} — ${track.artist}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(Modifier.height(16.dp))
            Text("Format", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DownloadFormat.entries.forEach { option ->
                    RiffChip(
                        label = option.extension.uppercase(),
                        selected = option == format,
                        onClick = { format = option },
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Quality", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DownloadQuality.entries.forEach { option ->
                    RiffChip(
                        label = option.label,
                        selected = option == quality,
                        onClick = { quality = option },
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            if (busy) {
                RiffSpinner(size = 28.dp)
            } else {
                androidx.compose.material3.Button(
                    onClick = {
                        busy = true
                        scope.launch {
                            val started = container.downloads.enqueue(track, format, quality)
                            busy = false
                            if (started) {
                                onEnqueued()
                            } else {
                                message = "already downloading"
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Download") }
            }
            message?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Downloads keep playing offline. Formats are kept as delivered by the source " +
                    "unless a transcoder is configured (see PORTING.md).",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Confirmation dialog used for destructive actions (delete playlist, clear history, ...). */
@Composable
fun RiffConfirmDialog(
    title: String,
    text: String,
    confirmLabel: String = "Confirm",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = {
                onConfirm()
                onDismiss()
            }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
