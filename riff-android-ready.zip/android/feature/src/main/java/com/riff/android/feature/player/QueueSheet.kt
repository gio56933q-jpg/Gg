package com.riff.android.feature.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.ui.RiffArtwork
import com.riff.android.core.ui.RiffEmptyHint
import com.riff.android.core.ui.RiffEqualizerBars
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.common.formatDuration

/**
 * Queue sheet.
 *
 * Desktop equivalent: the sidebar "Queue" page (`renderQueue()`) — current track,
 * the up-next list, per-row remove, drag-to-reorder and "clear queue". Drag & drop
 * becomes move up/down here; the rest matches, including the "playing" highlight and
 * the My Wave badge for auto-extended queues.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(onClose: () -> Unit) {
    val connection = LocalPlaybackConnection.current
    val player by connection.state.collectAsStateWithLifecycle()

    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    buildString {
                        append("Queue")
                        if (player.queue.isNotEmpty()) append(" • ${player.queue.size}")
                        if (player.waveActive) append(" • My Wave")
                    },
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f).padding(start = 12.dp),
                )
                if (player.queue.isNotEmpty()) {
                    TextButton(onClick = { connection.clearQueue() }) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Clear")
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "Close queue")
                }
            }

            if (player.queue.isEmpty()) {
                RiffEmptyHint("the queue is empty — play something from Search or your Library")
                Spacer(Modifier.height(24.dp))
                return@Column
            }

            LazyColumn(Modifier.fillMaxWidth()) {
                itemsIndexed(player.queue, key = { _, track -> track.id }) { index, track ->
                    val isCurrent = index == player.index
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { connection.seekToIndex(index) }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                            if (isCurrent) {
                                RiffEqualizerBars(isPlaying = player.isPlaying, height = 16.dp)
                            } else {
                                Text(
                                    "${index + 1}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        RiffArtwork(track.artworkUri, Modifier.size(44.dp), cornerRadius = 8.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                track.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                buildString {
                                    append(track.artist)
                                    if (track.durationMs > 0) {
                                        append(" • ")
                                        append(formatDuration(track.durationMs / 1000))
                                    }
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Column {
                            IconButton(
                                onClick = { connection.moveInQueue(index, index - 1) },
                                enabled = index > 0,
                            ) { Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up") }
                            IconButton(
                                onClick = { connection.moveInQueue(index, index + 1) },
                                enabled = index < player.queue.lastIndex,
                            ) { Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down") }
                        }
                        IconButton(onClick = { connection.removeFromQueue(track.id) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Remove from queue")
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "tap a row to jump to it",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
