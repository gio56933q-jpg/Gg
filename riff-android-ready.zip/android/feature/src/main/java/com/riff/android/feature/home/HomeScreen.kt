package com.riff.android.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.ui.RiffArtwork
import com.riff.android.core.ui.RiffChip
import com.riff.android.core.ui.RiffEmptyHint
import com.riff.android.core.ui.RiffPlaylistCover
import com.riff.android.core.ui.RiffSectionHeader
import com.riff.android.core.ui.RiffSpinner
import com.riff.android.core.ui.RiffTrackRow
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.Track
import com.riff.android.feature.common.LocalAppContainer
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.common.LocalRiffEffects
import com.riff.android.feature.common.riffViewModel

/**
 * Discover screen — the port of the desktop home view (`renderHomePage()` /
 * "My Wave" hero + suggestion chips + "Jump back in").
 *
 * Adapted for phones: the desktop's left rail (presets/playlists) and its wide grid
 * become a vertical scroll of sections with horizontal carousels, which is what the
 * same content looks like on a handset.
 */
@Composable
fun HomeScreen() {
    val container = LocalAppContainer.current
    val connection = LocalPlaybackConnection.current
    val effects = LocalRiffEffects.current
    val viewModel = riffViewModel { HomeViewModel(it, connection, effects) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val player by connection.state.collectAsStateWithLifecycle()

    // Trending chip queries — identical to the desktop suggestion chips.
    val chips = listOf(
        "Relaxing music" to "Relax",
        "Workout hip hop" to "Workout",
        "Electronic dance" to "Electronic",
        "Deftones rock" to "Rock",
        "Phonk drift" to "Phonk",
        "Synthwave chill" to "Synthwave",
        "Slowed reverb" to "Slowed + reverb",
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text("Riff", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(
                    "your offline-first music player",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(chips) { (query, label) ->
                    RiffChip(label = label, onClick = {
                        viewModel.searchFor(query)
                    })
                }
            }
        }

        // --- My Wave hero ---------------------------------------------------
        item {
            Spacer(Modifier.height(16.dp))
            WaveHero(
                state = state,
                isPlayingWave = player.waveActive,
                onGenerate = { viewModel.generateWave() },
                onPlay = { viewModel.playWave() },
                onShuffle = { viewModel.extendWave() },
            )
        }

        // --- Jump back in ---------------------------------------------------
        if (state.history.isNotEmpty()) {
            item {
                RiffSectionHeader(title = "Jump back in", hint = "history")
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(state.history.take(12), key = { it.id }) { track ->
                        JumpBackCard(
                            track = track,
                            isCurrent = player.track?.id == track.id,
                            onClick = { viewModel.play(track, state.history, PlaybackContext.History) },
                        )
                    }
                }
            }
        }

        // --- Favorites ------------------------------------------------------
        if (state.favorites.isNotEmpty()) {
            item {
                RiffSectionHeader(
                    title = "Favorites",
                    hint = "${state.favorites.size}",
                    trailing = {
                        IconButton(onClick = { viewModel.shuffleFavorites() }) {
                            Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle favorites")
                        }
                    },
                )
            }
            itemsIndexed(state.favorites.take(8), key = { _, track -> track.id }) { _, track ->
                RiffTrackRow(
                    track = track,
                    isCurrent = player.track?.id == track.id,
                    onClick = { viewModel.play(track, state.favorites, PlaybackContext.Favorites) },
                    onFavoriteToggle = { viewModel.toggleFavorite(track) },
                    modifier = Modifier.padding(horizontal = 8.dp),
                )
            }
        }

        // --- Offline downloads ---------------------------------------------
        if (state.downloads.isNotEmpty()) {
            item {
                RiffSectionHeader(title = "Available offline", hint = "${state.downloads.size} downloaded")
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(state.downloads.take(12), key = { it.id }) { track ->
                        JumpBackCard(
                            track = track,
                            isCurrent = player.track?.id == track.id,
                            onClick = { viewModel.play(track, state.downloads, PlaybackContext.Downloads) },
                        )
                    }
                }
            }
        }

        // --- Playlists ------------------------------------------------------
        if (state.playlists.isNotEmpty()) {
            item {
                RiffSectionHeader(title = "Playlists", hint = "${state.playlists.size}")
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(state.playlists, key = { it.id }) { playlist ->
                        Column(
                            Modifier
                                .width(120.dp)
                                .clickable {
                                    // Playing a playlist mirrors the desktop "play all"
                                    // button: queue the whole list from index 0.
                                    container.playlists.observePlaylistTracks(playlist.id)
                                },
                        ) {
                            RiffPlaylistCover(covers = playlist.coverUris, modifier = Modifier.size(120.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(
                                playlist.name,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                "${playlist.trackCount} tracks",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }

        if (state.history.isEmpty() && state.favorites.isEmpty() && state.downloads.isEmpty()) {
            item {
                RiffEmptyHint(
                    "nothing here yet — search for a track, or import your own files from the Library tab.\n" +
                        "Downloads stay playable offline, exactly like the desktop app's offline library.",
                )
            }
        }
    }
}

/** Desktop "My Wave" hero card: gradient panel, generate/refresh and play controls. */
@Composable
private fun WaveHero(
    state: HomeUiState,
    isPlayingWave: Boolean,
    onGenerate: () -> Unit,
    onPlay: () -> Unit,
    onShuffle: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("My Wave", style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (state.autoExtendWave) "never-ending queue, built from your taste"
                        else "built from your listening history",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            when {
                state.waveLoading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    RiffSpinner(size = 20.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("building your wave…", style = MaterialTheme.typography.bodyMedium)
                }

                state.wave.isNotEmpty() -> {
                    Text(
                        state.wave.take(3).joinToString("  •  ") { it.title },
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onPlay) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (isPlayingWave) "Playing" else "Play wave")
                        }
                        Button(
                            onClick = onShuffle,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                            ),
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Extend")
                        }
                    }
                }

                else -> {
                    Text(
                        state.waveError
                            ?: "generate a queue from what you have been listening to lately",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onGenerate, enabled = state.hasTasteSeed || state.waveError == null) {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Generate")
                    }
                }
            }
        }
    }
}

/** Square artwork card used by the "jump back in" / offline rows. */
@Composable
private fun JumpBackCard(track: Track, isCurrent: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(112.dp)
            .clickable(onClick = onClick),
    ) {
        RiffArtwork(
            uri = track.artworkUri,
            modifier = Modifier.size(112.dp),
            cornerRadius = 14.dp,
            contentDescription = track.title,
            placeholderColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerHigh,
        )
        Spacer(Modifier.height(6.dp))
        Text(track.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            track.artist,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
