package com.riff.android.feature

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.riff.android.core.ui.RiffArtwork
import com.riff.android.core.ui.RiffProgressLine
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.home.HomeScreen
import com.riff.android.feature.library.LibraryScreen
import com.riff.android.feature.player.FullPlayer
import com.riff.android.feature.player.QueueSheet
import com.riff.android.feature.playlists.PlaylistsScreen
import com.riff.android.feature.search.SearchScreen
import com.riff.android.feature.settings.SettingsScreen

/** Bottom navigation destinations (the phone counterpart of the desktop sidebar). */
private enum class RiffDestination(val route: String, val label: String) {
    HOME("home", "Discover"),
    SEARCH("search", "Search"),
    LIBRARY("library", "Library"),
    PLAYLISTS("playlists", "Playlists"),
    SETTINGS("settings", "Settings"),
}

/**
 * Root of the Android UI.
 *
 * Layout mapping from the desktop app (`index.html`):
 *  - sidebar (discover / favorites / history / queue / settings) -> bottom navigation,
 *    with favorites/history/downloads living in the Library screen's tabs,
 *  - the fixed playbar -> [MiniPlayer] above the navigation bar (tap = full player),
 *  - the right-hand lyrics/now-playing panel -> [FullPlayer] (a full-screen surface
 *    with its own queue/effects/lyrics sheets) because phones have no room for a
 *    permanent side panel in portrait; in landscape the full player is what the
 *    desktop layout collapses to anyway.
 */
@Composable
fun RiffApp() {
    val connection = LocalPlaybackConnection.current
    val player by connection.state.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { connection.connect() }
    DisposableEffect(Unit) {
        onDispose { connection.release() }
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    var playerOpen by rememberSaveable { mutableStateOf(false) }
    var queueOpen by rememberSaveable { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                Column(Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.navigationBars)) {
                    AnimatedVisibility(
                        visible = player.hasTrack,
                        enter = slideInVertically { it },
                        exit = slideOutVertically { it },
                    ) {
                        MiniPlayer(
                            onClick = { playerOpen = true },
                            onQueueClick = { queueOpen = true },
                        )
                    }
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                        RiffDestination.entries.forEach { destination ->
                            val selected = currentRoute == destination.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    if (!selected) {
                                        navController.navigate(destination.route) {
                                            popUpTo(RiffDestination.HOME.route) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                icon = { Icon(destination.icon(), contentDescription = destination.label) },
                                label = { Text(destination.label, style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                ),
                            )
                        }
                    }
                }
            },
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = RiffDestination.HOME.route,
                modifier = Modifier.fillMaxSize().padding(padding),
            ) {
                composable(RiffDestination.HOME.route) { HomeScreen() }
                composable(RiffDestination.SEARCH.route) { SearchScreen() }
                composable(RiffDestination.LIBRARY.route) { LibraryScreen() }
                composable(RiffDestination.PLAYLISTS.route) { PlaylistsScreen() }
                composable(RiffDestination.SETTINGS.route) { SettingsScreen() }
            }
        }

        if (playerOpen) {
            FullPlayer(onClose = { playerOpen = false })
        }
        if (queueOpen) {
            QueueSheet(onClose = { queueOpen = false })
        }
    }
}

private fun RiffDestination.icon() = when (this) {
    RiffDestination.HOME -> Icons.Filled.Home
    RiffDestination.SEARCH -> Icons.Filled.Search
    RiffDestination.LIBRARY -> Icons.Filled.LibraryMusic
    RiffDestination.PLAYLISTS -> Icons.Filled.PlaylistPlay
    RiffDestination.SETTINGS -> Icons.Filled.Settings
}

/**
 * The desktop playbar, reduced to what fits above a phone navigation bar:
 * artwork, title/artist, play/pause, next and a thin progress line at the top edge.
 */
@Composable
private fun MiniPlayer(onClick: () -> Unit, onQueueClick: () -> Unit) {
    val connection = LocalPlaybackConnection.current
    val player by connection.state.collectAsStateWithLifecycle()
    val track = player.track ?: return

    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
    ) {
        Column {
            RiffProgressLine(progress = player.progress, height = 2.dp)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RiffArtwork(
                    uri = track.artworkUri,
                    modifier = Modifier.size(42.dp),
                    cornerRadius = 10.dp,
                    contentDescription = track.title,
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        track.title,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        if (player.error != null) player.error!! else track.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (player.error != null) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = { connection.togglePlayPause() }) {
                        Icon(
                            if (player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (player.isPlaying) "Pause" else "Play",
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    }
                    IconButton(onClick = { connection.next() }) {
                        Icon(Icons.Filled.SkipNext, contentDescription = "Next")
                    }
                }
            }
        }
    }
}
