package com.riff.android.feature.playlists

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.ui.RiffEmptyHint
import com.riff.android.core.ui.RiffPlaylistCover
import com.riff.android.core.ui.RiffSectionHeader
import com.riff.android.core.ui.RiffTrackRow
import com.riff.android.domain.model.Playlist
import com.riff.android.domain.model.Track
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.common.RiffConfirmDialog
import com.riff.android.feature.common.TrackActionSheet
import com.riff.android.feature.common.riffViewModel

/**
 * Playlists.
 *
 * Desktop equivalent: the sidebar "Playlists" section + the playlist detail page in
 * app.js — 2x2 mosaic covers (`renderPlaylistCover()`), create/rename/delete, play all,
 * track removal and reordering. Drag & drop is replaced by explicit move up/down
 * buttons; everything else maps 1:1.
 */
@Composable
fun PlaylistsScreen() {
    val connection = LocalPlaybackConnection.current
    val viewModel = riffViewModel { container -> PlaylistsViewModel(container, connection) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val player by connection.state.collectAsStateWithLifecycle()

    var showCreate by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Playlist?>(null) }
    var deleteTarget by remember { mutableStateOf<Playlist?>(null) }
    var actionTrack by remember { mutableStateOf<Track?>(null) }

    Box(Modifier.fillMaxSize()) {
        val open = state.openPlaylist
        if (open == null) {
            Column(Modifier.fillMaxSize()) {
                RiffSectionHeader(
                    title = "Playlists",
                    hint = "${state.playlists.size}",
                )
                state.message?.let { message ->
                    Text(
                        message,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.dismissMessage() }
                            .padding(horizontal = 20.dp, vertical = 4.dp),
                    )
                }
                if (state.playlists.isEmpty()) {
                    RiffEmptyHint(
                        "no playlists yet — create one, then use \"Add to playlist\" from any track menu",
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(state.playlists, key = { it.id }) { playlist ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.open(playlist.id) }
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                RiffPlaylistCover(playlist.coverUris, Modifier.size(56.dp), cornerRadius = 12.dp)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        playlist.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        "${playlist.trackCount} tracks",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(onClick = { renameTarget = playlist }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Rename")
                                }
                                IconButton(onClick = { deleteTarget = playlist }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                        item { Spacer(Modifier.height(80.dp)) }
                    }
                }
            }

            FloatingActionButton(
                onClick = { showCreate = true },
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            ) {
                Icon(Icons.Filled.Add, contentDescription = "New playlist")
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = viewModel::close) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                    RiffPlaylistCover(open.coverUris, Modifier.size(64.dp), cornerRadius = 12.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(open.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${open.playlistTrackCountLabel()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = { viewModel.play(0) }, enabled = state.tracks.isNotEmpty()) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Play")
                    }
                    TextButton(onClick = { viewModel.play(shuffled = true) }, enabled = state.tracks.isNotEmpty()) {
                        Icon(Icons.Filled.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Shuffle")
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { renameTarget = open }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Rename playlist")
                    }
                    IconButton(onClick = { deleteTarget = open }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete playlist")
                    }
                }

                if (state.tracks.isEmpty()) {
                    RiffEmptyHint("this playlist is empty — add tracks from Search, Library or the player")
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(state.tracks, key = { _, track -> track.id }) { index, track ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RiffTrackRow(
                                    track = track,
                                    isCurrent = player.track?.id == track.id,
                                    showIndex = index + 1,
                                    onClick = { viewModel.play(index) },
                                    onFavoriteToggle = { viewModel.toggleFavorite(track) },
                                    onMoreClick = { actionTrack = track },
                                    modifier = Modifier.weight(1f),
                                )
                                Column {
                                    IconButton(
                                        onClick = { viewModel.moveTrack(index, index - 1) },
                                        enabled = index > 0,
                                    ) { Icon(Icons.Filled.ArrowUpward, contentDescription = "Move up") }
                                    IconButton(
                                        onClick = { viewModel.moveTrack(index, index + 1) },
                                        enabled = index < state.tracks.lastIndex,
                                    ) { Icon(Icons.Filled.ArrowDownward, contentDescription = "Move down") }
                                }
                            }
                        }
                        item { Spacer(Modifier.height(32.dp)) }
                    }
                }
            }
        }
    }

    if (showCreate) {
        NameDialog(
            title = "New playlist",
            initial = "",
            confirmLabel = "Create",
            onConfirm = {
                viewModel.create(it)
                showCreate = false
            },
            onDismiss = { showCreate = false },
        )
    }

    renameTarget?.let { playlist ->
        NameDialog(
            title = "Rename playlist",
            initial = playlist.name,
            confirmLabel = "Save",
            onConfirm = {
                viewModel.rename(playlist.id, it)
                renameTarget = null
            },
            onDismiss = { renameTarget = null },
        )
    }

    deleteTarget?.let { playlist ->
        RiffConfirmDialog(
            title = "Delete \"${playlist.name}\"?",
            text = "The playlist is removed. The tracks themselves stay in your library.",
            confirmLabel = "Delete",
            onConfirm = { viewModel.delete(playlist.id) },
            onDismiss = { deleteTarget = null },
        )
    }

    actionTrack?.let { track ->
        TrackActionSheet(
            track = track,
            onDismiss = { actionTrack = null },
            onPlay = { viewModel.play(state.tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)) },
            onPlayNext = { viewModel.queueNext(track) },
            onAddToQueue = { viewModel.addToQueue(track) },
            onToggleFavorite = { viewModel.toggleFavorite(track) },
            onDownload = {},
            onRemoveFromPlaylist = { viewModel.removeTrack(track) },
        )
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                label = { Text("Name") },
                singleLine = true,
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(value.trim()) }, enabled = value.isNotBlank()) {
                Text(confirmLabel)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private fun Playlist.playlistTrackCountLabel(): String =
    if (trackCount == 1) "1 track" else "$trackCount tracks"
