package com.riff.android.feature.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.ui.RiffChip
import com.riff.android.core.ui.RiffEmptyHint
import com.riff.android.core.ui.RiffSectionHeader
import com.riff.android.core.ui.RiffSpinner
import com.riff.android.core.ui.RiffTrackRow
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.Track
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.common.TrackActionSheet
import com.riff.android.feature.common.riffViewModel

/**
 * Search.
 *
 * Desktop equivalent: the top-nav search (`#search-input` + the YouTube/SoundCloud
 * toggle, `#search-results` list). Two deliberate changes for phones:
 *
 *  - the platform switch is a chip row under the field instead of a compact pill,
 *  - the results list supports "play all" / "shuffle all" like the desktop results
 *    header, which on mobile is otherwise hidden behind a scroll.
 */
@Composable
fun SearchScreen() {
    val connection = LocalPlaybackConnection.current
    val viewModel = riffViewModel { container -> SearchViewModel(container, connection) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val player by connection.state.collectAsStateWithLifecycle()

    var actionTrack by remember { mutableStateOf<Track?>(null) }
    val keyboard = LocalSoftwareKeyboardController.current

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = state.query,
            onValueChange = viewModel::onQueryChange,
            placeholder = { Text("Search YouTube or SoundCloud") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (state.query.isNotEmpty()) {
                    IconButton(onClick = { viewModel.onQueryChange("") }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(
                onSearch = {
                    keyboard?.hide()
                    viewModel.submit()
                },
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SearchPlatform.entries.forEach { platform ->
                RiffChip(
                    label = platform.label,
                    selected = state.platform == platform,
                    onClick = { viewModel.onPlatformChange(platform) },
                )
            }
            Spacer(Modifier.weight(1f))
            if (state.results.isNotEmpty()) {
                IconButton(onClick = viewModel::shuffleAll) {
                    Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle results")
                }
                TextButton(onClick = viewModel::playAll) { Text("Play all") }
            }
        }

        when {
            state.loading -> Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                RiffSpinner()
            }

            state.error != null && state.results.isEmpty() -> RiffEmptyHint(state.error!!)

            state.searched && state.results.isEmpty() -> RiffEmptyHint(
                "no results for \"${state.query}\" on ${state.platform.label}",
            )

            state.results.isEmpty() -> RecentSearches(
                queries = state.recentQueries,
                onPick = viewModel::repeatQuery,
                onClear = viewModel::clearRecent,
            )

            else -> LazyColumn(Modifier.fillMaxSize()) {
                item {
                    RiffSectionHeader(
                        title = "Results",
                        hint = buildString {
                            append("${state.results.size} on ${state.platform.label}")
                            if (state.fromCache) append(" • cached")
                        },
                    )
                }
                items(state.results, key = { it.id }) { track ->
                    RiffTrackRow(
                        track = track,
                        isCurrent = player.track?.id == track.id,
                        onClick = { viewModel.play(track) },
                        onFavoriteToggle = { viewModel.toggleFavorite(track) },
                        onMoreClick = { actionTrack = track },
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    actionTrack?.let { track ->
        TrackActionSheet(
            track = track,
            onDismiss = { actionTrack = null },
            onPlay = { viewModel.play(track) },
            onPlayNext = { viewModel.queueNext(track) },
            onAddToQueue = { viewModel.addToQueue(track) },
            onToggleFavorite = { viewModel.toggleFavorite(track) },
            onDownload = {},
            onSearchArtist = { viewModel.repeatQuery(track.artist) },
        )
    }
}

/** Recent queries (the desktop app kept the last search in `state.lastQuery`). */
@Composable
private fun RecentSearches(
    queries: List<String>,
    onPick: (String) -> Unit,
    onClear: () -> Unit,
) {
    if (queries.isEmpty()) {
        Column(Modifier.fillMaxSize()) {
            RiffSectionHeader(title = "Search", hint = "type at least 2 characters")
            RiffEmptyHint(
                "search for a song, an artist or a vibe — results can be played, downloaded " +
                    "and added to playlists",
            )
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        RiffSectionHeader(
            title = "Recent searches",
            trailing = { TextButton(onClick = onClear) { Text("Clear") } },
        )
        LazyColumn {
            items(queries) { query ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(query) }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(12.dp))
                    Text(query, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}
