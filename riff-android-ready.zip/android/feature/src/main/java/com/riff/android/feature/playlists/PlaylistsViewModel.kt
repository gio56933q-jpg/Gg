package com.riff.android.feature.playlists

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riff.android.core.player.PlaybackConnection
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.Playlist
import com.riff.android.domain.model.Track
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PlaylistsUiState(
    val playlists: List<Playlist> = emptyList(),
    val openPlaylistId: String? = null,
    val openPlaylist: Playlist? = null,
    val tracks: List<Track> = emptyList(),
    val message: String? = null,
)

/**
 * Playlists state holder.
 *
 * Desktop equivalent: `renderPlaylists()` / `createPlaylist()` / `deletePlaylist()` /
 * `renamePlaylist()` and `initListReordering()` in app.js (`state.playlists` persisted
 * in `devsize_playlists`). Reordering uses explicit move up/down actions instead of
 * HTML5 drag & drop, which has no touch equivalent in a Compose list.
 */
class PlaylistsViewModel(
    private val container: RiffContainer,
    private val connection: PlaybackConnection,
) : ViewModel() {

    private val local = MutableStateFlow(LocalState())

    private data class LocalState(
        val openPlaylistId: String? = null,
        val message: String? = null,
    )

    @OptIn(ExperimentalCoroutinesApi::class)
    private val openPlaylistFlow: StateFlow<Playlist?> = local
        .flatMapLatest { state ->
            state.openPlaylistId?.let { container.playlists.observePlaylist(it) } ?: flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    private val openTracksFlow: StateFlow<List<Track>> = local
        .flatMapLatest { state ->
            state.openPlaylistId?.let { container.playlists.observePlaylistTracks(it) } ?: flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val state: StateFlow<PlaylistsUiState> = combine(
        container.playlists.observePlaylists(),
        local,
        openPlaylistFlow,
        openTracksFlow,
    ) { playlists, localState, playlist, tracks ->
        PlaylistsUiState(
            playlists = playlists,
            openPlaylistId = localState.openPlaylistId,
            openPlaylist = playlist,
            tracks = tracks,
            message = localState.message,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PlaylistsUiState())

    fun open(playlistId: String) {
        local.value = local.value.copy(openPlaylistId = playlistId)
    }

    fun close() {
        local.value = local.value.copy(openPlaylistId = null)
    }

    fun dismissMessage() {
        local.value = local.value.copy(message = null)
    }

    fun create(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val playlist = container.playlists.createPlaylist(name)
            local.value = local.value.copy(
                openPlaylistId = playlist.id,
                message = "created ${playlist.name}",
            )
        }
    }

    fun rename(playlistId: String, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            container.playlists.renamePlaylist(playlistId, name)
            local.value = local.value.copy(message = "renamed to $name")
        }
    }

    fun delete(playlistId: String) {
        viewModelScope.launch {
            container.playlists.deletePlaylist(playlistId)
            local.value = local.value.copy(openPlaylistId = null, message = "playlist deleted")
        }
    }

    fun removeTrack(track: Track) {
        val playlistId = local.value.openPlaylistId ?: return
        viewModelScope.launch {
            container.playlists.removeTrack(playlistId, track.id)
            local.value = local.value.copy(message = "removed ${track.title}")
        }
    }

    /** `initListReordering()` port: move one slot up/down. */
    fun moveTrack(fromIndex: Int, toIndex: Int) {
        val playlistId = local.value.openPlaylistId ?: return
        if (fromIndex == toIndex) return
        viewModelScope.launch { container.playlists.moveTrack(playlistId, fromIndex, toIndex) }
    }

    fun play(index: Int = 0, shuffled: Boolean = false) {
        val playlist = state.value.openPlaylist ?: return
        val tracks = if (shuffled) state.value.tracks.shuffled() else state.value.tracks
        if (tracks.isEmpty()) return
        if (shuffled) connection.setShuffle(true)
        val startIndex = if (shuffled) 0 else index.coerceIn(0, tracks.lastIndex)
        connection.playTracks(tracks, startIndex, PlaybackContext.PlaylistContext(playlist.id, playlist.name))
        viewModelScope.launch { container.library.upsertAll(tracks) }
    }

    fun queueNext(track: Track) = connection.playNextInQueue(track)

    fun addToQueue(track: Track) = connection.addToQueue(track)

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            val updated = container.library.setFavorite(track, !track.favorite)
            if (connection.state.value.track?.id == updated.id) connection.updateCurrentTrack(updated)
        }
    }

    /** Used by the "add to playlist" flow from other screens. */
    fun addToPlaylist(playlistId: String, track: Track) {
        viewModelScope.launch {
            container.playlists.addTrack(playlistId, track)
            local.value = local.value.copy(message = "added ${track.title}")
        }
    }
}
