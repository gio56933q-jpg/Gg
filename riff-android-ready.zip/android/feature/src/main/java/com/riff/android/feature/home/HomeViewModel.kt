package com.riff.android.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riff.android.core.audio.AudioEffectsController
import com.riff.android.core.player.PlaybackConnection
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.Track
import com.riff.android.domain.recommend.RecommendationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Discover screen state. */
data class HomeUiState(
    val history: List<Track> = emptyList(),
    val favorites: List<Track> = emptyList(),
    val downloads: List<Track> = emptyList(),
    val playlists: List<com.riff.android.domain.model.Playlist> = emptyList(),
    val wave: List<Track> = emptyList(),
    val waveLoading: Boolean = false,
    val waveError: String? = null,
    val autoExtendWave: Boolean = true,
    val hasTasteSeed: Boolean = false,
)

/**
 * Discover ("My Wave") state holder.
 *
 * Desktop equivalent: `loadHomePage()` + `renderMyWaveChips()` / `extendMyWaveQueue()`
 * in app.js. The recommendation pipeline itself lives in the domain layer
 * (`RecommendationEngine` via `RecommendationRepository`); this ViewModel only
 * observes the library and drives playback through [PlaybackConnection].
 */
class HomeViewModel(
    private val container: RiffContainer,
    private val connection: PlaybackConnection,
    private val effects: AudioEffectsController?,
) : ViewModel() {

    private val waveState = MutableStateFlow(WaveState())

    val state: StateFlow<HomeUiState> = combine(
        container.library.observeHistory(),
        container.library.observeFavorites(),
        container.library.observeDownloads(),
        container.playlists.observePlaylists(),
        waveState,
    ) { history, favorites, downloads, playlists, wave ->
        HomeUiState(
            history = history,
            favorites = favorites,
            downloads = downloads,
            playlists = playlists,
            wave = wave.tracks,
            waveLoading = wave.loading,
            waveError = wave.error,
            hasTasteSeed = (history.size + favorites.size) >= 5,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    init {
        viewModelScope.launch {
            container.settings.observeSettings().collect { settings ->
                waveState.value = waveState.value.copy(autoExtendWave = settings.advanced.autoExtendWave)
            }
        }
    }

    private data class WaveState(
        val tracks: List<Track> = emptyList(),
        val loading: Boolean = false,
        val error: String? = null,
        val autoExtendWave: Boolean = true,
    )

    /** Desktop `refreshMyWave()` -> `POST /api/vibe`. */
    fun generateWave() {
        if (waveState.value.loading) return
        waveState.value = waveState.value.copy(loading = true, error = null)
        viewModelScope.launch {
            runCatching { container.recommendations.recommend(limit = WAVE_SIZE, extend = false) }
                .onSuccess { result -> onWaveLoaded(result) }
                .onFailure { error ->
                    waveState.value = waveState.value.copy(loading = false, error = error.message ?: "wave failed")
                }
        }
    }

    /** Desktop `extendMyWaveQueue()` — called by the service, exposed here for the UI button. */
    fun extendWave() {
        if (waveState.value.loading) return
        waveState.value = waveState.value.copy(loading = true, error = null)
        viewModelScope.launch {
            runCatching { container.recommendations.recommend(limit = WAVE_SIZE, extend = true) }
                .onSuccess { result -> onWaveLoaded(result) }
                .onFailure { error ->
                    waveState.value = waveState.value.copy(loading = false, error = error.message ?: "wave failed")
                }
        }
    }

    private fun onWaveLoaded(result: RecommendationResult) {
        waveState.value = waveState.value.copy(
            tracks = result.tracks,
            loading = false,
            error = if (result.tracks.isEmpty()) EMPTY_WAVE_MESSAGE else null,
        )
    }

    /** Plays the wave as a My Wave queue so the service auto-extends it near the end. */
    fun playWave(startIndex: Int = 0) {
        val tracks = waveState.value.tracks
        if (tracks.isEmpty()) {
            generateWave()
            return
        }
        connection.playTracks(
            tracks = tracks,
            startIndex = startIndex,
            context = PlaybackContext.MyWave,
            waveActive = true,
        )
        container.library.let { repo -> viewModelScope.launch { repo.upsertAll(tracks) } }
    }

    fun play(track: Track, queue: List<Track>, context: PlaybackContext) {
        val index = queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        connection.playTracks(queue.toMutableList(), index, context)
        viewModelScope.launch { container.library.upsert(track) }
    }

    fun shuffleFavorites() {
        val favorites = state.value.favorites
        if (favorites.isEmpty()) return
        connection.setShuffle(true)
        connection.playTracks(favorites.shuffled(), 0, PlaybackContext.Favorites)
    }

    fun queueNext(track: Track) = connection.playNextInQueue(track)

    fun addToQueue(track: Track) = connection.addToQueue(track)

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            val nowFavorite = !track.favorite
            val updated = container.library.setFavorite(track, nowFavorite)
            // Keep the currently playing item's state in sync with the row.
            if (connection.state.value.track?.id == updated.id) {
                connection.updateCurrentTrack(updated)
            }
        }
    }

    fun download(track: Track) {
        viewModelScope.launch { container.downloads.enqueue(track) }
    }

    fun searchFor(query: String) {
        // Chips on the discover page behave like the desktop: they run a search and
        // play the first result as a new queue (desktop `suggestionChips` handler).
        viewModelScope.launch {
            val result = container.search.search(
                query = query,
                platform = com.riff.android.domain.model.SearchPlatform.YOUTUBE,
                limit = 20,
            )
            if (result.tracks.isNotEmpty()) {
                connection.playTracks(result.tracks, 0, PlaybackContext.Search)
            }
        }
    }

    companion object {
        /** Desktop `/api/vibe` is called with `limit: 8`; the UI asks for a few more. */
        const val WAVE_SIZE = 10
        const val EMPTY_WAVE_MESSAGE =
            "not enough listening history yet — play a few tracks, or search for something you like"
    }
}
