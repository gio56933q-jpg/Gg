package com.riff.android.feature.library

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.riff.android.core.ui.RiffArtwork
import com.riff.android.core.ui.RiffBadge
import com.riff.android.core.ui.RiffEmptyHint
import com.riff.android.core.ui.RiffSectionHeader
import com.riff.android.core.ui.RiffSpinner
import com.riff.android.core.ui.RiffTrackRow
import com.riff.android.domain.model.ArtistProfile
import com.riff.android.domain.model.Track
import com.riff.android.feature.common.LocalPlaybackConnection

/**
 * Artist profile.
 *
 * Desktop equivalent: `openArtistProfile()` in app.js — a full-screen panel with the
 * artist avatar, name, verification badge, bio (`/api/artist` → Deezer +
 * Wikipedia) and the top-track list. Rendered as a full-screen sheet here because
 * phones cannot overlay a side panel.
 */
@Composable
fun ArtistProfileSheet(
    profile: ArtistProfile?,
    loading: Boolean,
    onDismiss: () -> Unit,
    onPlayTrack: (Int) -> Unit,
    onAddToQueue: (Track) -> Unit,
) {
    val connection = LocalPlaybackConnection.current
    val player = connection.state.value

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                                MaterialTheme.colorScheme.background,
                            ),
                        ),
                    ),
            ) {
                IconButton(onClick = onDismiss, modifier = Modifier.padding(8.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Close")
                }
            }

            if (loading && profile == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { RiffSpinner() }
                return@Column
            }

            val artist = profile ?: run {
                RiffEmptyHint("no profile available for this artist")
                return@Column
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RiffArtwork(
                    artist.avatarUri,
                    Modifier.size(84.dp).clip(CircleShape),
                    cornerRadius = 42.dp,
                    contentDescription = artist.name,
                )
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(artist.name, style = MaterialTheme.typography.headlineSmall, maxLines = 2)
                        if (artist.verified) {
                            Spacer(Modifier.width(6.dp))
                            Icon(
                                Icons.Filled.Verified,
                                contentDescription = "Verified",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                    if (artist.followers > 0) {
                        Spacer(Modifier.height(4.dp))
                        RiffBadge("%,d followers".format(artist.followers))
                    }
                }
            }

            if (!artist.bio.isNullOrBlank()) {
                Text(
                    artist.bio,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .height(96.dp)
                        .verticalScroll(rememberScrollState()),
                )
            }

            RiffSectionHeader(
                title = "Top tracks",
                hint = "${artist.tracks.size}",
                trailing = {
                    if (artist.tracks.isNotEmpty()) {
                        IconButton(onClick = { onPlayTrack(0) }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Play artist")
                        }
                    }
                },
            )

            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(artist.tracks, key = { _, track -> track.id }) { index, track ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RiffTrackRow(
                            track = track,
                            isCurrent = player.track?.id == track.id,
                            showIndex = index + 1,
                            onClick = { onPlayTrack(index) },
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { onAddToQueue(track) }) {
                            Icon(Icons.Filled.Add, contentDescription = "Add to queue")
                        }
                    }
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }
}
