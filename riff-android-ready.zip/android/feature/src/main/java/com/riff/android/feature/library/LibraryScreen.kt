package com.riff.android.feature.library

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.riff.android.core.ui.RiffArtwork
import com.riff.android.core.ui.RiffEmptyHint
import com.riff.android.core.ui.RiffSectionHeader
import com.riff.android.core.ui.RiffSpinner
import com.riff.android.core.ui.RiffTrackRow
import com.riff.android.domain.model.Track
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.common.RiffConfirmDialog
import com.riff.android.feature.common.TrackActionSheet
import com.riff.android.feature.common.riffViewModel

/**
 * Library.
 *
 * Desktop equivalents merged into one screen with tabs, because the desktop sidebar
 * entries (favorites, history) and the offline library overlay are all "my music" on
 * a phone:
 *
 *  - **Songs** — everything the app knows about (downloads, imports, search results
 *    the user favourited or queued),
 *  - **Artists / Albums** — grouped views with the artist profile sheet
 *    (`openArtistProfile()` in app.js),
 *  - **Favorites** — `state.favorites`,
 *  - **Downloaded** — the offline library (`/api/offline-library`) with per-track
 *    delete and "clear all" (the desktop cache modal),
 *  - **History** — `state.history` (newest first) with the desktop's clear button.
 */
@Composable
fun LibraryScreen() {
    val context = LocalContext.current
    val connection = LocalPlaybackConnection.current
    val viewModel = riffViewModel { container -> LibraryViewModel(container, connection) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val player by connection.state.collectAsStateWithLifecycle()
    val profile by viewModel.artistProfile.collectAsStateWithLifecycle()
    val profileLoading by viewModel.artistLoading.collectAsStateWithLifecycle()

    var actionTrack by remember { mutableStateOf<Track?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    // SAF import — the desktop "add local files" button.
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
            viewModel.importUri(context, uri)
        }
    }

    // MediaStore scan — optional, needs the audio read permission.
    var pendingScan by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted && pendingScan) viewModel.scanDevice()
        pendingScan = false
    }

    fun scanWithPermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        val granted = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            viewModel.scanDevice()
        } else {
            pendingScan = true
            permissionLauncher.launch(permission)
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = state.query,
            onValueChange = viewModel::onQueryChange,
            placeholder = { Text("Filter your library") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )

        ScrollableTabRow(
            selectedTabIndex = LibraryTab.entries.indexOf(state.tab),
            edgePadding = 12.dp,
            containerColor = MaterialTheme.colorScheme.background,
        ) {
            LibraryTab.entries.forEach { tab ->
                Tab(
                    selected = state.tab == tab,
                    onClick = { viewModel.selectTab(tab) },
                    text = { Text(tab.label) },
                )
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                buildString {
                    append(
                        when (state.tab) {
                            LibraryTab.ARTISTS -> "${state.visibleArtists.size} artists"
                            LibraryTab.ALBUMS -> "${state.visibleAlbums.size} albums"
                            else -> "${state.visible.size} tracks"
                        },
                    )
                    if (state.storageBytes > 0) {
                        append(" • ${formatBytes(state.storageBytes)} on device")
                    }
                },
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            if (state.tab != LibraryTab.ARTISTS && state.tab != LibraryTab.ALBUMS && state.visible.isNotEmpty()) {
                IconButton(onClick = { viewModel.playAll(shuffled = true) }) {
                    Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle")
                }
                TextButton(onClick = { viewModel.playAll() }) { Text("Play all") }
            }
            when (state.tab) {
                LibraryTab.DOWNLOADS -> if (state.downloads.isNotEmpty()) {
                    IconButton(onClick = { confirmClear = true }) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear offline library")
                    }
                }
                LibraryTab.HISTORY -> if (state.history.isNotEmpty()) {
                    TextButton(onClick = viewModel::clearHistory) { Text("Clear") }
                }
                else -> Unit
            }
        }

        if (state.tab == LibraryTab.SONGS || state.tab == LibraryTab.DOWNLOADS) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = { importLauncher.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Filled.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add files")
                }
                TextButton(onClick = { scanWithPermission() }) {
                    Icon(Icons.Filled.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Scan device")
                }
                Spacer(Modifier.weight(1f))
                if (state.busy) RiffSpinner(size = 22.dp)
            }
        }

        state.message?.let { message ->
            Text(
                message,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.dismissMessage() }
                    .padding(horizontal = 20.dp, vertical = 6.dp),
            )
        }

        when (state.tab) {
            LibraryTab.ARTISTS -> if (state.visibleArtists.isEmpty()) {
                RiffEmptyHint("no artists yet — play or download something")
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(state.visibleArtists, key = { it.name }) { artist ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.openArtist(artist.name) }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RiffArtwork(
                                artist.artworkUri,
                                Modifier.size(48.dp),
                                cornerRadius = 24.dp,
                                contentDescription = artist.name,
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(artist.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${artist.trackCount} tracks • ${artist.albumCount} albums",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }

            LibraryTab.ALBUMS -> if (state.visibleAlbums.isEmpty()) {
                RiffEmptyHint("no albums yet")
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(state.visibleAlbums, key = { "${it.artist}::${it.name}" }) { album ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RiffArtwork(album.artworkUri, Modifier.size(48.dp), cornerRadius = 10.dp, contentDescription = album.name)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(album.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${album.artist} • ${album.trackCount} tracks",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }

            else -> {
                val tracks = state.visible
                if (tracks.isEmpty()) {
                    RiffEmptyHint(
                        when (state.tab) {
                            LibraryTab.FAVORITES -> "no favourites yet — tap the heart on any track"
                            LibraryTab.DOWNLOADS -> "no downloads yet — use \"Download\" in a track menu"
                            LibraryTab.HISTORY -> "nothing played yet"
                            else -> "your library is empty — search for music or add local files"
                        },
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        item {
                            RiffSectionHeader(
                                title = state.tab.label,
                                hint = if (state.query.isBlank()) null else "filtered",
                            )
                        }
                        items(tracks, key = { it.id }) { track ->
                            RiffTrackRow(
                                track = track,
                                isCurrent = player.track?.id == track.id,
                                onClick = { viewModel.play(track) },
                                onFavoriteToggle = { viewModel.toggleFavorite(track) },
                                onMoreClick = { actionTrack = track },
                            )
                        }
                        item { Spacer(Modifier.height(24.dp)) }
                    }
                }
            }
        }
    }

    actionTrack?.let { track ->
        TrackActionSheet(
            track = track,
            onDismiss = { actionTrack = null },
            onPlay = { viewModel.play(track) },
            onPlayNext = { viewModel.queueNext(track) },
            onAddToQueue = { viewModel.addToQueue(track) },
            onToggleFavorite = { viewModel.toggleFavorite(track) },
            onDownload = {},
            onDeleteDownload = if (track.isDownloaded) {
                { viewModel.deleteDownload(track) }
            } else {
                null
            },
            onSearchArtist = { viewModel.openArtist(track.artist) },
        )
    }

    if (confirmClear) {
        RiffConfirmDialog(
            title = "Clear offline library?",
            text = "This deletes every downloaded file from the device. Favourites, playlists and history stay.",
            confirmLabel = "Delete files",
            onConfirm = viewModel::clearAllDownloads,
            onDismiss = { confirmClear = false },
        )
    }

    if (profile != null || profileLoading) {
        ArtistProfileSheet(
            profile = profile,
            loading = profileLoading,
            onDismiss = viewModel::closeArtist,
            onPlayTrack = { index -> profile?.let { viewModel.playArtistTracks(it, index) } },
            onAddToQueue = viewModel::addToQueue,
        )
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 MB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> "%.2f GB".format(gb)
        mb >= 1 -> "%.1f MB".format(mb)
        else -> "%.0f KB".format(kb)
    }
}
