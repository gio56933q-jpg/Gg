package com.riff.android.feature.common

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.riff.android.core.audio.AudioEffectsController
import com.riff.android.core.player.PlaybackConnection
import com.riff.android.core.player.RiffServiceHost
import com.riff.android.domain.di.RiffContainer

/**
 * Composition locals used instead of passing the container through every screen.
 * All screens depend on the `:domain` interfaces only, never on `:data`.
 */
val LocalAppContainer = staticCompositionLocalOf<RiffContainer> {
    error("LocalAppContainer is not provided — wrap the UI in RiffApplication's container.")
}

val LocalPlaybackConnection = staticCompositionLocalOf<PlaybackConnection> {
    error("LocalPlaybackConnection is not provided — see MainActivity.")
}

/** The audio effects controller lives in the Application (see RiffApplication). */
val LocalRiffEffects = staticCompositionLocalOf<AudioEffectsController?> { null }

/**
 * Builds a ViewModel with the [RiffContainer] taken from the Application.
 * Keeps the screens free of `:data` types (task requirement: feature modules see
 * the domain interfaces, and the UI never branches on the platform).
 */
@Composable
inline fun <reified VM : ViewModel> riffViewModel(
    noinline create: (RiffContainer) -> VM,
): VM = viewModel(
    factory = viewModelFactory {
        initializer {
            val host = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as RiffServiceHost
            create(host.container)
        }
    },
)

/**
 * Duration label used by every screen. Delegates to the domain helper so the player,
 * the track rows and the queue cannot drift apart (and long tracks print 1:02:05, not
 * 1:2:05).
 */
fun formatDuration(seconds: Long): String = com.riff.android.domain.text.TrackText.formatDuration(seconds)
