package com.riff.android.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riff.android.core.player.PlaybackConnection
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.SearchPlatform
import com.riff.android.domain.model.Track
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Search screen state.
 *
 * Desktop equivalent: `handleSearch()` in app.js — the top-nav search box, the
 * YouTube/SoundCloud platform toggle, the results list and its "searching…" state.
 * The difference is that queries are debounced here (the desktop searched on Enter),
 * because phone keyboards fire input events for every character.
 */
data class SearchUiState(
    val query: String = "",
    val platform: SearchPlatform = SearchPlatform.YOUTUBE,
    val results: List<Track> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val searched: Boolean = false,
    val fromCache: Boolean = false,
    val recentQueries: List<String> = emptyList(),
)

class SearchViewModel(
    private val container: RiffContainer,
    private val connection: PlaybackConnection,
) : ViewModel() {

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    private var searchJob: Job? = null

    fun onQueryChange(query: String) {
        _state.value = _state.value.copy(query = query)
        searchJob?.cancel()
        if (query.trim().length < 2) {
            _state.value = _state.value.copy(results = emptyList(), searched = false, error = null)
            return
        }
        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            runSearch(query)
        }
    }

    fun onPlatformChange(platform: SearchPlatform) {
        if (platform == _state.value.platform) return
        _state.value = _state.value.copy(platform = platform, results = emptyList(), searched = false)
        if (_state.value.query.trim().length >= 2) {
            searchJob?.cancel()
            searchJob = viewModelScope.launch { runSearch(_state.value.query) }
        }
    }

    /** Explicit submit (keyboard "search" action) — skips the debounce. */
    fun submit() {
        val query = _state.value.query
        if (query.trim().length < 2) return
        searchJob?.cancel()
        searchJob = viewModelScope.launch { runSearch(query) }
    }

    fun repeatQuery(query: String) {
        _state.value = _state.value.copy(query = query)
        searchJob?.cancel()
        searchJob = viewModelScope.launch { runSearch(query) }
    }

    fun clearRecent() {
        _state.value = _state.value.copy(recentQueries = emptyList())
    }

    private suspend fun runSearch(rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isBlank()) return
        _state.value = _state.value.copy(loading = true, error = null)
        val platform = _state.value.platform
        val result = runCatching { container.search.search(query, platform, limit = SEARCH_LIMIT) }
            .getOrElse { error ->
                _state.value = _state.value.copy(
                    loading = false,
                    error = error.message ?: "search failed",
                    searched = true,
                )
                return
            }
        _state.value = _state.value.copy(
            loading = false,
            results = result.tracks,
            error = result.error,
            searched = true,
            fromCache = result.fromCache,
            recentQueries = (listOf(query) + _state.value.recentQueries.filterNot { it.equals(query, true) })
                .take(RECENT_LIMIT),
        )
    }

    fun play(track: Track) {
        val queue = _state.value.results
        val index = queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        connection.playTracks(queue, index, PlaybackContext.Search)
    }

    fun playAll() {
        val results = _state.value.results
        if (results.isEmpty()) return
        connection.playTracks(results, 0, PlaybackContext.Search)
    }

    fun shuffleAll() {
        val results = _state.value.results
        if (results.isEmpty()) return
        connection.setShuffle(true)
        connection.playTracks(results.shuffled(), 0, PlaybackContext.Search)
    }

    fun queueNext(track: Track) = connection.playNextInQueue(track)

    fun addToQueue(track: Track) = connection.addToQueue(track)

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            val updated = container.library.setFavorite(track, !track.favorite)
            _state.value = _state.value.copy(
                results = _state.value.results.map { if (it.id == updated.id) updated else it },
            )
            if (connection.state.value.track?.id == updated.id) connection.updateCurrentTrack(updated)
        }
    }

    companion object {
        const val SEARCH_LIMIT = 25
        const val SEARCH_DEBOUNCE_MS = 450L
        const val RECENT_LIMIT = 8
    }
}
