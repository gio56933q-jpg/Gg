package com.riff.android.feature.library

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.riff.android.core.player.PlaybackConnection
import com.riff.android.domain.di.RiffContainer
import com.riff.android.domain.model.Album
import com.riff.android.domain.model.Artist
import com.riff.android.domain.model.ArtistProfile
import com.riff.android.domain.model.PlaybackContext
import com.riff.android.domain.model.Track
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Library tabs — the desktop sidebar's Favorites/History entries plus the offline library. */
enum class LibraryTab(val label: String) {
    SONGS("Songs"),
    ARTISTS("Artists"),
    ALBUMS("Albums"),
    FAVORITES("Favorites"),
    DOWNLOADS("Downloaded"),
    HISTORY("History"),
}

data class LibraryUiState(
    val tab: LibraryTab = LibraryTab.SONGS,
    val query: String = "",
    val songs: List<Track> = emptyList(),
    val favorites: List<Track> = emptyList(),
    val downloads: List<Track> = emptyList(),
    val history: List<Track> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList(),
    val storageBytes: Long = 0L,
    val busy: Boolean = false,
    val message: String? = null,
) {
    /** Tracks of the current tab, filtered by the search box. */
    val visible: List<Track>
        get() {
            val base = when (tab) {
                LibraryTab.SONGS -> songs
                LibraryTab.FAVORITES -> favorites
                LibraryTab.DOWNLOADS -> downloads
                LibraryTab.HISTORY -> history
                LibraryTab.ARTISTS, LibraryTab.ALBUMS -> emptyList()
            }
            if (query.isBlank()) return base
            val needle = query.trim().lowercase()
            return base.filter { track ->
                track.title.lowercase().contains(needle) ||
                    track.artist.lowercase().contains(needle) ||
                    (track.album?.lowercase()?.contains(needle) ?: false)
            }
        }

    val visibleArtists: List<Artist>
        get() = if (query.isBlank()) artists else artists.filter { it.name.lowercase().contains(query.trim().lowercase()) }

    val visibleAlbums: List<Album>
        get() = if (query.isBlank()) albums else albums.filter {
            it.name.lowercase().contains(query.trim().lowercase()) ||
                it.artist.lowercase().contains(query.trim().lowercase())
        }
}

/**
 * Library state holder.
 *
 * Desktop equivalents:
 *  - the offline library overlay (`loadOfflineLibrary()` → `/api/offline-library`),
 *  - the Favorites page (`state.favorites`),
 *  - the History page (`state.history`, deduped, newest first, capped at 100),
 *  - the "add local files" flow (`<input type="file" multiple>` + `importLocalFiles()`).
 *
 * On Android the import goes through the Storage Access Framework (no
 * MANAGE_EXTERNAL_STORAGE) and optionally a MediaStore scan of the user's music.
 */
class LibraryViewModel(
    private val container: RiffContainer,
    private val connection: PlaybackConnection,
) : ViewModel() {

    private val ui = MutableStateFlow(LibraryUiState())

    private data class Tracks(
        val songs: List<Track>,
        val favorites: List<Track>,
        val downloads: List<Track>,
        val history: List<Track>,
    )

    private data class Browse(val artists: List<Artist>, val albums: List<Album>)

    val state: StateFlow<LibraryUiState> = combine(
        combine(
            container.library.observeLibrary(),
            container.library.observeFavorites(),
            container.library.observeDownloads(),
            container.library.observeHistory(),
        ) { songs, favorites, downloads, history -> Tracks(songs, favorites, downloads, history) },
        combine(
            container.library.observeArtists(),
            container.library.observeAlbums(),
        ) { artists, albums -> Browse(artists, albums) },
        ui,
    ) { tracks, browse, local ->
        local.copy(
            songs = tracks.songs,
            favorites = tracks.favorites,
            downloads = tracks.downloads,
            history = tracks.history,
            artists = browse.artists,
            albums = browse.albums,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState())

    init {
        refreshStorageUsage()
    }

    fun selectTab(tab: LibraryTab) {
        ui.value = ui.value.copy(tab = tab)
    }

    fun onQueryChange(query: String) {
        ui.value = ui.value.copy(query = query)
    }

    fun dismissMessage() {
        ui.value = ui.value.copy(message = null)
    }

    fun refreshStorageUsage() {
        viewModelScope.launch {
            val bytes = runCatching { container.library.totalDownloadBytes() }.getOrDefault(0L)
            ui.value = ui.value.copy(storageBytes = bytes)
        }
    }

    fun play(track: Track) {
        val queue = state.value.visible.ifEmpty { listOf(track) }
        val index = queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        connection.playTracks(queue, index, contextForTab(state.value.tab))
    }

    fun playAll(shuffled: Boolean = false) {
        val queue = if (shuffled) state.value.visible.shuffled() else state.value.visible
        if (queue.isEmpty()) return
        if (shuffled) connection.setShuffle(true)
        connection.playTracks(queue, 0, contextForTab(state.value.tab))
    }

    fun queueNext(track: Track) = connection.playNextInQueue(track)

    fun addToQueue(track: Track) = connection.addToQueue(track)

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            val updated = container.library.setFavorite(track, !track.favorite)
            if (connection.state.value.track?.id == updated.id) connection.updateCurrentTrack(updated)
        }
    }

    /** Deletes the local file but keeps favourites/history (desktop "clear cache"). */
    fun deleteDownload(track: Track) {
        viewModelScope.launch {
            container.library.deleteDownloaded(track.id, deleteFile = true)
            refreshStorageUsage()
            ui.value = ui.value.copy(message = "removed ${track.title} from the device")
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch {
            container.library.clearDownloads()
            refreshStorageUsage()
            ui.value = ui.value.copy(message = "offline library cleared")
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            container.library.clearHistory()
            ui.value = ui.value.copy(message = "history cleared")
        }
    }

    /** SAF import (desktop `<input type="file">` equivalent). */
    fun importUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            ui.value = ui.value.copy(busy = true)
            // Name/mime/size are resolved inside the repository (ContentResolver), so the
            // UI layer never needs storage APIs of its own.
            val track = runCatching {
                container.library.importLocalFile(
                    uri = uri.toString(),
                    displayName = null,
                    mimeType = context.contentResolver.getType(uri),
                    sizeBytes = 0L,
                )
            }.getOrNull()

            ui.value = ui.value.copy(
                busy = false,
                message = when {
                    track != null -> "imported ${track.title}"
                    else -> "could not read that file"
                },
            )
        }
    }

    /** Optional MediaStore scan (`READ_MEDIA_AUDIO` / `READ_EXTERNAL_STORAGE` on API < 33). */
    fun scanDevice() {
        viewModelScope.launch {
            ui.value = ui.value.copy(busy = true)
            val settings = runCatching { container.settings.current() }.getOrNull()
            val excluded = settings?.excludedMediaStoreFolders ?: emptySet()
            val added = runCatching { container.library.syncMediaStore(excluded) }.getOrDefault(0)
            ui.value = ui.value.copy(
                busy = false,
                message = if (added > 0) "found $added audio files on this device" else "no new audio files found",
            )
        }
    }

    /** Artist profile: remote (Deezer/Wikipedia) with a local-library fallback. */
    private val _artistProfile = MutableStateFlow<ArtistProfile?>(null)
    val artistProfile: StateFlow<ArtistProfile?> = _artistProfile.asStateFlow()

    private val _artistLoading = MutableStateFlow(false)
    val artistLoading: StateFlow<Boolean> = _artistLoading.asStateFlow()

    fun openArtist(name: String) {
        _artistLoading.value = true
        viewModelScope.launch {
            val profile = runCatching { container.artists.loadProfile(name) }.getOrNull()
            _artistProfile.value = profile
            _artistLoading.value = false
        }
    }

    fun closeArtist() {
        _artistProfile.value = null
    }

    fun playArtistTracks(profile: ArtistProfile, startIndex: Int = 0) {
        if (profile.tracks.isEmpty()) return
        viewModelScope.launch { container.library.upsertAll(profile.tracks) }
        connection.playTracks(profile.tracks, startIndex, PlaybackContext.ArtistContext(profile.name))
    }

    /** Opens a downloaded/imported file in another app (desktop "show in folder"). */
    fun shareTrack(track: Track): Intent? {
        val uri = track.localUri ?: track.sourceUrl ?: return null
        return Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
            putExtra(Intent.EXTRA_TEXT, "${track.artist} - ${track.title}")
        }
    }

    private fun contextForTab(tab: LibraryTab) = when (tab) {
        LibraryTab.FAVORITES -> PlaybackContext.Favorites
        LibraryTab.DOWNLOADS -> PlaybackContext.Downloads
        LibraryTab.HISTORY -> PlaybackContext.History
        else -> PlaybackContext.Library
    }
}
