package com.riff.android

import android.app.Application
import com.riff.android.core.audio.AudioEffectsController
import com.riff.android.core.audio.dsp.RiffEffectState
import com.riff.android.core.player.RiffServiceHost
import com.riff.android.data.di.AppContainer
import com.riff.android.domain.di.RiffContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Application object = the composition root.
 *
 * Desktop equivalent: `main.js` (Electron main process) creating the window,
 * wiring IPC handlers and starting the local HTTP server. Here it creates the
 * dependency graph, keeps the DSP state that the playback service needs (the
 * service is a singleton, so the effects state must outlive Activity recreations),
 * and resumes the last session once the process starts.
 */
class RiffApplication : Application(), RiffServiceHost {

    override val applicationScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Created eagerly: `RiffPlaybackService` may be started before the UI exists. */
    private val appContainer: AppContainer by lazy { AppContainer(this) }

    /** DSP/AudioProcessor state shared with the playback service and the UI. */
    override val effectsState: RiffEffectState = RiffEffectState()

    override val container: RiffContainer get() = appContainer

    override val notificationIconRes: Int = R.drawable.ic_notification

    /** Created in [onCreate]; the service may start before the UI does. */
    lateinit var effects: AudioEffectsController
        private set

    override fun onCreate() {
        super.onCreate()

        // Effects controller needs a scope that is not tied to any Activity.
        effects = AudioEffectsController(appContainer.settings, applicationScope)
        effects.bind()

        // Seed the effect state from the persisted settings so the very first
        // playback already has the right speed/pitch/reverb.
        applicationScope.launch {
            runCatching {
                val settings = appContainer.settings.current()
                effectsState.audio = settings.audio
                effectsState.hq = settings.hq
                effectsState.hqEnabled = settings.playback.hqEnabled
            }
        }

        // Nothing else to bootstrap: WorkManager owns downloads, the playback
        // service restores the queue from Room, and every screen observes Room
        // flows directly.
    }
}
