package com.riff.android

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.riff.android.core.theme.RiffTheme
import com.riff.android.feature.RiffApp
import com.riff.android.feature.common.LocalAppContainer
import com.riff.android.feature.common.LocalPlaybackConnection
import com.riff.android.feature.common.LocalRiffEffects
import com.riff.android.core.player.PlaybackConnection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue

/**
 * Single Activity, Compose navigation — the Android equivalent of Electron's single
 * renderer window (`index.html`).
 *
 * Nothing long-running happens here: playback lives in
 * `RiffPlaybackService`, downloads in WorkManager, and the UI only observes
 * repositories and the media session. The Activity is therefore safe to recreate
 * (rotation, process death) — the queue and position are restored from Room by the
 * service (desktop kept them in memory, Android must survive).
 */
class MainActivity : ComponentActivity() {

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { /* Denied just means no media notification; playback still works. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as RiffApplication

        setContent {
            val connection = remember { PlaybackConnection(applicationContext, lifecycleScope, app.effects) }
            val settings by app.container.settings.observeSettings().collectAsState(
                initial = com.riff.android.domain.model.RiffSettings(),
            )

            CompositionLocalProvider(
                LocalAppContainer provides app.container,
                LocalPlaybackConnection provides connection,
                LocalRiffEffects provides app.effects,
            ) {
                RiffTheme(settings = settings) {
                    RiffApp()
                }
            }
        }

        requestNotificationPermissionIfNeeded()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}
