package com.riff.android

import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.google.common.truth.Truth.assertThat
import com.riff.android.core.player.RiffServiceHost
import com.riff.android.domain.model.Track
import com.riff.android.domain.model.TrackSource
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.runner.RunWith

/**
 * End-to-end smoke test of the composition root.
 *
 * It catches the class of failure that unit tests cannot: a container that cannot be
 * built (missing Room migration, DataStore schema change, a provider that throws in its
 * constructor) or an Activity that crashes on the first frame. It also verifies the
 * library round trip through the real database, which is what makes "downloaded tracks
 * appear in the library after a restart" work.
 */
@RunWith(AndroidJUnit4::class)
class RiffAppSmokeTest {

    @Test
    fun containerBuildsAndPersistsALibraryTrack() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<RiffApplication>()
        val container = app.container

        val track = Track(
            id = "smoke:${System.currentTimeMillis()}",
            title = "Smoke test song",
            artist = "Riff tests",
            durationMs = 120_000,
            source = TrackSource.LOCAL,
            localUri = "file:///dev/null",
        )
        container.library.upsert(track)

        val stored = container.library.get(track.id)
        assertThat(stored).isNotNull()
        assertThat(stored!!.title).isEqualTo("Smoke test song")

        val favourite = container.library.setFavorite(stored, true)
        assertThat(favourite.favorite).isTrue()
        assertThat(
            container.library.observeFavorites().first().map { it.id },
        ).contains(track.id)

        container.library.clearHistory()
        container.library.setFavorite(stored, false)
        container.library.deleteDownloaded(track.id, deleteFile = false)
    }

    @Test
    fun settingsRoundTripThroughDataStore() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<RiffApplication>()
        val settings = app.container.settings

        val original = settings.current()
        settings.setTheme(original.theme.copy(accent = "#a8c7fa"))
        assertThat(settings.current().theme.accent).isEqualTo("#a8c7fa")

        settings.setAdvanced(original.advanced.copy(autoExtendWave = false))
        assertThat(settings.current().advanced.autoExtendWave).isFalse()

        // Leave the device as we found it.
        settings.setTheme(original.theme)
        settings.setAdvanced(original.advanced)
    }

    @Test
    fun activityStartsAndShowsTheDiscoverScreen() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                assertThat(activity.isFinishing).isFalse()
            }
        }
    }

    @Test
    fun applicationHostsTheEffectsStateTheServiceNeeds() {
        val app = ApplicationProvider.getApplicationContext<RiffApplication>()
        val host: RiffServiceHost = app

        assertThat(host.effectsState).isNotNull()
        assertThat(host.notificationIconRes).isNotEqualTo(0)
        assertThat(host.container.settings).isNotNull()
    }
}
