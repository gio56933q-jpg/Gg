# Riff Android
-keep class org.schabi.newpipe.extractor.** { *; }
-keep class com.riff.android.core.model.** { *; }
-keepattributes *Annotation*, InnerClasses
-dontwarn org.mozilla.javascript.**
-dontwarn org.slf4j.**
-dontwarn kotlinx.**
