# Riff for Android — porting notes

A native Android client for the Riff desktop player: **Kotlin + Jetpack Compose (Material 3) + AndroidX Media3 + Room + Coroutines/Flow**, no Electron, no WebView, no bundled binaries.

Everything in this document was derived from the desktop sources in this repository
(`app.js`, `server.js`, `platform.js`, `preload.js`, `tools.js`, `audio-engine.js`,
`index.html`, `styles.css`), not from assumptions — file and function names are cited so
the mapping can be checked. Where a desktop behaviour could not be reproduced faithfully,
the desktop behaviour, the reason and the Android approach are written down instead of
being dropped silently.

---

## 1. Build & run

```bash
cd android
./gradlew assembleDebug          # debug APK
./gradlew test                   # JVM unit tests (domain, core, data, feature)
./gradlew connectedAndroidTest   # instrumentation tests (device/emulator)
./gradlew installDebug
```

Requirements: JDK 17, Android SDK with platform 35 and build-tools 35. `local.properties`
must point at the SDK (`sdk.dir=...`), or set `ANDROID_HOME`.

Optional: point the app at a running desktop backend (see §7) and `adb reverse tcp:38472 tcp:38472`.

---

## 2. Module map

| Module | Contents | Desktop counterpart |
| --- | --- | --- |
| `:domain` | models, text/normalisation, queue planner, lyrics parsing, recommendation engine, repository *interfaces* | the plain-JS helpers in `app.js`/`server.js` (`normalizeTrack`, `getTrackNormalizedKey`, `computeTasteProfile`) |
| `:data` | Room, DataStore, providers (NewPipe, lrclib, Deezer, Riff server), repositories, WorkManager worker, MediaStore/SAF import, tag writer, exporter | `server.js` (HTTP API, yt-dlp/ffmpeg child processes, caches) + the `localStorage` persistence in `app.js` |
| `:core` | theme/palette, Compose UI primitives, ExoPlayer factory, `MediaSessionService`, DSP chain, effects controller, utilities | `audio-engine.js` (Web Audio graph), `styles.css` design tokens, the `<audio>` element + `navigator.mediaSession` wiring |
| `:feature` | screens + ViewModels (`home`, `search`, `player`, `library`, `playlists`, `lyrics`, `settings`) | `index.html` views + the render functions in `app.js` |
| `:app` | Application (composition root), single Activity, manifest | `main.js` (Electron main process) |

Dependency direction: `app → feature → data → core → domain`. The UI never imports `:data`
concrete classes; it sees `RiffContainer` (from `:domain`) through a `CompositionLocal`.

---

## 3. Feature-by-feature mapping

### 3.1 Window shell, navigation, layout

| Desktop | Android |
| --- | --- |
| Electron `BrowserWindow` + `index.html` with a left sidebar and a fixed bottom playbar | single `MainActivity` + Compose `NavHost`; sidebar becomes a `NavigationBar` (Discover / Search / Library / Playlists / Settings); the playbar becomes a mini player docked above the navigation bar |
| right-hand "now playing / lyrics" panel | full-screen `FullPlayer` (lyrics and queue live there as toggles/sheets) — phones have no room for a permanent side panel in portrait; in landscape the desktop layout collapses to the same content |
| `#search-input` + platform pill (`yt`/`sc`) | Search screen with an outlined field, debounced (450 ms) queries and a platform chip row |
| Favorites / History pages, offline-library overlay, "clear cache" modal | Library screen tabs (Songs / Artists / Albums / Favorites / Downloaded / History) + "Clear offline library" |
| Playlists sidebar + detail page with drag & drop reordering (`initListReordering`) | Playlists screen with a detail view; reordering uses explicit move-up/move-down buttons because HTML5 drag & drop has no faithful touch equivalent |
| Queue page (`renderQueue`) | `QueueSheet` (bottom sheet) with the same rows, remove, reorder and clear |
| Settings page (theme customiser, audio, lyrics, advanced, tools) | Settings screen, same sections; desktop-only sections are documented in §10 |

### 3.2 Theme and visual language

* `styles.css` tokens (`--md-sys-color-*`, `#121214` dark surface, `#D0BCFF` primary) are
  reproduced in `core/theme/RiffPalette.kt` + `RiffTheme.kt`. `generateM3Palette()`'s inputs
  are kept: **accent**, **theme mode**, **palette style** (Classic / Tonal spot / Expressive /
  Vibrant / Neutral), **intensity**, **brightness**, plus the desktop accent swatches
  (`ACCENT_SWATCHES`).
* The desktop recolours from the cover (`extractDominantColor`) — Android does the same with
  `CoverColorAnalyzer` (Palette) feeding `RiffPalette.accentFromAverageColor()`, gated by
  **Accent from artwork**.
* `#bg-mesh-a/#bg-mesh-b` radial gradients → `RiffMeshBackground` (Compose gradients), with
  the desktop "mesh brightness" setting applied.
* Component vocabulary (`RiffSectionHeader`, `RiffChip`, `RiffTrackRow`, `RiffArtwork`,
  `RiffPlaylistCover` (2×2 mosaic of `renderPlaylistCover`), `RiffBadge`, `RiffEmptyHint`,
  `RiffSpinner`, `RiffProgressLine`, `RiffOutlinedPill`) mirrors the classes in `styles.css`.
* Desktop-only VFX flags (tilt, glow trails, cover pulse…) are not ported; `Reduce motion`
  from the desktop advanced settings is honoured.
* **Analyser visualiser**: the desktop draws a real Web Audio `AnalyserNode`. Android cannot
  read the audio sink from the UI process, so `RiffEqualizerBars` animates from the play
  state instead. Documented limitation, no fake data.

### 3.3 Playback

| Desktop (`app.js`, `audio-engine.js`) | Android |
| --- | --- |
| `<audio>` element inside the renderer | `ExoPlayer` owned by `RiffPlaybackService : MediaSessionService` (`core/player/`) |
| `navigator.mediaSession` metadata + action handlers | `MediaSession` + `MediaNotification.Provider` (registered by the service) → notification, lock screen, Bluetooth, media buttons, audio focus, headphone-unplug pause — all platform behaviour |
| play/pause/next/prev/seek/volume/repeat/shuffle/speed | `PlaybackConnection` (UI-side `MediaController` façade) exposing the same command set as `playTrack/playNext/playPrev/togglePlayPause/…` |
| `playTrack(track, list, index, context)` seeding rules; `playPrev()` restarts when `currentTime > 3`; `playNext()` wraps around | ported 1:1 in `domain/queue/QueuePlanner.kt` (unit-tested) and mapped onto Media3's `seekToPrevious`, repeat and shuffle modes |
| `state.history.unshift`, dedupe, cap 100 | `HistoryDao` + `LibraryRepository.recordPlayed()` (`HISTORY_LIMIT = 100`) |
| nothing survives a restart (queue lived in memory) | **Resume after restart** (explicit requirement): current track, position, queue, repeat/shuffle are persisted to Room every 5 s, on every transition and on shutdown, then restored by the service |
| repeat = one boolean | `RepeatMode OFF → ALL → ONE` cycling (desktop's on/off behaviour is a subset) |
| `preservesPitch = false` resampling and `pitchShift` (see §3.8) | `RiffPlaybackParameters.of()` → `PlaybackParameters(speed, pitch)`, clamped 0.25×–4× |

Progress state is pushed to the UI at 250 ms while the player is active; screens only
observe `StateFlow`s (no long-running work in Activities/Composables).

### 3.4 Search

* Desktop `handleSearch()` (server.js) uses a direct YouTube HTML scrape first, then
  `yt-dlp ytsearch/scsearch`, caches results for 5 minutes and prefetches the first hits.
* Android: `MusicSearchProvider` (domain interface) with three implementations —
  `NewPipeSearchProvider` (YouTube and SoundCloud, pure Java extractor, no binaries),
  `RiffServerSearchProvider` (the desktop's own `/api/search` contract, including `isCached`),
  and the orchestration in `SearchRepositoryImpl` (5-minute cache, SoundCloud/YouTube
  fallback when the chosen platform returns nothing, upsert of results into the library so
  they can be favourited/queued/downloaded immediately).
* The UI consumes domain `Track` objects only — it never sees a provider type.

### 3.5 Streams

* Desktop `/api/stream-info` runs `yt-dlp -g`, checks the local cache first, and caches the
  resolved URL for **2 hours** (server.js: `Date.now() - cached.timestamp < 7200000`).
* Android: `RiffUriResolver` + `StreamResolver`. Stream URLs are resolved lazily when a
  `riff://track/<id>` item is prepared, with the same precedence: **local file → cached URL
  (2 h) → provider**. `BackendAwareStreamResolver` chooses on-device extraction, a Riff
  server, or auto (server first, on-device fallback). A failed on-device resolution falls
  back to a SoundCloud search for `artist + title`, which is what the desktop did when a
  YouTube stream was blocked.

### 3.6 Library, imports, offline

* Desktop: `/api/offline-library` (cache directory + `metadata.json`), `devsize_favorites`,
  `devsize_history` arrays in `localStorage`, and an `<input type="file">` import path.
* Android: one Room database (`riff.db`) with `tracks`, `playlists`, `playlist_tracks`,
  `history`, `downloads`, `lyrics`, `seen_recommendations`, `queue_items`, `playback_state`,
  `imported_folders`. A single `Track` row carries the local file, favourite flag and play
  counters, so the UI never joins two representations of the same track.
* **Imports**: SAF (`ActivityResultContracts.OpenMultipleDocuments`) needs **no permission**,
  keeps a persistable `content://` grant, and reads title/artist/album/duration/embedded cover
  through `MediaMetadataRetriever` (cover copied into `filesDir/artwork/`, mirroring the
  desktop `thumbnails/` cache). An optional MediaStore scan (button in Library, `README`-level
  explicit action) requires `READ_MEDIA_AUDIO` on API 33+ / `READ_EXTERNAL_STORAGE` on ≤ 32.
  `MANAGE_EXTERNAL_STORAGE` is **never** requested.
* **Offline-first**: a downloaded/imported track always plays from `localUri`; artwork is
  cached by Coil for remote covers and on disk for imports; lyrics are cached in the DB after
  the first fetch.

### 3.7 Playlists

Create/rename/delete, add/remove tracks, ordered positions in `playlist_tracks`, 2×2 mosaic
covers from the first four tracks, "play"/"shuffle" from the detail view. `PlaylistDao.moveTrack`
mirrors the desktop drag & drop at the data level, so a future drag gesture only needs a UI change.

### 3.8 Audio effects

Desktop chain (`audio-engine.js`): `MediaElementSource → [std chain | HQ chain] → destination`,
with `WaveShaper` distortion, feedback `Delay`, `Convolver` reverb and HQ
`compressor → lowshelf(80 Hz) → peaking(2500 Hz, Q 1.2) → highshelf(9000 Hz) → saturation →
limiter(-1 dBFS, 20:1, 5 ms/50 ms)`.

Android: `AudioEffectsController` (the only API the UI sees) writes into `RiffEffectState`;
`RiffRenderersFactory` injects `RiffAudioProcessorChain` into ExoPlayer's `DefaultAudioSink`.
Order matches the desktop: **Sonic (speed/pitch) → overdrive → delay → reverb → HQ → gain**.

| Desktop node | Android implementation | Fidelity |
| --- | --- | --- |
| `audio.playbackRate` + `preservesPitch=false` | `PlaybackParameters(rate, rate)` (Sonic) | identical intent; clamp 0.25×–4× |
| `pitchShift` (`preservesPitch=true`) | Sonic pitch (independent of tempo) | desktop's `pitchShift` was a non-standard extension; Android behaves equivalently |
| `WaveShaper` + `_makeDistortionCurve(amount)` | `WaveshaperCurve.distortion()` — same 256-point curve, same formula, linear interpolation like Web Audio | bit-comparable maths |
| feedback `Delay` (0.3 s, feedback 0.35) | `DelayLine` (circular buffer, same defaults) | identical |
| `ConvolverNode` with a generated noise/decay impulse | `Freeverb` (Schroeder comb+allpass network) | **different tail character** — no IR convolution in the audio pipeline. Same wet/dry control and comparable decay, documented in-code |
| HQ shelves | `RiffBiquad` (RBJ low/peaking/high shelf, same frequencies/Q) | identical filter maths |
| HQ compressor/limiter | `DynamicsProcessor` (feed-forward peak detector, hard knee, same threshold/ratio/attack/release values) | close; not sample-identical to Web Audio's implementation |
| HQ saturation | `tanh` shaper | same intent |
| `AnalyserNode` visualiser | animated bars | documented limitation (§3.2) |
| `AudioContext.currentTime`-driven automation | per-buffer parameter polling (`RiffEffectState.version`) | knob changes are audible immediately |

Presets (`defaultPresets` in app.js) and the three HQ chips (**Studio Clear / Warm Vinyl /
Concert Hall**, whose exact knob values are in `HqPresets`) are ported, including user presets
saved in settings. Engine selection (HQ Music 3 / Glyphs 7B / Fyro 1.1) is preserved as a
setting that feeds the same HQ processor.

Not portable: the desktop's Web Audio nodes only exist in a browser. Anything that needs a
graph render (the editor, §3.10) therefore uses platform media APIs instead of "porting" the
graph.

### 3.9 Downloads

Desktop: `/api/download` spawns `yt-dlp -x --audio-format …` with progress parsing and an
in-memory `downloadingSet` guard, writing into the cache directory.

Android: `DownloadRepository` (state in Room: queued/running/completed/failed/canceled,
progress, bytes, attempts, provider id) + `DownloadWorker` (WorkManager):

* unique work `download-<trackId>` — the successor of `downloadingSet` (duplicates are no
  ops; `REPLACE` is used for explicit retries),
* `NetworkType.CONNECTED`, or `UNMETERED` when "Download over Wi-Fi only" is on,
* exponential backoff (15 s), up to 3 attempts, `Result.retry()` while attempts remain,
* progress written to Room at most every 256 KiB (mirrors the desktop's throttling),
* survives backgrounding, process death and reboot; cancel removes the work and marks the row,
* on success: tags written with jaudiotagger (`title/artist/album` + artwork) when
  "Embed metadata & artwork" is on (the desktop's `--embed-thumbnail --add-metadata`), then the
  track row is updated with `localUri`, size and timestamp so it appears in the offline library,
* `DownloadProvider` (domain interface) with two implementations: `OnDeviceDownloadProvider`
  (NewPipe + OkHttp, resolves the stream and streams to `filesDir/music/`) and
  `RiffServerDownloadProvider` (the desktop `/api/download` contract). `CompositeDownloadProvider`
  picks by `BackendMode`, so switching backends never touches the app's structure.
* Minimum valid size 60 kB, mirroring the desktop's broken-download guard.

**No ffmpeg/yt-dlp binaries are bundled.** The desktop's `--audio-format flac/opus/mp3` step
required ffmpeg; on Android every container the extractor returns (Opus/WebM, M4A/AAC, MP3,
FLAC) plays natively through MediaCodec, so transcoding is optional and isolated behind
`AudioTranscoder` (default `NoTranscoder`, i.e. "keep the source container"). `FFMPEG_AVAILABLE`
is `false` in `app/build.gradle.kts`; FFmpegKit was retired (archived January 2025, artifacts
pulled April 2025) and its maintained forks ship source-only — see §11 for how to plug one in.

### 3.10 Lyrics

* Two-tier cache like the desktop: **custom** lyrics (never overwritten) → **fetched** cache
  (`artist___title` key, same shape as `getFetchedLyricsPath()`, so a desktop cache copies over)
  → provider lookup (lrclib.net `/api/get` then `/api/search`, preferring synced) → empty state.
* Synced highlighting uses the desktop rule "last timestamp ≤ position" plus its small early
  lead (`LyricsSync.LEAD_MS`), with auto-scroll to the active line (`scrollLyricsToLine`) and
  the `lyrics_autoscroll` / `online lyrics` / karaoke settings honoured.
* The custom-lyrics editor is present, including the desktop's timestamp shift tool
  (`CUSTOM_SHIFT_LEAD_SECONDS = 4.0`).
* Karaoke **word** highlighting (`<mm:ss.xx>` enhanced LRC) is parsed into `LyricWord` and kept
  in the model, but the UI currently highlights whole lines only — a rendering gap, not a data
  loss (documented limitation).

### 3.11 Recommendations ("My Wave")

The algorithm is **ported, not rewritten**: `computeTasteProfile()` (app.js) →
`RecommendationEngine.buildProfile()`, `buildDiscoveryQueries()` and `scoreDiscoveryCandidate()`
and `recommendVibeTracks()` (server.js) → `buildDiscoveryQueries()`, `scoreCandidate()`,
`recommend()`. Preserved exactly: seeds ≥ 5 tracks, top-5 artists, Cyrillic > 35 % ⇒ "Cyrillic"
script hint, `±60 s` duration preference, `random() * 1.5` jitter, "max 2 tracks per artist"
post-filter, `filter < 90 s / > 420 s` spam rules, and the recently-recommended window of
**100 ids / 100 keys** (the desktop kept it in server memory; Android persists it in
`seen_recommendations` so a restart does not repeat itself — "Reset recommendations" clears it).

Inputs mirror `/api/vibe`: `history[0:30]`, `favorites[0:25]`, discovery searches over
SoundCloud with a YouTube fallback. The client's `state.myWaveActive` behaviour is preserved:
the wave is a playback context, and the service requests more tracks when the queue reaches
`size - 3` (`autoExtendWave` in advanced settings).

### 3.12 Audio editor / export

Desktop: an `OfflineAudioContext` render of the whole effect graph (`audio-engine.js`), converted
to WAV by `audioBufferToWav()` and written to disk.

Android: `AudioExporter` uses `MediaExtractor` + `MediaMuxer`:

* **trim** → stream copy into M4A (`SUPPORTED_IN_MP4` codecs) — fast and lossless,
* codecs that cannot be muxed into MP4 (Opus/Vorbis/FLAC) → decode with `MediaCodec` and write a
  **WAV** file,
* **effects are not re-rendered**: Media3's `Transformer` + `Effects` is the intended path and
  the request carries the settings, but the dependency is not part of this build.
  `ExportSupport.CAN_RENDER_EFFECTS = false` makes the limitation explicit in code.

### 3.13 Settings

Persisted in one DataStore JSON document (`SettingsStore`) whose fields mirror the desktop
localStorage keys (`devsize_theme*`, `riff_adv_*`, `devsize_audio_settings`, `devsize_hq_settings`,
`devsize_custom_presets`, …). Sections: Appearance (mode, accent, palette style, intensity,
brightness, mesh brightness, accent-from-artwork), Playback (volume, HQ, skip silence,
crossfade), Lyrics, Downloads (Wi-Fi only, embed tags, transcode — marked unavailable), Backend
(mode + URL + prefer-remote-downloads), Advanced (auto-extend wave, reduce motion), Library tools
(clear offline library/history, reset My Wave, clear search cache), About.

`skipSilence` and `crossfadeMs` have **no desktop equivalent** (the `<audio>` element had
neither); they are ExoPlayer capabilities exposed as extras and labelled as such.

---

## 4. Data model

`domain/model/` is the only vocabulary:

* `Track` — id (canonical), title, artist, album, duration, artwork, source (youtube /
  soundcloud / **local** / **riff**), source id + url, optional `searchQuery` (Deezer-backed
  artist rows), `localUri`, `downloadedAt`, `fileSizeBytes`, `favorite`, `lastPlayedAt`,
  `playCount`, `addedAt`, plus derived `normalizedKey`, `isDownloaded`, `isLocal`, `playableUri`.
* `Artist`, `Album` (aggregates from the library), `ArtistProfile` (remote Deezer/Wikipedia).
* `Playlist`, `PlaylistTrack`; `Lyrics`, `LyricLine`, `LyricWord`; `HistoryEntry`;
  `PlaybackState`/`PlaybackSnapshot`; `DownloadTask`, `DownloadFormat`, `DownloadQuality`,
  `DownloadState`; `ExportRequest/Result`; `RiffSettings` (+ `AudioSettings`, `HqSettings`,
  `RiffPreset`, `ThemeSettings`, `LyricsSettings`, `AdvancedSettings`, `BackendSettings`).
* Identity: `TrackText.canonicalId()` (`platform:id`, else `platform:url`, else
  `platform:title|artist|duration`) and `TrackText.normalizeKey()` (`artist::title` with
  decorations stripped) — both ports of the desktop helpers; `TrackEntity` has a unique index on
  the normalized key so the two agree in the database.

---

## 5. Permissions and storage

| Permission | Why |
| --- | --- |
| `INTERNET`, `ACCESS_NETWORK_STATE` | search, streams, downloads |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `WAKE_LOCK` | MediaSessionService playback |
| `POST_NOTIFICATIONS` | media notification (requested once, denial is non-fatal) |
| `READ_MEDIA_AUDIO` (33+) / `READ_EXTERNAL_STORAGE` (≤ 32, `maxSdkVersion=32`) | optional MediaStore scan, requested only when the user taps "Scan device" |
| `MODIFY_AUDIO_SETTINGS` | audio focus/effects |

Downloads live in app-private storage (`filesDir/music`); imports keep a SAF `content://`
reference. `MANAGE_EXTERNAL_STORAGE` is not requested anywhere.

---

## 6. Lifecycle & background behaviour

* Media owns playback: the service keeps playing when the UI is destroyed; the Activity only
  holds a `MediaController` connection.
* Rotation/recreation: state lives in ViewModels + repositories; the connection is created in
  the Activity and released on dispose; the queue/position come back from the service.
* Process death: `RiffPlaybackService.onCreate` restores queue, index, position and modes from
  Room; downloads are re-scheduled by WorkManager; settings come from DataStore.
* Audio focus, becoming noisy (headphone unplug) and Bluetooth/media buttons are Media3
  defaults — the desktop relied on the browser for the same behaviour.
* Error handling mirrors `playNext()`'s error path: a failed resolution skips to the next item
  and surfaces a message in the player UI.

---

## 7. Backend modes (on-device vs. Riff server)

`BackendMode`:

* `ON_DEVICE` (default) — NewPipeExtractor + OkHttp inside the app; works with no other machine.
* `RIFF_SERVER` — every search/stream/download goes through a running desktop backend
  (`node server.js`, local API on `127.0.0.1:38472`); use `adb reverse tcp:38472 tcp:38472`
  so the phone can reach it. The wire contracts are the desktop's own:
  `GET /api/search`, `GET /api/stream-info` (+ `/api/local-track?id=`), `GET /api/download`.
* `AUTO` — try the server, fall back to on-device.

This is why the desktop's yt-dlp/ffmpeg behaviour is *available* to the Android app without
bundling those binaries: they stay on the desktop, and the app talks to their HTTP API.

---

## 8. Testing

JVM unit tests (`./gradlew test`, all green):

| Suite | Covers |
| --- | --- |
| `domain/QueuePlannerTest` | queue seeding, next/prev (incl. the 3 s restart rule), shuffle/repeat, wave auto-extend window, history dedupe/cap, queue merge |
| `domain/RecommendationEngineTest` | warm-up rule, taste profile, discovery queries (incl. Cyrillic + fallbacks), spam rejection, heard/seen filtering, ≥ 2-per-artist cap, limit, search failure tolerance |
| `domain/TrackTextTest`, `HqPresetTest` | canonical ids, normalized keys, artist/title sanitising, lyrics cache key, spam filter, duration formatting, HQ preset knob values |
| `domain/LyricsTest`, `LyricsSyncTest` | LRC parsing (synced + plain), custom precedence, active-line highlighting, timestamp shifting |
| `core/RiffDspTest` | waveshaper curves (identity passthrough, monotonic distortion), delay line, Freeverb tail, biquad stability, bypass logic, speed/pitch mapping and clamping |
| `data/MappersTest` | track ↔ entity round trip, local-state preservation, download/playlist/lyrics mapping, unknown enum fallbacks |
| `data/SearchMappingTest` | `/api/search` payload mapping (incl. unknown fields), YouTube id extraction (watch/youtu.be/shorts), id stability |
| `feature/LibraryFiltersTest` | per-tab filtering, artist/album filters, duration formatting, download format chips |

Instrumentation tests (`./gradlew connectedAndroidTest`):

* `data/RiffDatabaseTest` — real Room queries: library/favorites/search, history ordering + trim,
  playlist ordering/reorder/cover query, queue + playback-state persistence, downloads,
  lyrics custom precedence, seen-recommendation window, download-byte totals.
* `core/RiffMediaItemsTest` — `Track` ↔ `MediaItem` round trip, local-file preference for
  downloaded tracks, `riff://` lazy uri for streams, mixed-source queue ids.
* `app/RiffAppSmokeTest` — the container builds, settings round-trip through DataStore, the
  Activity starts, and the Application exposes the DSP state the service needs.

---

## 9. Deliberate behaviour changes

1. **Resume after restart** — the desktop lost its queue on exit; the task requires resuming, so
   queue/position/modes are persisted (Room) and restored.
2. **Playlist reordering** uses buttons instead of drag & drop (no touch-parity equivalent);
   the move semantics are identical and `PlaylistDao.moveTrack` is ready for a drag gesture.
3. **Search is debounced** (450 ms) instead of searching on Enter, because phone keyboards fire
   input events per character.
4. **Imported local files** are a new capability (the desktop only played its own cache); they
   appear in the same library, artists/albums views and playlists.
5. **Repeat has three states** (off/all/one); the desktop had on/off.
6. **Skip-silence and crossfade** are Android-only extras, labelled as such in Settings.

## 10. Desktop features that are not ported

| Feature | Why | What Android does instead |
| --- | --- | --- |
| Discord Rich Presence (`platform.js`/`preload.js` RPC) | no desktop process to attach to | nothing; not applicable on a phone |
| Auto-updater, system tray, window zoom/frameless controls (`tools.js`) | Electron shell features | Play Store / APK update flow |
| yt-dlp + ffmpeg child processes | cannot ship/execute desktop binaries; FFmpegKit retired | NewPipeExtractor on device, or `RIFF_SERVER` mode (§7); transcoding behind `AudioTranscoder` (§11) |
| Web Audio `ConvolverNode` reverb | no IR convolution in the Media3 pipeline | Freeverb implementation, same controls (§3.8) |
| `AnalyserNode` visualiser | sink analyser not exposed to the UI | animated bars driven by play state (§3.2) |
| Offline audio render for export with effects | would need Media3 `Transformer` | trim export via `MediaExtractor`/`MediaMuxer`; effects flagged unsupported |
| Karaoke word-by-word highlighting in the UI | rendering work not yet done | word timings are parsed and stored; lines highlight |

## 11. Extending

* **Transcoder**: implement `AudioTranscoder` (e.g. wrapping a maintained FFmpegKit fork or
  Media3 `Transformer`) and return it from `AppContainer.transcoder`; set `FFMPEG_AVAILABLE=true`
  in `app/build.gradle.kts`. Nothing else changes: `DownloadWorker` calls the interface.
* **New music platform**: implement `MusicSearchProvider` (+ optionally a `StreamResolver`) and
  add it to `AppContainer.searchProviders`; the UI needs no change (it only sees `Track`).
* **Drag & drop playlists**: call `PlaylistRepository.moveTrack()` from a reorderable list.
* **Effect rendering / export**: add Media3 `Transformer` with the existing
  `RiffAudioProcessorChain` as an `Effects` implementation, then flip
  `ExportSupport.CAN_RENDER_EFFECTS`.

## 12. Known limitations (summary)

1. Reverb is Freeverb, not convolution — same controls, slightly different tail.
2. No on-device transcoding (no bundled ffmpeg); downloads keep their source container.
3. Export re-encodes nothing and does not apply effects; Opus export is unsupported.
4. Karaoke word highlighting is parsed but not rendered.
5. Visualiser is not driven by real audio data.
6. Instrumentation tests need a device/emulator (`connectedAndroidTest`); the JVM suite runs
   anywhere.
